#!/usr/bin/env python3
"""Keep the TBox Edge Gateway running: restarts it if it ever crashes or is killed.

    python run_forever.py --config gateway.json
Combine with  python ../tools/install_autostart.py  so it also starts when the PC boots/logs in.
"""
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    args = [sys.executable, str(HERE / "run_gateway.py")] + sys.argv[1:]
    delay = 2.0
    while True:
        started = time.monotonic()
        code = subprocess.call(args, cwd=str(HERE))
        ran = time.monotonic() - started
        delay = 2.0 if ran > 60 else min(delay * 2, 60.0)  # back off only on rapid crash loops
        print("gateway exited with code %s after %.0fs; restarting in %.0fs" % (code, ran, delay), flush=True)
        time.sleep(delay)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
