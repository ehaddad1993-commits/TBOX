#!/usr/bin/env python3
"""Make the TBox Edge Gateway start automatically and stay running.

    python tools/install_autostart.py            # Windows: at user log-on.   Linux: systemd unit (use sudo)
    python tools/install_autostart.py --boot     # Windows: at boot (run from an Administrator prompt)
    python tools/install_autostart.py --remove
"""
import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GW = ROOT / "gateway"
NAME = "TBox Edge Gateway"


def server_autostart(a):
    name = "TBox Server"
    launcher = ROOT / "launch_tbox.py"
    if os.name == "nt":
        if a.remove:
            return subprocess.call(["schtasks", "/Delete", "/TN", name, "/F"])
        exe = Path(sys.executable)
        pyw = exe.with_name("pythonw.exe") if exe.with_name("pythonw.exe").exists() else exe
        cmd = '"%s" "%s" --no-window --lan --port %d' % (pyw, launcher, a.port)
        args = ["schtasks", "/Create", "/TN", name, "/TR", cmd, "/SC", "ONSTART" if a.boot else "ONLOGON", "/RL", "HIGHEST", "/F"]
        if a.boot:
            args += ["/RU", "SYSTEM"]
        r = subprocess.call(args)
        if r == 0:
            subprocess.call(["schtasks", "/Run", "/TN", name])
            print("TBox will now start by itself %s and is reachable at http://localhost:%d (and from other devices at http://<this-PC-IP>:%d)." % ("at boot" if a.boot else "when you sign in", a.port, a.port))
        return r
    unit = ("[Unit]\nDescription=TBox server\nAfter=network-online.target\n\n[Service]\nUser=%s\nWorkingDirectory=%s\nEnvironment=TBOX_DATA_DIR=%s\n"
            "Environment=TBOX_HOST=0.0.0.0\nEnvironment=TBOX_PORT=%d\nEnvironment=TBOX_SUPERVISED=1\nExecStart=%s %s\nRestart=always\nRestartSec=2\n\n[Install]\nWantedBy=multi-user.target\n"
            % (os.environ.get("USER", "root"), ROOT / "server", ROOT / "data", a.port, sys.executable, ROOT / "server" / "run_server.py"))
    path = Path("/etc/systemd/system/tbox-server.service")
    if a.remove:
        subprocess.call(["systemctl", "disable", "--now", "tbox-server"])
        path.unlink(missing_ok=True)
        return 0
    try:
        path.write_text(unit)
    except PermissionError:
        print("Run with sudo, or save this as %s:\n\n%s" % (path, unit))
        return 1
    subprocess.call(["systemctl", "daemon-reload"])
    return subprocess.call(["systemctl", "enable", "--now", "tbox-server"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--boot", action="store_true", help="start at machine boot instead of user log-on (needs Administrator)")
    ap.add_argument("--remove", action="store_true")
    ap.add_argument("--server", action="store_true", help="autostart the TBox SERVER on this PC (so the link always works)")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--config", default=str(GW / "gateway.json"))
    a = ap.parse_args()
    if a.server:
        return server_autostart(a)
    if os.name == "nt":
        if a.remove:
            return subprocess.call(["schtasks", "/Delete", "/TN", NAME, "/F"])
        exe = Path(sys.executable)
        pyw = exe.with_name("pythonw.exe") if exe.with_name("pythonw.exe").exists() else exe
        cmd = '"%s" "%s" --config "%s"' % (pyw, GW / "run_forever.py", a.config)
        args = ["schtasks", "/Create", "/TN", NAME, "/TR", cmd, "/SC", "ONSTART" if a.boot else "ONLOGON", "/RL", "HIGHEST", "/F"]
        if a.boot:
            args += ["/RU", "SYSTEM"]
        r = subprocess.call(args)
        if r == 0:
            print("Installed. It starts %s. To start it now: schtasks /Run /TN \"%s\"" % ("at boot" if a.boot else "when you sign in", NAME))
        return r
    unit = ("[Unit]\nDescription=%s\nAfter=network-online.target\n\n[Service]\nUser=%s\nWorkingDirectory=%s\nExecStart=%s %s --config %s\n"
            "Restart=always\nRestartSec=3\n\n[Install]\nWantedBy=multi-user.target\n" % (NAME, os.environ.get("USER", "root"), GW, sys.executable, GW / "run_gateway.py", a.config))
    path = Path("/etc/systemd/system/tbox-gateway.service")
    if a.remove:
        subprocess.call(["systemctl", "disable", "--now", "tbox-gateway"])
        path.unlink(missing_ok=True)
        return 0
    try:
        path.write_text(unit)
    except PermissionError:
        print("Run with sudo, or save this as %s:\n\n%s" % (path, unit))
        return 1
    subprocess.call(["systemctl", "daemon-reload"])
    return subprocess.call(["systemctl", "enable", "--now", "tbox-gateway"])


if __name__ == "__main__":
    sys.exit(main())
