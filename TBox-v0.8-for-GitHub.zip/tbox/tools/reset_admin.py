#!/usr/bin/env python3
"""Reset a TBox login (forgotten password) and optionally rename the user.

    python tools/reset_admin.py                         # asks for a new password for user "admin"
    python tools/reset_admin.py --new-username boss     # also renames admin -> boss
    python tools/reset_admin.py --user admin --data-dir data

Works with the server stopped or running. Signs the user out everywhere.
"""
import argparse
import getpass
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))
from tbox_server.security import check_password_policy, hash_password  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--user", default="admin")
    ap.add_argument("--new-username")
    ap.add_argument("--password", help="omit to be asked (typing is hidden)")
    ap.add_argument("--data-dir", default=str(ROOT / "data"))
    a = ap.parse_args()
    db = Path(a.data_dir) / "tbox.db"
    if not db.exists():
        sys.exit("No TBox database found at %s. Start TBox once first (or pass --data-dir)." % db)
    pw = a.password
    if not pw:
        pw = getpass.getpass("New password (min 10 chars, upper+lower case, a digit): ")
        if pw != getpass.getpass("Repeat password: "):
            sys.exit("The passwords do not match. Nothing was changed.")
    problem = check_password_policy(pw)
    if problem:
        sys.exit(problem + " Nothing was changed.")
    c = sqlite3.connect(str(db), timeout=30)
    try:
        row = c.execute("SELECT id FROM users WHERE username=? COLLATE NOCASE", (a.user,)).fetchone()
        if not row:
            names = ", ".join(r[0] for r in c.execute("SELECT username FROM users"))
            sys.exit("No user '%s'. Existing users: %s" % (a.user, names))
        if a.new_username:
            if c.execute("SELECT 1 FROM users WHERE username=? COLLATE NOCASE AND id<>?", (a.new_username, row[0])).fetchone():
                sys.exit("The username '%s' is already taken." % a.new_username)
            c.execute("UPDATE users SET username=? WHERE id=?", (a.new_username, row[0]))
        c.execute("UPDATE users SET password_hash=?, must_change_password=0, active=1, token_version=token_version+1 WHERE id=?",
                  (hash_password(pw), row[0]))
        c.commit()
    finally:
        c.close()
    print("Done. Sign in as '%s' with the new password." % (a.new_username or a.user))
    print("If the sign-in page says 'Too many failed attempts', wait 5 minutes or restart TBox (python launch_tbox.py --stop, then TBox.bat).")


if __name__ == "__main__":
    main()
