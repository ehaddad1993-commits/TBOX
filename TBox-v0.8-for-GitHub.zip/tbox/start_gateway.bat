@echo off
REM TBox Edge Gateway (Windows), restarts itself if it crashes.
REM 1) copy gateway\gateway.example.json to gateway\gateway.json and fill in server_url + token
REM 2) optional, so it starts by itself: python tools\install_autostart.py
cd /d "%~dp0gateway"
python run_forever.py --config gateway.json
pause
