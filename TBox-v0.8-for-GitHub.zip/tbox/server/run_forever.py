#!/usr/bin/env python3
"""Keep the TBox server running: restarts it after a crash or after an in-app update."""
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    env = dict(os.environ, TBOX_SUPERVISED="1")
    delay = 1.0
    while True:
        t0 = time.monotonic()
        code = subprocess.call([sys.executable, str(HERE / "run_server.py")], cwd=str(HERE), env=env)
        ran = time.monotonic() - t0
        delay = 1.0 if ran > 30 else min(delay * 2, 30.0)
        print("TBox server exited (code %s) after %.0fs; restarting in %.0fs" % (code, ran, delay), flush=True)
        time.sleep(delay)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
