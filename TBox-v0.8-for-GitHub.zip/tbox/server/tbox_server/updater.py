"""In-app updates: validate an uploaded release zip, self-test it, install it beside the bundled code
(<data dir>/app), and restart. Only whitelisted folders are extracted; paths are sanitised."""
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
from pathlib import Path

ALLOWED_TOP = {"server", "packages", "profiles", "gateway", "tools", "docs"}
SKIP_PARTS = {"__pycache__", ".git", "data", "gateway_data"}
MAX_FILES, MAX_BYTES = 3000, 100 * 1024 * 1024
SELFTEST = r"""
import sys, tempfile
from pathlib import Path
sys.path.insert(0, sys.argv[1] + "/packages/modbus"); sys.path.insert(0, sys.argv[1] + "/server")
import tbox_server
from tbox_server.app import App
from tbox_server.config import Config
d = Path(tempfile.mkdtemp())
app = App(Config.from_env(data_dir=d, seed_demo=True, run_simulator=False, admin_password="SelfTest-Pass1"))
assert len(app.profiles) > 0 and app.db.scalar("SELECT COUNT(*) FROM tags") > 0
print(tbox_server.__version__)
"""


class UpdateError(Exception):
    pass


def parse_version(v):
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        return (0,)


def extract(data, dest):
    """Validate and extract a release zip into `dest`. Returns the release's version string."""
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise UpdateError("That file is not a valid zip archive.")
    infos = [i for i in zf.infolist() if not i.is_dir()]
    if len(infos) > MAX_FILES or sum(i.file_size for i in infos) > MAX_BYTES:
        raise UpdateError("The archive is too large or has too many files.")
    names = [i.filename.replace("\\", "/") for i in infos]
    marker = next((n for n in names if n.endswith("server/tbox_server/__init__.py") and n.count("/") <= 3), None)
    if not marker:
        raise UpdateError("This does not look like a TBox release (server/tbox_server not found). Use the TBox-vX.zip I gave you, unchanged.")
    prefix = marker[: -len("server/tbox_server/__init__.py")]
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    for info, name in zip(infos, names):
        if not name.startswith(prefix):
            continue
        rel = name[len(prefix):]
        parts = rel.split("/")
        if rel.startswith("/") or ".." in parts or ":" in parts[0] or not parts[0]:
            raise UpdateError("The archive contains an unsafe path: %s" % rel)
        if parts[0] not in ALLOWED_TOP or SKIP_PARTS & set(parts) or rel.endswith((".pyc", ".db", ".db-wal", ".db-shm")):
            continue
        target = dest.joinpath(*parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(zf.read(info))
    init = dest / "server" / "tbox_server" / "__init__.py"
    m = re.search(r'__version__\s*=\s*"([^"]+)"', init.read_text(encoding="utf-8")) if init.exists() else None
    if not m or not (dest / "server" / "tbox_server" / "migrations").is_dir():
        raise UpdateError("The release is incomplete (no version or database migrations).")
    return m.group(1)


def selfcheck(new_dir):
    """Start the new code against a throw-away database. Returns (ok, message)."""
    try:
        r = subprocess.run([sys.executable, "-c", SELFTEST, str(new_dir)], capture_output=True, text=True, timeout=120,
                           env=dict(os.environ, TBOX_NO_OVERRIDE="1", TBOX_SEED_DEMO="1"))
    except subprocess.TimeoutExpired:
        return False, "self-test timed out"
    if r.returncode != 0:
        return False, (r.stderr.strip().splitlines() or ["unknown error"])[-1][:300]
    return True, r.stdout.strip()


def swap(data_dir, new_dir):
    data_dir = Path(data_dir)
    app, prev = data_dir / "app", data_dir / "app.prev"
    if prev.exists():
        shutil.rmtree(prev, ignore_errors=True)
    if app.exists():
        app.rename(prev)
    Path(new_dir).rename(app)


def schedule_restart():
    """Exit so the supervisor / host restarts us; otherwise start a replacement process first."""
    def go():
        time.sleep(1.0)
        if not (os.environ.get("TBOX_SUPERVISED") or os.environ.get("RENDER")):
            kw = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL,
                  "env": dict(os.environ, TBOX_RESTART_DELAY="2")}
            if os.name == "nt":
                kw["creationflags"] = 0x00000008 | 0x08000000
            else:
                kw["start_new_session"] = True
            subprocess.Popen([sys.executable] + sys.argv, **kw)
        os._exit(0)
    threading.Thread(target=go, daemon=True).start()
