"""API: HMI screens (Screen Designer). A screen is JSON: {width,height,elements:[{id,type,x,y,w,h,props}]}."""
import json

from .db import now_ms
from .util import loads, need, require_site, site_clause, visible_sites
from .web import HttpError

TYPES = ("label", "rect", "value", "lamp", "bar", "gauge", "button", "pipe", "tank", "generator", "solar", "pump", "motor", "valve",
         "breaker", "transformer", "inverter", "battery", "meter")
WRITE_ROLES = ("admin", "engineer")
EMPTY = {"width": 1000, "height": 600, "elements": []}


def clean_layout(layout):
    if not isinstance(layout, dict):
        raise HttpError(400, "layout must be an object")
    els = layout.get("elements", [])
    if not isinstance(els, list) or len(els) > 300:
        raise HttpError(400, "A screen can have at most 300 elements")
    out = []
    for e in els:
        if not isinstance(e, dict) or e.get("type") not in TYPES:
            raise HttpError(400, "Unknown element type")
        try:
            item = {"id": str(e["id"])[:40], "type": e["type"], **{k: int(e[k]) for k in ("x", "y", "w", "h")}}
        except (KeyError, TypeError, ValueError):
            raise HttpError(400, "Each element needs id, x, y, w, h")
        if not (-5000 <= item["x"] <= 5000 and -5000 <= item["y"] <= 5000 and 5 <= item["w"] <= 3000 and 5 <= item["h"] <= 3000):
            raise HttpError(400, "Element position or size is out of range")
        props = e.get("props") or {}
        if not isinstance(props, dict):
            raise HttpError(400, "props must be an object")
        p = {}
        for k, v in props.items():
            if isinstance(v, (int, float, bool)) or v is None:
                p[str(k)[:30]] = v
            elif isinstance(v, str):
                p[str(k)[:30]] = v[:200]
        item["props"] = p
        out.append(item)
    w, h = int(layout.get("width", 1000)), int(layout.get("height", 600))
    if not (200 <= w <= 4000 and 200 <= h <= 4000):
        raise HttpError(400, "Screen size must be between 200 and 4000")
    return {"width": w, "height": h, "elements": out}


def register(app):
    db, eng = app.db, app.engine
    R = app.router.route

    def get_screen(req):
        s = db.one("SELECT * FROM hmi_screens WHERE id=?", (req.params["id"],))
        if not s:
            raise HttpError(404, "Not found")
        require_site(db, req.user, s["site_id"])
        return s

    @R("GET", "/api/screens")
    def screens(req):
        cl, p = site_clause(visible_sites(db, req.user), "s.site_id")
        return db.q("SELECT s.id, s.site_id, s.name, s.updated_at, s.updated_by, t.name AS site_name FROM hmi_screens s JOIN sites t ON t.id=s.site_id "
                    "WHERE %s ORDER BY t.name, s.name" % cl, p)

    @R("GET", "/api/screens/<int:id>")
    def screen_get(req):
        s = get_screen(req)
        s["layout"] = loads(s["layout"], EMPTY)
        return s

    @R("POST", "/api/screens", roles=WRITE_ROLES)
    def screen_create(req):
        b = req.json()
        site_id = need(b, "site_id", int)
        require_site(db, req.user, site_id)
        layout = clean_layout(b.get("layout") or EMPTY)
        try:
            cur = db.execute("INSERT INTO hmi_screens(site_id,name,layout,updated_by,updated_at) VALUES(?,?,?,?,?)",
                             (site_id, need(b, "name"), json.dumps(layout), req.user["username"], now_ms()))
        except Exception:
            raise HttpError(409, "A screen with this name already exists on the site")
        eng.log_event("audit", "Screen created: %s" % b["name"], site_id=site_id, username=req.user["username"])
        return {"id": cur.lastrowid}

    @R("PUT", "/api/screens/<int:id>", roles=WRITE_ROLES)
    def screen_update(req):
        s = get_screen(req)
        b = req.json()
        layout = clean_layout(b["layout"]) if "layout" in b else loads(s["layout"], EMPTY)
        name = need(b, "name") if "name" in b else s["name"]
        try:
            db.execute("UPDATE hmi_screens SET name=?, layout=?, updated_by=?, updated_at=? WHERE id=?",
                       (name, json.dumps(layout), req.user["username"], now_ms(), s["id"]))
        except Exception:
            raise HttpError(409, "A screen with this name already exists on the site")
        eng.log_event("audit", "Screen saved: %s (%d elements)" % (name, len(layout["elements"])), site_id=s["site_id"], username=req.user["username"])
        return {"ok": True, "updated_at": now_ms()}

    @R("DELETE", "/api/screens/<int:id>", roles=WRITE_ROLES)
    def screen_delete(req):
        s = get_screen(req)
        db.execute("DELETE FROM hmi_screens WHERE id=?", (s["id"],))
        eng.log_event("audit", "Screen deleted: %s" % s["name"], site_id=s["site_id"], username=req.user["username"])
        return {"ok": True}
