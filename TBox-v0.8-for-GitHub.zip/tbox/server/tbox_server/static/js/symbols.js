// Industrial symbols drawn as SVG. They react to a state object: {on, level, alarm, text, color, valueText, unit}.
import { svg } from './ui.js';

const C = { line: '#8b9ab0', body: '#1c2632', dark: '#101820', on: '#2ecc71', off: '#6b7788', alarm: '#ff4d4f', amber: '#ffb000', water: '#4da3ff', pipe: '#7f93ad' };
let uid = 0;
const stateColor = (s) => (s.alarm ? C.alarm : s.on === true ? C.on : C.off);
const spin = (cx, cy, dur = 1.2) => svg('animateTransform', { attributeName: 'transform', type: 'rotate', from: `0 ${cx} ${cy}`, to: `360 ${cx} ${cy}`, dur: dur + 's', repeatCount: 'indefinite' });
const line = (x1, y1, x2, y2, stroke, w = 2) => svg('line', { x1, y1, x2, y2, stroke, 'stroke-width': w, 'stroke-linecap': 'round' });
const rect = (x, y, w, h, o = {}) => svg('rect', { x, y, width: w, height: h, rx: o.rx ?? 0, fill: o.fill ?? C.body, stroke: o.stroke ?? C.line, 'stroke-width': o.sw ?? 2 });
const circle = (cx, cy, r, o = {}) => svg('circle', { cx, cy, r, fill: o.fill ?? C.body, stroke: o.stroke ?? C.line, 'stroke-width': o.sw ?? 2 });
const text = (x, y, t, o = {}) => svg('text', { x, y, 'text-anchor': 'middle', fill: o.fill ?? '#e6ebf2', 'font-size': o.size ?? 12, 'font-weight': o.bold ? 700 : 400, 'font-family': o.mono ? 'ui-monospace,Consolas,monospace' : 'system-ui,sans-serif' }, t);
const spokes = (cx, cy, len, color, n = 3, w = 3) => {
  const g = svg('g', {});
  for (let i = 0; i < n; i++) { const a = (Math.PI * i) / n; g.append(line(cx - len * Math.cos(a), cy - len * Math.sin(a), cx + len * Math.cos(a), cy + len * Math.sin(a), color, w)); }
  return g;
};

export const SYMBOLS = {
  tank: { w: 100, h: 140, label: 'Tank' }, generator: { w: 120, h: 110, label: 'Generator' }, solar: { w: 140, h: 110, label: 'Solar panel' },
  pump: { w: 100, h: 100, label: 'Pump' }, motor: { w: 100, h: 100, label: 'Motor' }, valve: { w: 70, h: 70, label: 'Valve' },
  breaker: { w: 60, h: 100, label: 'Breaker' }, transformer: { w: 100, h: 80, label: 'Transformer' }, inverter: { w: 100, h: 80, label: 'Inverter' },
  battery: { w: 100, h: 60, label: 'Battery' }, meter: { w: 100, h: 80, label: 'Meter' },
};

const draw = {
  tank(r, s) {
    const id = 'tk' + ++uid, col = s.color || C.water;
    r.append(svg('defs', {}, svg('clipPath', { id }, svg('rect', { x: 10, y: 12, width: 80, height: 116, rx: 8 }))));
    r.append(rect(10, 12, 80, 116, { rx: 8, fill: C.dark, stroke: s.alarm ? C.alarm : C.line, sw: 3 }));
    if (s.level != null) r.append(svg('rect', { x: 10, y: 12 + 116 * (1 - s.level), width: 80, height: 116 * s.level, fill: col, opacity: 0.85, 'clip-path': `url(#${id})` }));
    for (const q of [0.25, 0.5, 0.75]) r.append(line(10, 12 + 116 * (1 - q), 24, 12 + 116 * (1 - q), C.line, 1.5));
    r.append(text(54, 76, s.level != null ? Math.round(s.level * 100) + '%' : '—', { size: 18, bold: true }), rect(20, 128, 8, 10, { fill: '#2a3646' }), rect(72, 128, 8, 10, { fill: '#2a3646' }));
  },
  generator(r, s) {
    const c = stateColor(s);
    r.append(rect(8, 88, 104, 12, { rx: 3, fill: '#2a3646' }), rect(10, 44, 44, 44, { rx: 4 }), rect(16, 34, 12, 10), rect(36, 34, 12, 10), rect(42, 14, 6, 20, { fill: '#2a3646' }), rect(54, 58, 12, 16, { fill: '#2a3646' }), circle(88, 66, 28, { stroke: c, sw: 3 }));
    if (s.on) { const g = spokes(88, 66, 22, c + 'aa', 3, 3); g.append(spin(88, 66, 1.1)); r.append(g); }
    r.append(text(88, 74, 'G', { size: 22, bold: true, fill: c }), circle(108, 14, 5, { fill: c, stroke: c }));
  },
  solar(r, s) {
    const on = s.on === true, c = s.alarm ? C.alarm : on ? C.amber : C.off;
    r.append(circle(24, 24, 10, { fill: on ? C.amber : '#2a3646', stroke: c }));
    if (on) for (let i = 0; i < 8; i++) { const a = (Math.PI * i) / 4; r.append(line(24 + 15 * Math.cos(a), 24 + 15 * Math.sin(a), 24 + 21 * Math.cos(a), 24 + 21 * Math.sin(a), C.amber, 2)); }
    r.append(svg('polygon', { points: '40,86 124,86 136,36 52,36', fill: on ? '#2a5db0' : '#1d3b6b', stroke: s.alarm ? C.alarm : C.line, 'stroke-width': 2.5 }));
    for (let i = 1; i < 4; i++) { const t = i / 4; r.append(line(52 + 84 * t, 36, 40 + 84 * t, 86, '#9db7e8', 1)); }
    for (let j = 1; j < 3; j++) { const t = j / 3; r.append(line(40 + 12 * t, 86 - 50 * t, 124 + 12 * t, 86 - 50 * t, '#9db7e8', 1)); }
    r.append(line(82, 86, 82, 102, C.line, 3), line(58, 102, 106, 102, C.line, 3));
  },
  pump(r, s) {
    const c = stateColor(s);
    r.append(rect(0, 52, 16, 12, { fill: '#2a3646' }), rect(52, 24, 44, 14, { fill: '#2a3646' }), rect(18, 90, 48, 8, { fill: '#2a3646' }), circle(42, 58, 30, { stroke: c, sw: 3 }));
    const g = spokes(42, 58, 20, c, 3, 4);
    if (s.on) g.append(spin(42, 58, 0.9));
    r.append(g, circle(42, 58, 5, { fill: c, stroke: c }));
  },
  motor(r, s) {
    const c = stateColor(s);
    r.append(rect(8, 28, 60, 44, { rx: 6 }), rect(68, 44, 24, 12, { fill: C.line }), rect(14, 72, 48, 8, { fill: '#2a3646' }));
    for (let x = 18; x <= 58; x += 10) r.append(line(x, 30, x, 36, '#2a3646', 2));
    r.append(circle(38, 52, 16, { stroke: c, sw: 3 }));
    if (s.on) { const g = svg('g', {}, line(38, 52, 38, 40, c, 3)); g.append(spin(38, 52, 0.8)); r.append(g); }
    r.append(text(38, 58, 'M', { size: 16, bold: true, fill: c }));
  },
  valve(r, s) {
    const col = s.alarm ? C.alarm : s.on === true ? C.on : s.on === false ? C.alarm : C.off;
    r.append(svg('polygon', { points: '6,18 35,38 6,58', fill: col, stroke: C.line, 'stroke-width': 2 }), svg('polygon', { points: '64,18 35,38 64,58', fill: col, stroke: C.line, 'stroke-width': 2 }),
      line(35, 38, 35, 10, C.line, 3), line(24, 10, 46, 10, C.line, 4));
  },
  breaker(r, s) {
    const closed = s.on === true, c = s.on == null ? C.off : closed ? C.on : C.alarm;
    r.append(circle(30, 12, 5), line(30, 17, 30, 34, C.line, 3), circle(30, 88, 5), line(30, 66, 30, 83, C.line, 3), circle(30, 66, 3, { fill: c, stroke: c }));
    r.append(closed || s.on == null ? line(30, 34, 30, 66, c, 4) : line(30, 34, 50, 60, c, 4));
  },
  transformer(r, s) {
    const c = stateColor(s);
    r.append(circle(38, 40, 26, { fill: 'none', stroke: c, sw: 3 }), circle(62, 40, 26, { fill: 'none', stroke: c, sw: 3 }),
      line(38, 0, 38, 14, C.line, 3), line(62, 0, 62, 14, C.line, 3), line(38, 66, 38, 80, C.line, 3), line(62, 66, 62, 80, C.line, 3));
  },
  inverter(r, s) {
    const c = stateColor(s);
    r.append(rect(6, 8, 88, 64, { rx: 6, stroke: c, sw: 3 }), line(6, 72, 94, 8, C.line, 1.5), text(28, 32, '=', { size: 20, bold: true, fill: c }), text(74, 62, '~', { size: 22, bold: true, fill: c }),
      text(28, 46, 'DC', { size: 10, fill: C.line }), text(72, 28, 'AC', { size: 10, fill: C.line }));
  },
  battery(r, s) {
    r.append(rect(4, 10, 84, 40, { rx: 5, fill: C.dark, stroke: s.alarm ? C.alarm : C.line, sw: 3 }), rect(88, 22, 8, 16, { fill: C.line }));
    if (s.level != null) r.append(svg('rect', { x: 8, y: 14, width: Math.max(0, 76 * s.level), height: 32, rx: 3, fill: s.level > 0.5 ? C.on : s.level > 0.2 ? C.amber : C.alarm, opacity: 0.9 }));
    r.append(text(46, 36, s.level != null ? Math.round(s.level * 100) + '%' : '—', { size: 15, bold: true }));
  },
  meter(r, s) {
    r.append(rect(6, 8, 88, 64, { rx: 6, stroke: s.alarm ? C.alarm : C.line, sw: 2.5 }), rect(14, 16, 72, 28, { rx: 3, fill: '#0a0f15', stroke: '#2a3646' }),
      text(50, 36, s.valueText ?? '—', { size: 15, bold: true, fill: C.amber, mono: true }), text(50, 60, s.unit || '', { size: 11, fill: C.line }));
  },
};

export function symbolSvg(type, s = {}) {
  const base = SYMBOLS[type], extra = s.text ? 18 : 0;
  const root = svg('svg', { viewBox: `0 0 ${base.w} ${base.h + extra}`, width: '100%', height: '100%', preserveAspectRatio: 'xMidYMid meet' });
  draw[type](root, s);
  if (s.text) root.append(text(base.w / 2, base.h + 13, s.text, { size: 12 }));
  return root;
}

// Pipes stretch to the element size. shape: h | v | tl (┌) | tr (┐) | bl (└) | br (┘)
export function pipeSvg(w, h, s = {}) {
  const cx = w / 2, cy = h / 2, t = s.thick || 12, shape = s.shape || 'h';
  const d = { h: `M0 ${cy} H${w}`, v: `M${cx} 0 V${h}`, tl: `M${w} ${cy} H${cx} V${h}`, tr: `M0 ${cy} H${cx} V${h}`, bl: `M${w} ${cy} H${cx} V0`, br: `M0 ${cy} H${cx} V0` }[shape] || `M0 ${cy} H${w}`;
  const root = svg('svg', { viewBox: `0 0 ${w} ${h}`, width: '100%', height: '100%', preserveAspectRatio: 'none' });
  const p = (stroke, sw, extra = {}) => svg('path', { d, fill: 'none', stroke, 'stroke-width': sw, 'stroke-linejoin': 'round', ...extra });
  root.append(p('#2a3646', t + 5), p(s.color || C.pipe, t));
  if (s.flow) {
    const dash = p('#ffffffaa', Math.max(2, t / 4), { 'stroke-dasharray': '8 14' });
    dash.append(svg('animate', { attributeName: 'stroke-dashoffset', from: '0', to: '-22', dur: '0.7s', repeatCount: 'indefinite' }));
    root.append(dash);
  }
  return root;
}
