// Screen Designer: place elements, bind each to a tag/address, save, and run live.
import { get, post, put, del } from './api.js';
import { h, clear, toast, modal, field, select, confirmBox, fmtNum, table, fmtTime } from './ui.js';
import { gauge } from './charts.js';
import { canWrite, quickWrite } from './control.js';
import { symbolSvg, pipeSvg, SYMBOLS } from './symbols.js';

const TYPES = [['label', 'Text'], ['rect', 'Box'], ['value', 'Value'], ['lamp', 'Lamp'], ['bar', 'Bar'], ['gauge', 'Gauge'], ['button', 'Button']];
const DEFAULT = { label: [160, 36, { text: 'Text', size: 18 }], rect: [200, 120, { color: '#1c2632' }], value: [150, 80, {}], lamp: [150, 40, {}], bar: [40, 160, {}], gauge: [180, 130, {}], button: [140, 46, { text: 'Button', mode: 'set', value: 1 }] };
const SYM_TYPES = Object.keys(SYMBOLS);
const BOUND = ['value', 'lamp', 'bar', 'gauge', 'button', 'pipe', ...SYM_TYPES];
const STATE_TYPES = ['generator', 'pump', 'motor', 'valve', 'breaker', 'transformer', 'inverter', 'solar', 'pipe'];
const PIPES = [['Pipe ─', 'h', 200, 30], ['Pipe │', 'v', 30, 200], ['Elbow ┌', 'tl', 60, 60], ['Elbow ┐', 'tr', 60, 60], ['Elbow └', 'bl', 60, 60], ['Elbow ┘', 'br', 60, 60]];
const ORDERS = ['ABCD', 'CDAB', 'BADC', 'DCBA'];
const DTYPES = ['bool', 'int16', 'uint16', 'int32', 'uint32', 'float32', 'int64', 'uint64', 'float64'];
const num = (v, a = {}) => h('input', { type: 'number', step: 'any', value: v ?? '', ...a });

export async function screens(box, ctx) {
  if (ctx.params.id) return editor(box, ctx, Number(ctx.params.id));
  const sites = await get('/api/sites');
  const rows = await get('/api/screens');
  const create = () => {
    const site = select(sites.map((s) => [s.id, s.name]), sites[0]?.id), name = h('input', { placeholder: 'e.g. Pump station overview' });
    modal('New screen', h('div', null, field('Site', site), field('Screen name', name)), { small: true, buttons: [{ label: 'Cancel', onclick: () => {} },
      { label: 'Create', cls: 'pri', onclick: async () => { try { const r = await post('/api/screens', { site_id: Number(site.value), name: name.value }); location.hash = '#/screens?id=' + r.id + '&mode=edit'; } catch (e) { toast(e.message, 'err'); return false; } } }] });
  };
  box.append(h('div', { class: 'row', style: 'margin-bottom:10px' }, ctx.canEdit ? h('button', { class: 'btn pri', onclick: create }, '+ New screen') : null,
    h('span', { class: 'small mut' }, 'Design your own screens: drag elements, give each one a PLC address, save, then run it live.')),
    table([{ label: 'Screen', render: (s) => h('a', { href: '#/screens?id=' + s.id }, s.name) }, { label: 'Site', render: (s) => s.site_name }, { label: 'Last saved', render: (s) => fmtTime(s.updated_at) + (s.updated_by ? ' by ' + s.updated_by : '') },
      { label: '', render: (s) => h('div', { class: 'row' }, h('a', { class: 'btn sm pri', href: '#/screens?id=' + s.id }, 'Run'), ctx.canEdit ? h('a', { class: 'btn sm', href: '#/screens?id=' + s.id + '&mode=edit' }, 'Edit design') : null) }], rows, 'No screens yet.'));
}

async function editor(box, ctx, id) {
  const scr = await get('/api/screens/' + id);
  const layout = scr.layout;
  const [tagList, devices] = await Promise.all([get('/api/tags?site_id=' + scr.site_id), get('/api/devices?site_id=' + scr.site_id)]);
  const tagById = {};
  const indexTags = (l) => { for (const k of Object.keys(tagById)) delete tagById[k]; l.forEach((t) => (tagById[t.id] = t)); };
  indexTags(tagList);
  let mode = ctx.canEdit && ctx.params.mode === 'edit' ? 'edit' : 'run';
  let sel = null, dirty = false, dragging = false, scale = 1;
  const live = {};
  const stage = h('div', { class: 'hmi-stage' });
  const wrap = h('div', { class: 'hmi-wrap' }, stage);
  const panel = h('div', { class: 'card' });
  const status = h('span', { class: 'pill q-stale hide' }, 'Unsaved changes');
  const layoutBox = h('div', { class: 'hmi-layout' }, wrap, panel);
  const markDirty = () => { dirty = true; status.classList.remove('hide'); };
  const tagFor = (el) => (el.props.tag_id ? (live[el.props.tag_id] || tagById[el.props.tag_id]) : null);

  // ---------- element rendering
  function content(el) {
    const p = el.props, t = tagFor(el), q = t && (t.no_data ? 'bad' : t.quality || 'good');
    const val = t && t.value != null ? fmtNum(t.value) : '—';
    if (SYMBOLS[el.type]) return symbolSvg(el.type, symState(el, t));
    if (el.type === 'pipe') { const st = symState(el, t); return pipeSvg(el.w, el.h, { shape: p.shape || 'h', thick: p.thick || 12, color: p.color, flow: t ? st.on === true : !!p.always }); }
    switch (el.type) {
      case 'label': return h('div', { style: `font-size:${p.size || 18}px;font-weight:${p.bold ? 700 : 400};color:${p.color || '#e6ebf2'}` }, p.text || '');
      case 'rect': return null;
      case 'value': return [h('div', { class: 'small mut' }, p.title || (t ? t.name : 'no tag')), h('div', { class: 'v' }, val, ' ', h('small', { class: 'mut' }, t ? t.unit : ''))];
      case 'lamp': { const on = t && t.value >= 0.5 && q === 'good'; return h('div', { class: 'row', style: 'justify-content:center' }, h('span', { class: 'lamp' + (on ? ' on' : '') }), h('span', null, p.text || (t ? t.name : 'no tag'))); }
      case 'bar': { const mn = p.min ?? t?.disp_min ?? 0, mx = p.max ?? t?.disp_max ?? 100; const f = t && t.value != null ? Math.max(0, Math.min(1, (t.value - mn) / (mx - mn || 1))) : 0;
        return [h('div', { class: 'hmi-fill', style: `width:100%;height:${f * 100}%` }), h('div', { style: 'position:relative;text-shadow:0 0 4px #000', class: 'small' }, val, t && t.unit ? ' ' + t.unit : '')]; }
      case 'gauge': return t ? [gauge({ ...t, quality: q }), h('div', { class: 'v', style: 'font-size:1.2em' }, val, ' ', h('small', { class: 'mut' }, t.unit))] : h('div', { class: 'mut' }, 'no tag');
      case 'button': return h('button', { class: 'btn pri', style: 'width:100%;height:100%;font-size:15px', onclick: (e) => { if (mode === 'edit') return; e.stopPropagation(); press(el); } }, p.text || 'Button');
    }
  }
  function symState(el, t) {
    const p = el.props, st = { alarm: !!(t && t.alarm), color: p.color, on: null, level: null };
    if (t && !t.no_data && t.quality !== 'bad' && t.value != null) {
      const v = t.value, mn = p.min ?? t.disp_min ?? 0, mx = p.max ?? t.disp_max ?? 100;
      st.on = el.type === 'solar' ? v > 0 : v >= 0.5;
      if (p.invert) st.on = !st.on;
      st.level = Math.max(0, Math.min(1, (v - mn) / (mx - mn || 1)));
      st.valueText = fmtNum(v); st.unit = t.unit;
      if (p.showValue) st.text = (p.title ? p.title + '  ' : '') + fmtNum(v) + (t.unit ? ' ' + t.unit : '');
    }
    if (!st.text && p.title) st.text = p.title;
    return st;
  }
  async function press(el) {
    const t = tagFor(el);
    if (!t) return toast('This button has no address yet. Open the designer and choose a tag.', 'err');
    const full = tagById[t.id] || t;
    if (!canWrite({ ...t, access: full.access })) return toast('This tag is not writable for you (needs Read/Write on the tag, an Engineer/Admin account, and a real device).', 'err');
    const p = el.props;
    const v = p.mode === 'toggle' ? (t.value >= 0.5 ? 0 : 1) : Number(p.value);
    await quickWrite({ ...full, ...t, device_name: full.device_name }, v, p.text);
  }
  function draw() {
    scale = Math.min(1, (wrap.clientWidth - 2) / layout.width) || 1;
    stage.style.width = layout.width + 'px'; stage.style.height = layout.height + 'px';
    stage.style.transform = `scale(${scale})`; wrap.style.height = Math.round(layout.height * scale + 2) + 'px';
    stage.className = 'hmi-stage' + (mode === 'edit' ? ' hmi-edit' : '');
    stage.replaceChildren(...layout.elements.map((el) => {
      const t = tagFor(el);
      const d = h('div', { class: 'hmi-el' + (sel === el.id ? ' sel' : '') + (t && (t.no_data || t.quality === 'bad' || t.quality === 'stale') ? ' dim' : ''), 'data-id': el.id,
        style: `left:${el.x}px;top:${el.y}px;width:${el.w}px;height:${el.h}px;${el.type === 'rect' ? 'background:' + (el.props.color || '#1c2632') + ';border:1px solid #2a3646' : ''}`,
        onpointerdown: mode === 'edit' ? (e) => startDrag(e, el, 'move') : null }, content(el));
      if (mode === 'edit' && sel === el.id) d.append(h('div', { class: 'hmi-rs', onpointerdown: (e) => startDrag(e, el, 'size') }));
      return d;
    }));
  }
  function startDrag(e, el, kind) {
    if (e.target.tagName === 'INPUT') return;
    e.preventDefault(); e.stopPropagation();
    if (sel !== el.id) { sel = el.id; drawPanel(); }
    dragging = true;
    const sx = e.clientX, sy = e.clientY, ox = el.x, oy = el.y, ow = el.w, oh = el.h;
    const node = () => stage.querySelector(`[data-id="${el.id}"]`);
    const move = (ev) => {
      const dx = Math.round((ev.clientX - sx) / scale / 5) * 5, dy = Math.round((ev.clientY - sy) / scale / 5) * 5;
      if (kind === 'move') { el.x = ox + dx; el.y = oy + dy; } else { el.w = Math.max(20, ow + dx); el.h = Math.max(20, oh + dy); }
      const n = node(); if (n) { n.style.left = el.x + 'px'; n.style.top = el.y + 'px'; n.style.width = el.w + 'px'; n.style.height = el.h + 'px'; }
      markDirty();
    };
    const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); dragging = false; draw(); drawPanel(); };
    window.addEventListener('pointermove', move); window.addEventListener('pointerup', up);
    draw();
  }

  // ---------- properties panel
  function drawPanel() {
    if (mode !== 'edit') return clear(panel).classList.add('hide');
    panel.classList.remove('hide');
    const el = layout.elements.find((x) => x.id === sel);
    if (!el) {
      const w = num(layout.width), hh = num(layout.height), name = h('input', { value: scr.name });
      return clear(panel).append(h('h2', null, 'Screen'), field('Name', name), h('div', { class: 'form-grid' }, field('Width', w), field('Height', hh)),
        h('button', { class: 'btn', onclick: () => { scr.name = name.value; layout.width = Number(w.value) || 1000; layout.height = Number(hh.value) || 600; markDirty(); draw(); } }, 'Apply'),
        h('p', { class: 'small mut' }, 'Click an element to edit it. Drag to move, drag the amber corner to resize. Arrow keys nudge, Delete removes, Ctrl+S saves.'));
    }
    const p = el.props, upd = () => { markDirty(); draw(); };
    const bind = (k, inp, conv) => { inp.onchange = () => { p[k] = conv ? conv(inp.value) : inp.value; upd(); drawPanel(); }; return inp; };
    const geo = h('div', { class: 'form-grid' }, ...['x', 'y', 'w', 'h'].map((k) => { const i = num(el[k]); i.onchange = () => { el[k] = Number(i.value); upd(); }; return field(k.toUpperCase(), i); }));
    const kids = [h('h2', null, (TYPES.find((t) => t[0] === el.type) || ['', el.type === 'pipe' ? 'Pipe' : (SYMBOLS[el.type] || {}).label || el.type])[1]), geo];
    if (el.type === 'label') kids.push(field('Text', bind('text', h('input', { value: p.text }))), field('Size (px)', bind('size', num(p.size), Number)), field('Colour', bind('color', h('input', { type: 'color', value: p.color || '#e6ebf2' }))),
      h('label', { style: 'display:flex;gap:6px;align-items:center' }, bind('bold', h('input', { type: 'checkbox', checked: !!p.bold }), () => !p.bold), 'Bold'));
    if (el.type === 'rect') kids.push(field('Colour', bind('color', h('input', { type: 'color', value: p.color || '#1c2632' }))));
    if (BOUND.includes(el.type)) kids.push(...tagEditor(el, upd));
    if (SYMBOLS[el.type] || el.type === 'pipe') {
      if (el.type === 'pipe') kids.push(field('Shape', bind('shape', select([['h', 'Horizontal ─'], ['v', 'Vertical │'], ['tl', 'Elbow ┌'], ['tr', 'Elbow ┐'], ['bl', 'Elbow └'], ['br', 'Elbow ┘']], p.shape || 'h'))), h('div', { class: 'form-grid' }, field('Thickness', bind('thick', num(p.thick || 12), Number)), field('Colour', bind('color', h('input', { type: 'color', value: p.color || '#7f93ad' })))),
        h('label', { style: 'display:flex;gap:6px;align-items:center' }, bind('always', h('input', { type: 'checkbox', checked: !!p.always }), () => !p.always), 'Always show flow (when no tag linked)'));
      else kids.push(field('Title (optional)', bind('title', h('input', { value: p.title }))), h('label', { style: 'display:flex;gap:6px;align-items:center' }, bind('showValue', h('input', { type: 'checkbox', checked: !!p.showValue }), () => !p.showValue), 'Show value under the symbol'));
      if (['tank', 'battery'].includes(el.type)) kids.push(h('div', { class: 'form-grid' }, field('Empty at (min)', bind('min', num(p.min), Number)), field('Full at (max)', bind('max', num(p.max), Number))), el.type === 'tank' ? field('Liquid colour', bind('color', h('input', { type: 'color', value: p.color || '#4da3ff' }))) : null);
      if (STATE_TYPES.includes(el.type)) kids.push(h('label', { style: 'display:flex;gap:6px;align-items:center' }, bind('invert', h('input', { type: 'checkbox', checked: !!p.invert }), () => !p.invert), 'Invert (ON when value is 0)'));
      kids.push(h('p', { class: 'small mut' }, { tank: 'Fills with the linked value between min and max.', battery: 'Shows the linked value as a charge level.', solar: 'Lights up when the linked value is above 0.', valve: 'Green = open (value 1), red = closed (0).', breaker: 'Green = closed (1), red = open (0).', pipe: 'Flow animation runs while the linked value is ON.', meter: 'Shows the linked value as a number.' }[el.type] || 'Turns green and animates while the linked value is ON (1); red on alarm.'));
    }
    if (el.type === 'value') kids.push(field('Title (optional)', bind('title', h('input', { value: p.title }))));
    if (el.type === 'lamp') kids.push(field('Text (optional)', bind('text', h('input', { value: p.text }))));
    if (el.type === 'bar') kids.push(h('div', { class: 'form-grid' }, field('Min', bind('min', num(p.min), Number)), field('Max', bind('max', num(p.max), Number))));
    if (el.type === 'button') kids.push(field('Button text', bind('text', h('input', { value: p.text }))), field('Action', bind('mode', select([['set', 'Send a fixed value'], ['toggle', 'Toggle ON/OFF']], p.mode || 'set'))),
      p.mode === 'toggle' ? null : field('Value to send', bind('value', num(p.value), Number)), h('p', { class: 'small mut' }, 'Every press asks for confirmation. The tag must be Read/Write and remote control must be enabled.'));
    kids.push(h('div', { class: 'row', style: 'margin-top:10px' }, h('button', { class: 'btn sm', onclick: () => { const c = JSON.parse(JSON.stringify(el)); c.id = 'e' + Date.now(); c.x += 20; c.y += 20; layout.elements.push(c); sel = c.id; markDirty(); draw(); drawPanel(); } }, 'Duplicate'),
      h('button', { class: 'btn sm dng', onclick: () => { layout.elements.splice(layout.elements.indexOf(el), 1); sel = null; markDirty(); draw(); drawPanel(); } }, 'Delete')));
    clear(panel).append(...kids);
  }

  function tagEditor(el, upd) {
    const p = el.props, cur = p.tag_id ? tagById[p.tag_id] : null;
    const dev = select([['', '— device —'], ...devices.map((d) => [d.id, d.name])], cur ? cur.device_id : '');
    const tsel = select([], '');
    const fillTags = () => tsel.replaceChildren(h('option', { value: '' }, '— tag —'), ...Object.values(tagById).filter((t) => String(t.device_id) === dev.value).map((t) => h('option', { value: t.id, selected: t.id === p.tag_id }, t.name)));
    dev.onchange = fillTags; fillTags();
    tsel.onchange = () => { p.tag_id = tsel.value ? Number(tsel.value) : null; upd(); drawPanel(); };
    const out = [h('h3', { style: 'margin-top:10px' }, 'Linked address'), field('Device', dev), field('Tag', tsel)];
    out.push(h('button', { class: 'btn sm', onclick: () => newTag(el, upd, dev.value) }, '+ New tag at an address…'));
    if (cur && ctx.canEdit) {
      const tbl = select([['holding', 'Holding register'], ['input', 'Input register'], ['coil', 'Coil'], ['discrete', 'Discrete input']], cur.table_type), addr = num(cur.address, { min: 0, max: 65535 });
      const dt = select(DTYPES, cur.data_type), bo = select(ORDERS, cur.byte_order), sc = num(cur.scale), un = h('input', { value: cur.unit || '' });
      out.push(h('h3', { style: 'margin-top:10px' }, 'Change this tag\'s address'), h('div', { class: 'form-grid' }, field('Table', tbl), field('Address', addr), field('Data type', dt), field('Byte order', bo), field('Scale', sc), field('Unit', un)),
        h('button', { class: 'btn sm pri', onclick: async () => {
          const body = { ...cur, table_type: tbl.value, address: Number(addr.value), data_type: dt.value, byte_order: bo.value, scale: Number(sc.value), unit: un.value };
          try { await put('/api/tags/' + cur.id, body); Object.assign(cur, body); toast('Address saved (gateway updates itself within seconds)', 'ok'); draw(); } catch (e) { toast(e.message, 'err'); } } }, 'Save address'));
    }
    return out;
  }

  function newTag(el, upd, devId) {
    const dev = select(devices.map((d) => [d.id, d.name]), devId || devices[0]?.id), name = h('input', { placeholder: 'e.g. Pump start command' });
    const tbl = select([['holding', 'Holding register (%MW)'], ['coil', 'Coil (%M)'], ['input', 'Input register'], ['discrete', 'Discrete input']], 'holding'), addr = num(0, { min: 0, max: 65535 });
    const dt = select(DTYPES, 'uint16'), un = h('input'), acc = select([['R', 'Read only'], ['RW', 'Read / write']], el.type === 'button' ? 'RW' : 'R'), wmin = num(''), wmax = num('');
    modal('New tag at an address', h('div', null, h('div', { class: 'form-grid' }, field('Device', dev), field('Tag name', name), field('Register table', tbl), field('Address (0-based)', addr), field('Data type', dt), field('Unit', un), field('Permission', acc), field('Write min', wmin), field('Write max', wmax))), { buttons: [{ label: 'Cancel', onclick: () => {} },
      { label: 'Create and link', cls: 'pri', onclick: async () => {
        try { const r = await post('/api/tags', { device_id: Number(dev.value), name: name.value, table_type: tbl.value, address: Number(addr.value), data_type: tbl.value === 'coil' || tbl.value === 'discrete' ? 'bool' : dt.value, unit: un.value, access: acc.value, write_min: wmin.value, write_max: wmax.value });
          indexTags(await get('/api/tags?site_id=' + scr.site_id)); el.props.tag_id = r.id; markDirty(); draw(); drawPanel(); toast('Tag created and linked', 'ok'); } catch (e) { toast(e.message, 'err'); return false; } } }] });
  }

  // ---------- toolbar
  const save = async () => { try { await put('/api/screens/' + id, { name: scr.name, layout }); dirty = false; status.classList.add('hide'); toast('Screen saved', 'ok'); } catch (e) { toast(e.message, 'err'); } };
  const toolbar = h('div', { class: 'row', style: 'margin-bottom:10px' });
  const palette = h('div', { class: 'row', style: 'margin-bottom:10px' });
  function drawToolbar() {
    const items = [h('a', { class: 'btn', href: '#/screens' }, '← Screens'), h('h2', { style: 'margin:0' }, scr.name)];
    if (ctx.canEdit) {
      items.push(h('button', { class: 'btn' + (mode === 'edit' ? ' pri' : ''), onclick: () => { mode = mode === 'edit' ? 'run' : 'edit'; sel = null; drawToolbar(); draw(); drawPanel(); layoutBox.classList.toggle('hmi-run', mode !== 'edit'); } }, mode === 'edit' ? '▶ Run' : '✎ Edit design'));
    }
    items.push(h('span', { class: 'sp' }), status);
    if (mode === 'edit') {
      for (const [k, l] of TYPES) items.push(h('button', { class: 'btn sm', onclick: () => { const d = DEFAULT[k]; const n = layout.elements.length, el = { id: 'e' + Date.now() + n, type: k, x: 40 + (n % 6) * 170, y: 40 + Math.floor(n / 6) * 150, w: d[0], h: d[1], props: { ...d[2] } }; layout.elements.push(el); sel = el.id; markDirty(); draw(); drawPanel(); } }, '+ ' + l));
      items.push(h('button', { class: 'btn pri', onclick: save }, '💾 Save'), h('button', { class: 'btn dng sm', onclick: async () => { if (await confirmBox('Delete screen', 'Delete "' + scr.name + '"?', 'Delete', true)) { await del('/api/screens/' + id); location.hash = '#/screens'; } } }, 'Delete screen'));
    }
    clear(toolbar).append(...items);
    clear(palette);
    if (mode === 'edit') {
      palette.append(h('span', { class: 'small mut' }, 'Symbols:'));
      for (const k of SYM_TYPES) palette.append(h('button', { class: 'btn sm sym', title: SYMBOLS[k].label, onclick: () => addEl(k, SYMBOLS[k].w, SYMBOLS[k].h, {}) }, h('span', { class: 'symprev' }, symbolSvg(k, { on: true, level: 0.6 })), SYMBOLS[k].label));
      for (const [l, shape, w, hh] of PIPES) palette.append(h('button', { class: 'btn sm sym', onclick: () => addEl('pipe', w, hh, { shape, thick: 12 }) }, l));
    }
  }
  function addEl(type, w, hh, props) {
    const n = layout.elements.length, el = { id: 'e' + Date.now() + n, type, x: 40 + (n % 6) * 170, y: 40 + Math.floor(n / 6) * 150, w, h: hh, props: { ...props } };
    layout.elements.push(el); sel = el.id; markDirty(); draw(); drawPanel();
  }
  stage.addEventListener('pointerdown', (e) => { if (mode === 'edit' && e.target === stage) { sel = null; draw(); drawPanel(); } });
  const keys = (e) => {
    if (mode !== 'edit' || ['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); return save(); }
    const el = layout.elements.find((x) => x.id === sel); if (!el) return;
    const step = e.shiftKey ? 20 : 5;
    if (e.key === 'Delete') { layout.elements.splice(layout.elements.indexOf(el), 1); sel = null; }
    else if (e.key === 'ArrowLeft') el.x -= step; else if (e.key === 'ArrowRight') el.x += step; else if (e.key === 'ArrowUp') el.y -= step; else if (e.key === 'ArrowDown') el.y += step; else return;
    e.preventDefault(); markDirty(); draw(); drawPanel();
  };
  window.addEventListener('keydown', keys); ctx.onCleanup(() => window.removeEventListener('keydown', keys));
  const onResize = () => draw(); window.addEventListener('resize', onResize); ctx.onCleanup(() => window.removeEventListener('resize', onResize));
  window.onbeforeunload = () => (dirty ? 'Unsaved changes' : undefined); ctx.onCleanup(() => { window.onbeforeunload = null; });

  async function poll() {
    if (dragging) return;
    const ids = [...new Set(layout.elements.map((e) => e.props.tag_id).filter(Boolean))];
    if (!ids.length) return;
    const r = await get('/api/live?tag_ids=' + ids.join(','));
    r.tags.forEach((t) => (live[t.id] = t));
    draw();
  }
  box.append(toolbar, palette, layoutBox);
  layoutBox.classList.toggle('hmi-run', mode !== 'edit');
  drawToolbar(); draw(); drawPanel(); await poll().catch(() => {});
  ctx.every(1000, poll);
}
