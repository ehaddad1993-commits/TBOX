#!/usr/bin/env python3
"""Start the TBox server.   python run_server.py   (see README for environment variables)

Self-update support: if <data dir>/app holds a NEWER installed update (uploaded in Settings > Update TBox),
that code is used instead of the code next to this file. If the updated code fails to start, it is set aside
and the bundled version starts instead, so a bad update can never lock you out.
"""
import logging
import os
import re
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _version_of(init_file):
    try:
        m = re.search(r'__version__\s*=\s*"([^"]+)"', Path(init_file).read_text(encoding="utf-8"))
        return tuple(int(x) for x in m.group(1).split(".")) if m else (0,)
    except (OSError, ValueError):
        return (0,)


def _setup_paths():
    data = Path(os.environ.get("TBOX_DATA_DIR", "data"))
    ov = data / "app"
    active = None
    if (ov / "server" / "tbox_server" / "__init__.py").exists() and not os.environ.get("TBOX_NO_OVERRIDE"):
        if _version_of(ov / "server" / "tbox_server" / "__init__.py") > _version_of(ROOT / "tbox_server" / "__init__.py"):
            active = ov
    sys.path.insert(0, str(ROOT.parent / "packages" / "modbus"))
    sys.path.insert(0, str(ROOT))
    if active:
        sys.path.insert(0, str(active / "packages" / "modbus"))
        sys.path.insert(0, str(active / "server"))
    return data, active


DATA, ACTIVE = _setup_paths()


def main():
    try:
        from tbox_server.app import App, setup_logging
        from tbox_server.config import Config
        import tbox_server
        if "--selfcheck" in sys.argv:
            print("tbox_server %s from %s" % (tbox_server.__version__, Path(tbox_server.__file__).parent))
            return
        cfg = Config.from_env()
        cfg.ensure_dirs()
        setup_logging(cfg, logging.DEBUG if os.environ.get("TBOX_DEBUG") else logging.INFO)
        app = App(cfg)
    except Exception:
        if ACTIVE is not None:
            failed = DATA / ("app.failed-%d" % int(time.time()))
            logging.getLogger("tbox").exception("The installed update failed to start; reverting to the bundled version")
            try:
                shutil.move(str(ACTIVE), str(failed))
            except OSError:
                shutil.rmtree(ACTIVE, ignore_errors=True)
            os.execv(sys.executable, [sys.executable] + sys.argv)  # restart on the bundled code
        raise
    if app.initial_admin_password:
        bar = "=" * 70
        print("\n%s\n  TBox first start - administrator account created\n  user:     %s\n  password: %s\n"
              "  You will be asked to change it at first login. This is shown only once.\n%s\n"
              % (bar, cfg.admin_user, app.initial_admin_password, bar), flush=True)
    delay = float(os.environ.get("TBOX_RESTART_DELAY", "0") or 0)
    if delay:
        time.sleep(delay)  # let the previous process release the port after an update restart
    app.serve()


if __name__ == "__main__":
    main()
