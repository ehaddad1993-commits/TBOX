# Your Schneider M221 project in TBox (live view, live changes, keeps running)

**What TBox does and does not do.** Your control program keeps running *inside the M221* (made in SoMachine Basic). TBox does not run PLC logic; it reads the PLC's variables over Ethernet (Modbus TCP), shows them live, logs them, alarms on them and, if you enable it, writes selected values. The PLC keeps controlling the machine even if the PC, internet or TBox is off.

## A. Prepare the M221 (SoMachine Basic)
1. Give the controller a fixed IP address on your network (Configuration > Ethernet).
2. Make sure the Modbus TCP server is enabled (default port 502).
3. In your program, use memory words (`%MW`) / bits (`%M`) for every value you want to see or change from TBox, and note their numbers. (Physical I/O are usually mirrored into `%M`/`%MW` in the program.)
4. Download the program to the PLC.

## B. Create the project in TBox
1. **Sites & structure:** add your site (and building).
2. **Gateways:** add a gateway for that site and copy the token.
3. **Gateway PC** (a PC on the same network as the PLC: your laptop or a small always-on PC): fill `gateway/gateway.json` (`server_url` = your TBox link, `token`), run `start_gateway.bat`.
4. **Devices > Add device:** source *Real device via TBox Edge Gateway*, profile *Schneider Modicon M221 (starter)*, PLC IP, port 502, slave ID 1, choose the gateway. Press **Test**.
5. **Tags:** edit the starter tags or add your own: name, `holding` address = the `%MW` number (or `coil` address = the `%M` number), unit, scaling, limits.
6. Compare 2-3 values with what SoMachine shows online **before trusting** the mapping (the profile is a *starter*, not verified on your PLC).
7. **Live > My dashboard:** pin gauges, lamps and trends for your tags.

## C. Changing values from TBox
Gateway: `"allow_writes": true`. TBox: Settings > Enable remote control. Tag: Permission = Read/Write with a minimum/maximum. Use the **Write** button; TBox confirms by reading the value back. Use it for setpoints and commands that your PLC program validates; keep interlocks and emergency stops in the PLC program.

## D. Keeping it running while you are away
* **TBox server:** on Render (docs/RENDER.md) it runs 24/7 and stores history on its disk.
* **Gateway PC:** `python tools/install_autostart.py` (Windows: starts when you sign in; add `--boot` from an Administrator prompt to start at boot). `run_forever.py` restarts the gateway if it crashes. If the internet drops, the gateway keeps reading the PLC and saves the data, then uploads it when the link returns. Leave the PC powered on and set Windows not to sleep.
* Come back any time: open your TBox link, sign in, and see live values plus everything logged meanwhile (Trends, Reports, Alarms).
