@echo off
REM Makes TBox start by itself every time you sign in to Windows, so the link always works.
REM (Right-click > Run as administrator and add --boot below if you want it at boot, before sign-in.)
cd /d "%~dp0"
python tools\install_autostart.py --server
echo.
echo From now on open TBox with the "TBox Link" file or the address http://localhost:8080
echo Other devices on the same network: http://YOUR-PC-IP:8080   (find the IP with the command ipconfig)
pause
