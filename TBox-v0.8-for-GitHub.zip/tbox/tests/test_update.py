import io
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.request
import zipfile
from pathlib import Path

import helpers
from helpers import Api, login, start_app

ROOT = helpers.ROOT


def build_release(version, mutate=None, extra=None):
    """Zip of the current tree as a release `version` (layout: tbox/...)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for top in ("server", "packages", "profiles", "gateway", "tools", "docs"):
            for f in (ROOT / top).rglob("*"):
                if f.is_dir() or "__pycache__" in f.parts or f.suffix in (".pyc", ".db"):
                    continue
                rel = f.relative_to(ROOT).as_posix()
                data = f.read_bytes()
                if rel == "server/tbox_server/__init__.py":
                    data = data.decode().replace('"0.8.0"', '"%s"' % version).encode()
                if mutate and rel in mutate:
                    data = mutate[rel]
                z.writestr("tbox/" + rel, data)
        for name, data in (extra or {}).items():
            z.writestr(name, data)
    return buf.getvalue()


class UpdateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app, cls.base = start_app()
        cls.admin = login(cls.base)
        cls.restarts = []
        cls.app.restart = lambda: cls.restarts.append(1)  # never exit the test process

    @classmethod
    def tearDownClass(cls):
        cls.app.shutdown()

    def upload(self, data, expect, query=""):
        return self.admin.post("/api/system/update" + query, raw=data, headers={"Content-Type": "application/zip"}, expect=expect)

    def test_1_rejections_change_nothing(self):
        data_dir = self.app.cfg.data_dir
        self.upload(b"not a zip", 400)
        self.upload(build_release("9.9.9")[:100], 400)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("hello.txt", "x")
        self.assertIn("does not look like a TBox release", self.upload(buf.getvalue(), 400)[1]["error"])
        self.assertIn("unsafe path", self.upload(build_release("9.9.9", extra={"tbox/server/../../evil.txt": "x"}), 400)[1]["error"])
        st, r = self.upload(build_release("0.8.0"), 409)
        self.assertEqual(r["code"], "not_newer")
        broken = build_release("9.9.9", mutate={"server/tbox_server/app.py": b"raise RuntimeError('boom')\n"})
        st, r = self.upload(broken, 400)
        self.assertEqual(r["code"], "selftest_failed")
        self.assertFalse((data_dir / "app").exists())
        self.assertFalse((data_dir / "app.new").exists())
        self.assertEqual(self.restarts, [])
        pw = "Operat0rUpdate!!"
        self.admin.post("/api/users", {"username": "opu", "password": pw, "role": "engineer"}, expect=200)
        _, t = login(self.base, "opu", pw).post("/api/auth/change-password", {"current_password": pw, "new_password": "Operat0rUpdate!!2"})
        Api(self.base, t["token"]).post("/api/system/update", raw=build_release("9.9.9"), expect=403)

    def test_2_install_backup_and_bootstrap_override(self):
        data_dir = self.app.cfg.data_dir
        before = len(self.app.engine.list_backups())
        st, r = self.upload(build_release("9.9.9"), 200)
        self.assertEqual((r["from"], r["to"], r["restarting"]), ("0.8.0", "9.9.9", True))
        self.assertEqual(self.restarts, [1])
        self.assertTrue((data_dir / "app" / "server" / "tbox_server" / "__init__.py").exists())
        self.assertEqual(len(self.app.engine.list_backups()), before + 1)
        _, ev = self.admin.get("/api/events?category=audit&limit=20")
        self.assertTrue(any("TBox UPDATED" in e["message"] for e in ev))
        # the bootstrap now prefers the installed (newer) code
        env = dict(os.environ, TBOX_DATA_DIR=str(data_dir))
        out = subprocess.run([sys.executable, str(ROOT / "server" / "run_server.py"), "--selfcheck"], capture_output=True, text=True, env=env).stdout
        self.assertIn("tbox_server 9.9.9", out)
        self.assertIn(str(data_dir), out)
        # a second install keeps the previous installed copy as app.prev (restart is mocked, so 9.9.9 > running 0.7.0)
        self.upload(build_release("9.9.10"), 200)
        self.assertTrue((data_dir / "app.prev" / "server" / "tbox_server" / "__init__.py").exists())

    def test_3_bad_installed_update_falls_back_to_bundled(self):
        d = Path(tempfile.mkdtemp())
        bad = d / "app"
        shutil.copytree(ROOT / "server" / "tbox_server", bad / "server" / "tbox_server", ignore=shutil.ignore_patterns("__pycache__"))
        (bad / "server" / "tbox_server" / "__init__.py").write_text('__version__ = "9.9.9"\n')
        (bad / "server" / "tbox_server" / "app.py").write_text("raise RuntimeError('broken update')\n")
        shutil.copytree(ROOT / "packages", bad / "packages", ignore=shutil.ignore_patterns("__pycache__"))
        s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
        env = dict(os.environ, TBOX_DATA_DIR=str(d), TBOX_PORT=str(port), TBOX_ADMIN_PASSWORD="Adm1nPassw0rd!", TBOX_SEED_DEMO="0", TBOX_SIMULATOR="0")
        p = subprocess.Popen([sys.executable, str(ROOT / "server" / "run_server.py")], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        try:
            version = None
            for _ in range(80):
                try:
                    import json
                    version = json.loads(urllib.request.urlopen("http://127.0.0.1:%d/api/health" % port, timeout=1).read())["version"]
                    break
                except Exception:
                    time.sleep(0.25)
            self.assertEqual(version, "0.8.0")
            self.assertTrue(list(d.glob("app.failed-*")))
            self.assertFalse(bad.exists())
        finally:
            p.terminate()
            p.wait(timeout=10)


class RealRestartTests(unittest.TestCase):
    """Real processes: upload an update over HTTP and watch TBox restart itself into the new version."""

    def _run(self, supervised):
        import json
        d = Path(tempfile.mkdtemp())
        s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
        env = dict(os.environ, TBOX_DATA_DIR=str(d), TBOX_PORT=str(port), TBOX_ADMIN_PASSWORD="Adm1nPassw0rd!", TBOX_SEED_DEMO="0", TBOX_SIMULATOR="0")
        env.pop("TBOX_SUPERVISED", None)
        script = "run_forever.py" if supervised else "run_server.py"
        p = subprocess.Popen([sys.executable, str(ROOT / "server" / script)], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        base = "http://127.0.0.1:%d" % port

        def version():
            try:
                return json.loads(urllib.request.urlopen(base + "/api/health", timeout=1).read())["version"]
            except Exception:
                return None

        def wait_for(v, secs=40):
            end = time.time() + secs
            while time.time() < end:
                if version() == v:
                    return True
                time.sleep(0.3)
            return False
        try:
            self.assertTrue(wait_for("0.8.0"))
            admin = login(base)
            admin.post("/api/companies", {"name": "KeepMe"}, expect=200)
            admin.post("/api/system/update", raw=build_release("9.9.9"), headers={"Content-Type": "application/zip"}, expect=200)
            self.assertTrue(wait_for("9.9.9"), "TBox did not come back as 9.9.9")
            admin2 = login(base)  # same credentials still work after the update
            self.assertIn("KeepMe", [c["name"] for c in admin2.get("/api/companies")[1]])  # data kept
            self.assertEqual(admin2.get("/api/system")[1]["version"], "9.9.9")
        finally:
            for pid_dir in (p,):
                try:
                    os.killpg(os.getpgid(pid_dir.pid), 15)
                except OSError:
                    pass
            # an unsupervised update starts a detached replacement process: stop every process of this test instance
            for q in Path("/proc").glob("[0-9]*"):
                try:
                    if ("TBOX_DATA_DIR=%s" % d).encode() in (q / "environ").read_bytes():
                        os.kill(int(q.name), 15)
                except (OSError, ValueError):
                    pass

    def test_update_restart_supervised(self):
        self._run(True)

    def test_update_restart_unsupervised(self):
        self._run(False)


if __name__ == "__main__":
    unittest.main()
