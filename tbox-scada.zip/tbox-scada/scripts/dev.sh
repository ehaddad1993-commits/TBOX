#!/usr/bin/env bash
# Start TBox SCADA locally: server + two simulated edge gateways. Seeds demo data on first run. Ctrl+C stops everything.
set -e
cd "$(dirname "$0")/.."
ROOT="$(pwd)"; mkdir -p data
export TBOX_DB="${TBOX_DB:-$ROOT/data/tbox.db}" PYTHONPATH="$ROOT/edge:$ROOT/server:$PYTHONPATH"
[ -f "$TBOX_DB" ] || python3 scripts/seed_demo.py --db "$TBOX_DB"
pids=()
trap 'kill "${pids[@]}" 2>/dev/null' EXIT
python3 -m tbox_server & pids+=($!)
sleep 2
(cd data && for s in main pump; do python3 -m tbox_edge --config "$ROOT/edge/config/edge.$s.demo.json" & done; wait) & pids+=($!)
echo "TBox SCADA -> http://127.0.0.1:8000   (login: admin / TBoxDemo#1 - DEMO ONLY)"
wait
