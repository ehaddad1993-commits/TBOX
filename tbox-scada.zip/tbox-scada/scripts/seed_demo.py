"""Create demo data: 2 sites, simulated devices + tags, users, HMI screens, and N days of history.
DEMO ONLY: uses well-known passwords. Never run against a production database."""
import argparse, json, os, secrets, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "server"), str(ROOT / "edge")]
from tbox_server.app import create_app
from tbox_server import db, auth, alarms, templates
from tbox_edge.drivers.simulator import make_sim, EPOCH

DEMO_PW = "TBoxDemo#1"
W = lambda type_, x, y, w, h, tag=None, **kw: {"id": None, "type": type_, "x": x, "y": y, "w": w, "h": h, "tag": tag, **kw}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--db", default=os.environ.get("TBOX_DB", "tbox.db")); ap.add_argument("--days", type=float, default=2); a = ap.parse_args()
    create_app(a.db, background=False)
    if db.one("SELECT 1 FROM sites"): sys.exit("Database already has sites; refusing to seed.")
    now = time.time(); keys = {}
    for code, name in (("MAIN", "Main Plant"), ("PUMP", "Pump Station")):
        keys[code] = secrets.token_urlsafe(32)
        db.run("INSERT INTO sites(code,name,location,timezone,api_key_hash,created_at) VALUES(?,?,?,?,?,?)", (code, name, "Demo site", "UTC", auth.sha(keys[code]), now))
    S = {r["code"]: r["id"] for r in db.q("SELECT id,code FROM sites")}
    plan = [("MAIN", "GEN-1", "generator"), ("MAIN", "GEN-2", "generator"), ("MAIN", "SOLAR-1", "solar_inverter"), ("MAIN", "GRID-1", "energy_meter"),
            ("MAIN", "PLC-1", "plc_station"), ("PUMP", "PLC-2", "plc_station"), ("PUMP", "VFD-1", "vfd")]
    devs = {}
    for site, name, prof in plan:
        did = db.run("INSERT INTO devices(site_id,name,description,kind,profile,params,poll_ms,created_at) VALUES(?,?,?,?,?,?,?,?)",
                     (S[site], name, templates.PROFILE_TAGS and prof.replace("_", " ") + " (simulated)", "simulator", prof, "{}", 1000, now))
        templates.create_tags(db, did, prof, now); devs[name] = (did, prof)
    users = [("admin", "admin", 1, [], "Administrator"), ("operator", "operator", 0, [S["MAIN"]], "Plant Operator"), ("viewer", "viewer", 0, [S["PUMP"]], "Viewer")]
    for u, role, ctl, sites, full in users:
        h = auth.hash_pw(DEMO_PW)
        if u == "admin": db.run("UPDATE users SET pw_hash=? WHERE username='admin'", (h,)); continue
        uid = db.run("INSERT INTO users(username,full_name,pw_hash,role,can_control,created_at) VALUES(?,?,?,?,?,?)", (u, full, h, role, ctl, now))
        for s in sites: db.run("INSERT INTO user_sites(user_id,site_id) VALUES(?,?)", (uid, s))
    tag = {(r["dev"], r["name"]): r["id"] for r in db.q("SELECT t.id,t.name,d.name dev FROM tags t JOIN devices d ON d.id=t.device_id")}
    T = lambda d, n: tag[(d, n)]

    # ---- history: run the simulators in virtual time (same code + epoch as the edge, so live data continues seamlessly)
    alarms.invalidate(); sims = {n: make_sim(p, seed=i) for n, (i, p) in devs.items()}
    t_end = int((now - EPOCH) // 60) * 60 + EPOCH; t_start = t_end - int(a.days * 86400); rows = []
    for s in sims.values(): s.advance(t_start)
    c = db.conn(); c.execute("BEGIN")
    meta = {(i): (d, db.one("SELECT device_id FROM tags WHERE id=?", (i,))["device_id"], ) for (d, _), i in tag.items()}
    dev_site = {d[0]: S[next(s for s, n, p in plan if n == nm)] for nm, d in devs.items()}
    t = t_start
    while t < t_end:
        t += 60
        for name, s in sims.items():
            s.advance(t)
            for sig, val in s.s.items():
                tid = tag[(name, sig)]; rows.append((tid, float(t), float(val))); alarms.evaluate(tid, devs[name][0], dev_site[devs[name][0]], float(val), float(t))
        if len(rows) > 20000: c.executemany("INSERT OR IGNORE INTO history VALUES(?,?,?)", rows); rows = []
    c.executemany("INSERT OR IGNORE INTO history VALUES(?,?,?)", rows)
    c.execute("UPDATE alarms SET state='cleared', ack_at=cleared_at, ack_by='demo-seed' WHERE state='cleared_unack'")
    c.execute("DELETE FROM events"); c.execute("COMMIT")

    # ---- HMI screens
    def put(site, name, widgets, w=1200, h=640):
        for i, wd in enumerate(widgets): wd["id"] = f"w{i + 1}"
        db.run("INSERT INTO screens(site_id,name,doc,updated_at,updated_by) VALUES(?,?,?,?,?)", (S[site], name, json.dumps({"width": w, "height": h, "widgets": widgets}), now, "seed"))
        return db.one("SELECT MAX(id) i FROM screens")["i"]
    pump_screen = put("PUMP", "Pump station", [
        W("label", 20, 14, 520, 30, text="PUMP STATION - PLC-2 / VFD-1", size=20),
        W("tank", 80, 80, 120, 220, T("PLC-2", "tank_level_pct"), label="Tank", min=0, max=100, unit="%"),
        W("pipe", 200, 188, 160, 12, T("PLC-2", "flow_m3h"), color="#3ea6ff"), W("pump", 360, 150, 90, 90, T("PLC-2", "pump_run"), label="Pump"),
        W("pipe", 450, 188, 180, 12, T("PLC-2", "flow_m3h"), color="#3ea6ff"),
        W("gauge", 660, 70, 200, 140, T("PLC-2", "pressure_bar"), label="Pressure", min=0, max=10, unit="bar"),
        W("value", 660, 230, 200, 70, T("PLC-2", "flow_m3h"), label="Flow", unit="m3/h"),
        W("motor", 100, 380, 90, 90, T("VFD-1", "running"), label="VFD motor"), W("gauge", 240, 360, 200, 140, T("VFD-1", "freq_actual"), label="Frequency", min=0, max=60, unit="Hz"),
        W("value", 470, 380, 190, 70, T("VFD-1", "power_kw"), label="Power", unit="kW"), W("value", 470, 460, 190, 70, T("VFD-1", "drive_temp"), label="Heatsink", unit="C"),
        W("chart", 700, 340, 440, 220, T("VFD-1", "freq_actual"), label="Frequency trend (30 min)", unit="Hz", minutes=30)])
    put("MAIN", "Plant single-line", [
        W("label", 20, 12, 600, 30, text="MAIN PLANT - SINGLE LINE (SIMULATED)", size=20),
        W("value", 40, 60, 150, 64, T("GRID-1", "kw"), label="Grid import", unit="kW"), W("breaker", 100, 140, 50, 80, T("GRID-1", "kw"), label="Q1"),
        W("pipe", 124, 220, 12, 80, T("GRID-1", "kw"), color="#f5a623"),
        W("generator", 300, 60, 100, 100, T("GEN-1", "run_state"), label="GEN-1"), W("value", 275, 170, 150, 60, T("GEN-1", "kw"), label="GEN-1 power", unit="kW"), W("pipe", 344, 232, 12, 68, T("GEN-1", "kw"), color="#f5a623"),
        W("generator", 500, 60, 100, 100, T("GEN-2", "run_state"), label="GEN-2"), W("value", 475, 170, 150, 60, T("GEN-2", "kw"), label="GEN-2 power", unit="kW"), W("pipe", 544, 232, 12, 68, T("GEN-2", "kw"), color="#f5a623"),
        W("solar", 720, 60, 120, 90, T("SOLAR-1", "pv_kw"), label="PV", min=0, max=150, unit="kW"), W("value", 710, 170, 140, 60, T("SOLAR-1", "ac_kw"), label="Inverter AC", unit="kW"), W("pipe", 774, 232, 12, 68, T("SOLAR-1", "ac_kw"), color="#f5a623"),
        W("tank", 940, 60, 90, 170, T("SOLAR-1", "battery_soc"), label="Battery", min=0, max=100, unit="%", color="#30a46c"),
        W("pipe", 100, 300, 800, 12, T("GRID-1", "kw"), color="#f5a623"),
        W("tank", 300, 380, 90, 170, T("GEN-1", "fuel_level_pct"), label="GEN-1 fuel", min=0, max=100, unit="%", color="#e0a23a"), W("tank", 500, 380, 90, 170, T("GEN-2", "fuel_level_pct"), label="GEN-2 fuel", min=0, max=100, unit="%", color="#e0a23a"),
        W("gauge", 690, 380, 200, 140, T("GEN-1", "coolant_temp"), label="GEN-1 coolant", min=0, max=130, unit="C"),
        W("pump", 60, 400, 90, 90, T("PLC-1", "pump_run"), label="Water pump"), W("tank", 170, 380, 90, 170, T("PLC-1", "tank_level_pct"), label="Water tank", min=0, max=100, unit="%", color="#3ea6ff"),
        W("button", 960, 400, 200, 50, None, label="Pump Station >", screen=pump_screen)])
    for code in keys:
        cfg = {"server_url": "http://127.0.0.1:8000", "site_key": keys[code], "buffer_path": f"edge_buffer_{code.lower()}.db", "cache_path": f"edge_cache_{code.lower()}.json",
               "local_ui": {"enabled": True, "bind": "127.0.0.1", "port": 8081 if code == "MAIN" else 8082}}
        (ROOT / "edge" / "config" / f"edge.{code.lower()}.demo.json").write_text(json.dumps(cfg, indent=2))
    n = db.one("SELECT COUNT(*) n FROM history")["n"]
    print(f"Seeded {len(devs)} devices, {len(tag)} tags, {n} history rows.\nLogins (DEMO ONLY): admin / operator / viewer, password {DEMO_PW}\nEdge configs written to edge/config/edge.*.demo.json")

if __name__ == "__main__": main()
