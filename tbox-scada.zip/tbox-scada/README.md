# TBox SCADA - Technical Power Systems

Web-based industrial monitoring platform: dashboard, device and tag manager, historian, reports (Excel/PDF), alarms, drag-and-drop HMI screens, multi-site with roles, and a separate edge gateway that polls PLCs locally and buffers when the internet drops.

**Status: v0.1 - monitoring only, running on simulated devices.** Real-hardware support is documented honestly in `docs/DRIVERS.md`.

```
server/   Flask API, alarm engine, ingest, reports, SQLite schema     web/    UI (no build step)
edge/     edge gateway: drivers, poller, disk buffer, uploader        deploy/ Docker, Caddy (HTTPS), systemd
scripts/  dev.sh, seed_demo.py                                       docs/   ARCHITECTURE, DRIVERS, DEPLOYMENT
tests/    cross-component contract test
```

## Quick start
```bash
pip install -r server/requirements.txt
scripts/dev.sh        # http://127.0.0.1:8000 - admin / operator / viewer, password TBoxDemo#1 (DEMO ONLY)
```
Then: Dashboard -> click a device -> *SCADA screens* (open, then Edit to build your own) -> *Reports*. Add a real PLC under *Devices* with the **Modbus TCP** driver.

## Tests
`cd server && python -m unittest discover -s tests` | `cd edge && python -m unittest discover -s tests` | `python -m unittest tests.test_contract` (CI runs all).

Read `docs/ARCHITECTURE.md` first, then `docs/DEPLOYMENT.md`.
