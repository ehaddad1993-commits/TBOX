import { api, store, liveVal, tagLabel } from "./api.js";
import { esc, $, $$, fmt, toast, modal, opts, confirmBox, fmtTime } from "./ui.js";
import { gaugeSvg, STATE_COLOR } from "./charts.js";

const isAdmin = () => store.user && store.user.role === "admin";
const DEFAULTS = { label: [200, 30, { text: "Label", size: 18 }], value: [150, 64, { unit: "" }], lamp: [60, 60, {}], gauge: [180, 125, { min: 0, max: 100 }], tank: [90, 170, { min: 0, max: 100, unit: "%" }],
  pump: [90, 90, {}], motor: [90, 90, {}], generator: [100, 100, {}], solar: [120, 90, { min: 0, max: 100, unit: "kW" }], breaker: [50, 80, {}], pipe: [200, 12, { color: "#3ea6ff" }], button: [190, 46, { label: "Go to screen" }], chart: [380, 180, { minutes: 30 }] };
const FIELDS = { label: ["text", "size", "color"], value: ["tag", "label", "unit", "decimals"], lamp: ["tag", "label", "color"], gauge: ["tag", "label", "min", "max", "unit"], tank: ["tag", "label", "min", "max", "unit", "color"], pump: ["tag", "label"], motor: ["tag", "label"],
  generator: ["tag", "label"], solar: ["tag", "label", "min", "max", "unit"], breaker: ["tag", "label"], pipe: ["tag", "color"], button: ["label", "screen"], chart: ["tag", "label", "unit", "minutes"] };
const NUM = new Set(["size", "min", "max", "decimals", "minutes", "x", "y", "w", "h"]);

function widgetSvg(w, v, ctx) {
  const on = v && v[0] != null && v[0] > 0.5, bad = !v || v[2] === "Bad" || v[2] === "Stale", alarm = v && (v[3] === "high_high" || v[3] === "low_low" ? "#e5484d" : v[3] ? "#f5a623" : null);
  const stateCol = bad ? "#6b7280" : alarm || (on ? "#30a46c" : "#8a94a6"), valCol = !v ? "#6b7280" : STATE_COLOR(v[3], v[2]), W = w.w, H = w.h, lbl = t => t ? `<text x="${W / 2}" y="${H + 14}" text-anchor="middle" font-size="12">${esc(t)}</text>` : "";
  const num = v && v[0] != null ? fmt(v[0], w.decimals !== "" && w.decimals != null ? +w.decimals : undefined) : "--";
  switch (w.type) {
    case "label": return `<text x="0" y="${w.size || 18}" font-size="${w.size || 18}" font-weight="600" ${w.color ? `style="fill:${esc(w.color)}"` : ""}>${esc(w.text)}</text>`;
    case "value": return `<rect width="${W}" height="${H}" rx="8" fill="var(--panel)" stroke="${valCol}" stroke-width="2"/><text x="8" y="17" font-size="11" style="fill:var(--muted)">${esc(w.label)}</text><text x="${W / 2}" y="${H - 16}" text-anchor="middle" font-size="${Math.min(28, H * .4)}" font-weight="700" style="fill:${valCol}">${num}</text><text x="${W - 8}" y="${H - 6}" text-anchor="end" font-size="11" style="fill:var(--muted)">${esc(w.unit)}</text>`;
    case "lamp": return `<circle cx="${W / 2}" cy="${H / 2}" r="${Math.min(W, H) / 2 - 3}" fill="${bad ? "#6b7280" : alarm || (on ? w.color || "#30a46c" : "#374151")}" stroke="#0006" stroke-width="3"/>${lbl(w.label)}`;
    case "gauge": return gaugeSvg({ value: v && v[0], min: +w.min, max: +w.max, unit: w.unit, label: w.label, alarm: v && v[3], quality: v ? v[2] : "Bad", size: W }).replace("<svg ", `<svg height="${H}" `);
    case "tank": { const f = v && v[0] != null ? Math.max(0, Math.min(1, (v[0] - w.min) / ((w.max - w.min) || 1))) : 0, fh = (H - 8) * f;
      return `<rect x="2" y="2" width="${W - 4}" height="${H - 4}" rx="8" fill="var(--panel)" stroke="var(--muted)" stroke-width="2"/><rect x="5" y="${H - 5 - fh}" width="${W - 10}" height="${fh}" rx="5" fill="${alarm || w.color || "#3ea6ff"}" opacity=".85"/><text x="${W / 2}" y="${H / 2 + 5}" text-anchor="middle" font-size="16" font-weight="700">${num}${esc(w.unit)}</text>${lbl(w.label)}`; }
    case "pump": return `<circle cx="${W / 2}" cy="${H / 2}" r="${W / 2 - 3}" fill="var(--panel)" stroke="${stateCol}" stroke-width="4"/><g transform="translate(${W / 2} ${H / 2})"><g>${on && !bad ? `<animateTransform attributeName="transform" type="rotate" from="0" to="360" dur="1.2s" repeatCount="indefinite"/>` : ""}<path d="M-${W * .22} -${W * .22} L${W * .28} 0 L-${W * .22} ${W * .22} Z" fill="${stateCol}"/></g></g>${lbl(w.label)}`;
    case "motor": return `<circle cx="${W / 2}" cy="${H / 2}" r="${W / 2 - 3}" fill="var(--panel)" stroke="${stateCol}" stroke-width="4"/><text x="${W / 2}" y="${H / 2 + 8}" text-anchor="middle" font-size="${W * .35}" font-weight="700" style="fill:${stateCol}">M</text>${lbl(w.label)}`;
    case "generator": return `<circle cx="${W / 2}" cy="${H / 2}" r="${W / 2 - 3}" fill="var(--panel)" stroke="${stateCol}" stroke-width="4"/><text x="${W / 2}" y="${H / 2 - 2}" text-anchor="middle" font-size="${W * .32}" font-weight="700" style="fill:${stateCol}">G</text><path d="M${W * .3} ${H * .68} q${W * .1} -${H * .16} ${W * .2} 0 t${W * .2} 0" fill="none" stroke="${stateCol}" stroke-width="3"/>${lbl(w.label)}`;
    case "solar": { const f = v && v[0] != null ? Math.max(0, Math.min(1, (v[0] - w.min) / ((w.max - w.min) || 1))) : 0, c = Math.round(60 + 160 * f);
      return `<g transform="skewX(-12) translate(10 0)"><rect width="${W - 20}" height="${H}" fill="rgb(${30 + c / 4},${c},${100 + c / 2})" stroke="${stateCol}" stroke-width="3"/>${[1, 2].map(i => `<line x1="${i * (W - 20) / 3}" y1="0" x2="${i * (W - 20) / 3}" y2="${H}" stroke="#fff6"/>`).join("")}<line x1="0" y1="${H / 2}" x2="${W - 20}" y2="${H / 2}" stroke="#fff6"/></g><text x="${W / 2}" y="${H + 16}" text-anchor="middle" font-size="12">${esc(w.label)} ${num} ${esc(w.unit)}</text>`; }
    case "breaker": return `<line x1="${W / 2}" y1="0" x2="${W / 2}" y2="${H * .25}" stroke="${stateCol}" stroke-width="4"/><circle cx="${W / 2}" cy="${H * .25}" r="4" fill="${stateCol}"/>${on ? `<line x1="${W / 2}" y1="${H * .25}" x2="${W / 2}" y2="${H * .75}" stroke="${stateCol}" stroke-width="5"/>` : `<line x1="${W / 2}" y1="${H * .25}" x2="${W * .85}" y2="${H * .65}" stroke="${stateCol}" stroke-width="5"/>`}<circle cx="${W / 2}" cy="${H * .75}" r="4" fill="${stateCol}"/><line x1="${W / 2}" y1="${H * .75}" x2="${W / 2}" y2="${H}" stroke="${stateCol}" stroke-width="4"/><text x="${W / 2 + 10}" y="${H / 2}" font-size="11">${esc(w.label)}</text>`;
    case "pipe": { const horiz = W >= H, c = bad ? "#6b7280" : w.color || "#3ea6ff";
      return `<line x1="${horiz ? 0 : W / 2}" y1="${horiz ? H / 2 : 0}" x2="${horiz ? W : W / 2}" y2="${horiz ? H / 2 : H}" stroke="${c}" stroke-width="${Math.min(W, H)}" opacity=".35"/><line x1="${horiz ? 0 : W / 2}" y1="${horiz ? H / 2 : 0}" x2="${horiz ? W : W / 2}" y2="${horiz ? H / 2 : H}" stroke="${c}" stroke-width="${Math.max(2, Math.min(W, H) - 6)}" stroke-dasharray="${on ? "10 10" : "0"}">${on && !bad ? `<animate attributeName="stroke-dashoffset" from="20" to="0" dur="0.8s" repeatCount="indefinite"/>` : ""}</line>`; }
    case "button": return `<rect width="${W}" height="${H}" rx="8" fill="var(--accent)" style="cursor:pointer"/><text x="${W / 2}" y="${H / 2 + 5}" text-anchor="middle" font-size="15" font-weight="700" style="fill:#111;cursor:pointer">${esc(w.label)}</text>`;
    case "chart": { const pts = (ctx.trends || {})[w.id] || [], lo = Math.min(...pts), hi = Math.max(...pts), r = hi - lo || 1;
      return `<rect width="${W}" height="${H}" rx="8" fill="var(--panel)" stroke="var(--line)"/><text x="8" y="16" font-size="11" style="fill:var(--muted)">${esc(w.label)}</text>${pts.length > 1 ? `<polyline fill="none" stroke="#3ea6ff" stroke-width="2" points="${pts.map((p, i) => `${(8 + i / (pts.length - 1) * (W - 16)).toFixed(1)},${(H - 10 - (p - lo) / r * (H - 38)).toFixed(1)}`).join(" ")}"/><text x="${W - 8}" y="16" text-anchor="end" font-size="11">${fmt(pts[pts.length - 1])} ${esc(w.unit)}</text>` : `<text x="${W / 2}" y="${H / 2}" text-anchor="middle" font-size="12" style="fill:var(--muted)">loading...</text>`}`; }
  }
  return "";
}
function render(svg, doc, ctx, edit) {
  svg.setAttribute("viewBox", `0 0 ${doc.width} ${doc.height}`);
  let h = edit ? Array.from({ length: Math.floor(doc.width / 50) }, (_, i) => `<line x1="${i * 50}" y1="0" x2="${i * 50}" y2="${doc.height}" stroke="var(--line)" opacity=".4"/>`).join("") + Array.from({ length: Math.floor(doc.height / 50) }, (_, i) => `<line y1="${i * 50}" x1="0" y2="${i * 50}" x2="${doc.width}" stroke="var(--line)" opacity=".4"/>`).join("") : "";
  for (const w of doc.widgets) { const v = w.tag ? liveVal(w.tag) : null; h += `<g class="wd" data-id="${w.id}" transform="translate(${w.x} ${w.y})"><title>${esc(w.tag ? tagLabel(w.tag) : w.type)}${v ? " = " + fmt(v[0]) : ""}</title>${widgetSvg(w, v, ctx)}<rect width="${w.w}" height="${w.h}" fill="transparent"/></g>`; }
  if (edit && ctx.sel) { const w = doc.widgets.find(x => x.id === ctx.sel); if (w) h += `<rect class="sel" x="${w.x - 3}" y="${w.y - 3}" width="${w.w + 6}" height="${w.h + 6}"/><rect data-handle="1" x="${w.x + w.w - 6}" y="${w.y + w.h - 6}" width="12" height="12" fill="var(--accent)" style="cursor:nwse-resize"/>`; }
  svg.innerHTML = h;
}

export async function screens(root) {
  async function draw() {
    const r = await api("/screens"); const list = r.screens.filter(s => store.siteId === "all" || s.site_id == store.siteId);
    root.innerHTML = `<div class="row"><h2 style="margin:0">SCADA screens</h2><span class="spacer"></span>${isAdmin() ? `<button class="primary" id="new">+ New screen</button>` : ""}</div><div class="grid devgrid">${list.map(s => `<div class="card"><div class="n" style="font-weight:700;font-size:16px">${esc(s.name)}</div><small class="muted">${esc((store.sites.find(x => x.id === s.site_id) || {}).name)} - ${s.updated_at ? fmtTime(s.updated_at) : ""}</small><div class="row" style="margin:10px 0 0"><a class="btn primary" href="#/hmi/${s.id}">Open</a>${isAdmin() ? `<a class="btn" href="#/hmi/${s.id}/edit">Edit</a><button class="sm danger" data-del="${s.id}">x</button>` : ""}</div></div>`).join("") || `<div class="muted">No screens yet.</div>`}</div>`;
  }
  root.onclick = async e => { const b = e.target.closest("button"); if (!b) return;
    if (b.id === "new") modal({ title: "New screen", html: `<label class="f">Name<input name="name" required></label><label class="f">Site<select name="site_id">${opts(store.sites, store.siteId)}</select></label>`, onSubmit: async f => { const r = await api("/screens", { method: "POST", body: { name: f.name, site_id: +f.site_id, doc: { width: 1200, height: 640, widgets: [] } } }); location.hash = `#/hmi/${r.id}/edit`; } });
    if (b.dataset.del && await confirmBox("Delete this screen?", "Delete")) { await api("/screens/" + b.dataset.del, { method: "DELETE" }); draw(); } };
  await draw(); return {};
}

async function loadTrends(doc, ctx) {
  for (const w of doc.widgets.filter(x => x.type === "chart" && x.tag)) { try { const to = Date.now() / 1000, r = await api(`/history?tags=${w.tag}&from=${to - (w.minutes || 30) * 60}&max_points=80`); ctx.trends[w.id] = (r.series[w.tag] || []).map(p => p[1]); } catch { } }
}

export async function screenView(root, id) {
  const s = await api("/screens/" + id), doc = s.doc, ctx = { trends: {} };
  root.innerHTML = `<div class="row"><a href="#/hmi">&larr; Screens</a><h2 style="margin:0">${esc(s.name)}</h2><span class="spacer"></span>${isAdmin() ? `<a class="btn" href="#/hmi/${id}/edit">Edit screen</a>` : ""}</div><svg class="hmi" id="cv"></svg>`;
  const svg = $("#cv", root), draw = () => render(svg, doc, ctx, false);
  svg.onclick = e => { const g = e.target.closest(".wd"); const w = g && doc.widgets.find(x => x.id === g.dataset.id); if (w && w.type === "button" && w.screen) location.hash = "#/hmi/" + w.screen; };
  draw(); loadTrends(doc, ctx).then(draw); const t = setInterval(() => loadTrends(doc, ctx), 30000);
  return { update: draw, destroy: () => clearInterval(t) };
}

export async function screenEdit(root, id) {
  if (!isAdmin()) { root.innerHTML = `<div class="card">Administrator role required.</div>`; return {}; }
  const s = await api("/screens/" + id), all = (await api("/screens")).screens.filter(x => x.site_id === s.site_id && x.id != id), doc = s.doc, ctx = { trends: {}, sel: null }; let drag = null, dirty = false;
  const tags = store.tags.filter(t => t.site_id === s.site_id);
  root.innerHTML = `<div class="row"><a href="#/hmi">&larr; Screens</a><input id="nm" value="${esc(s.name)}" class="inline" style="width:240px"><span class="spacer"></span><span id="dirty" class="muted"></span><button id="dup">Duplicate</button><button id="front">Bring to front</button><button id="del" class="danger">Delete widget</button><button id="save" class="primary">Save</button><a class="btn" href="#/hmi/${id}">View</a></div>
  <div class="hmi-wrap"><div class="card palette"><h3>Widgets</h3>${Object.keys(DEFAULTS).map(t => `<button data-add="${t}">+ ${t}</button>`).join("")}</div><svg class="hmi" id="cv"></svg><div class="card" id="props"><span class="muted">Select a widget to edit its properties. Drag to move, drag the orange corner to resize, Delete key removes.</span></div></div>`;
  const svg = $("#cv", root), draw = () => render(svg, doc, ctx, true), mark = () => { dirty = true; $("#dirty", root).textContent = "unsaved changes"; };
  const pt = e => { const p = svg.createSVGPoint(); p.x = e.clientX; p.y = e.clientY; return p.matrixTransform(svg.getScreenCTM().inverse()); }, snap = v => Math.round(v / 10) * 10, cur = () => doc.widgets.find(w => w.id === ctx.sel);
  function props() {
    const w = cur(), box = $("#props", root); if (!w) { box.innerHTML = `<span class="muted">Select a widget.</span>`; return; }
    const f = k => { const val = w[k] ?? ""; if (k === "tag") return `<label class="f">Tag<select data-k="tag"><option value="">- none -</option>${tags.map(t => `<option value="${t.id}" ${t.id == w.tag ? "selected" : ""}>${esc(tagLabel(t.id))}</option>`).join("")}</select></label>`;
      if (k === "screen") return `<label class="f">Target screen<select data-k="screen"><option value="">- none -</option>${all.map(x => `<option value="${x.id}" ${x.id == w.screen ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></label>`;
      return `<label class="f">${k}<input data-k="${k}" type="${NUM.has(k) ? "number" : k === "color" ? "color" : "text"}" step="any" value="${esc(k === "color" && !val ? "#3ea6ff" : val)}"></label>`; };
    box.innerHTML = `<h3>${w.type}</h3><div class="two">${["x", "y", "w", "h"].map(f).join("")}</div>${FIELDS[w.type].map(f).join("")}${w.type === "button" ? `<div class="note">v1 buttons navigate between screens only. Control buttons arrive with the command phase (read-only by default).</div>` : ""}`;
  }
  const select = id2 => { ctx.sel = id2; draw(); props(); };
  svg.addEventListener("pointerdown", e => { const p = pt(e), hd = e.target.closest("[data-handle]"), g = e.target.closest(".wd");
    if (hd && cur()) drag = { mode: "resize" }; else if (g) { select(g.dataset.id); const w = cur(); drag = { mode: "move", dx: p.x - w.x, dy: p.y - w.y }; } else { select(null); return; } svg.setPointerCapture(e.pointerId); });
  svg.addEventListener("pointermove", e => { if (!drag) return; const p = pt(e), w = cur(); if (!w) return;
    if (drag.mode === "move") { w.x = Math.max(0, snap(p.x - drag.dx)); w.y = Math.max(0, snap(p.y - drag.dy)); } else { w.w = Math.max(10, snap(p.x - w.x)); w.h = Math.max(10, snap(p.y - w.y)); } mark(); draw(); });
  svg.addEventListener("pointerup", () => { if (drag) { drag = null; props(); } });
  $("#props", root).addEventListener("input", e => { const k = e.target.dataset.k, w = cur(); if (!k || !w) return; let v = e.target.value; if (NUM.has(k)) v = v === "" ? "" : +v; else if (k === "tag" || k === "screen") v = v ? +v : null; w[k] = v; mark(); draw(); });
  const keyh = e => { if (e.key === "Delete" && !/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName) && cur()) $("#del", root).click(); }; document.addEventListener("keydown", keyh);
  const uid = () => "w" + Math.random().toString(36).slice(2, 8);
  root.addEventListener("click", async e => { const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.add) { const [w, h, d] = DEFAULTS[b.dataset.add]; doc.widgets.push({ id: uid(), type: b.dataset.add, x: 60, y: 60, w, h, tag: null, label: "", ...d }); select(doc.widgets[doc.widgets.length - 1].id); mark(); }
    if (b.id === "del" && cur()) { doc.widgets = doc.widgets.filter(w => w.id !== ctx.sel); select(null); mark(); }
    if (b.id === "dup" && cur()) { const n = { ...cur(), id: uid(), x: cur().x + 20, y: cur().y + 20 }; doc.widgets.push(n); select(n.id); mark(); }
    if (b.id === "front" && cur()) { const w = cur(); doc.widgets = [...doc.widgets.filter(x => x !== w), w]; draw(); mark(); }
    if (b.id === "save") { try { await api("/screens/" + id, { method: "PUT", body: { name: $("#nm", root).value, doc } }); dirty = false; $("#dirty", root).textContent = ""; toast("Screen saved", "ok"); } catch (err) { toast(err.message, "bad"); } } });
  const warn = e => { if (dirty) { e.preventDefault(); e.returnValue = ""; } }; window.addEventListener("beforeunload", warn);
  draw(); loadTrends(doc, ctx).then(draw);
  return { update: draw, destroy: () => { document.removeEventListener("keydown", keyh); window.removeEventListener("beforeunload", warn); } };
}
