import { api, store, siteQ, tagLabel, loadMeta, download } from "./api.js";
import { esc, $, $$, fmt, fmtTime, chip, toast, modal, opts, confirmBox } from "./ui.js";
import { lineChart, COLORS } from "./charts.js";

const isAdmin = () => store.user && store.user.role === "admin";
const canOp = () => store.user && store.user.role !== "viewer";
const vis = a => a.filter(x => store.siteId === "all" || x.site_id == store.siteId);

// ---------------- Trends ----------------
export async function trends(root) {
  const sel = new Set((JSON.parse(sessionStorage.getItem("trendSel") || "[]")).filter(id => store.tagMap[id])); let range = 3600, data = null, timer = null, q = "";
  root.innerHTML = `<div class="row"><h2 style="margin:0">Historical trends</h2><span class="spacer"></span>
    <select id="rng" class="inline">${[["900", "15 min"], ["3600", "1 hour"], ["21600", "6 hours"], ["86400", "24 hours"], ["604800", "7 days"], ["2592000", "30 days"]].map(([v, l]) => `<option value="${v}" ${+v === 3600 ? "selected" : ""}>${l}</option>`).join("")}</select>
    <label class="inline"><input type="checkbox" id="auto" class="inline"> auto-refresh</label><button id="csv">Export CSV</button></div>
    <div class="cols"><div class="card"><canvas class="chart" id="ch" style="height:380px"></canvas><div class="legend" id="lg"></div></div>
    <div class="card"><h3>Tags (max 8)</h3><input id="q" placeholder="Filter tags..."><div class="picker" id="pk" style="margin-top:8px;max-height:60vh"></div></div></div>`;
  const pick = () => { $("#pk", root).innerHTML = vis(store.tags).filter(t => !q || tagLabel(t.id).toLowerCase().includes(q)).map(t => `<label><input type="checkbox" value="${t.id}" ${sel.has(t.id) ? "checked" : ""}>${esc(tagLabel(t.id))} <small class="muted">${esc(t.unit)}</small></label>`).join(""); };
  async function load() {
    const ids = [...sel]; sessionStorage.setItem("trendSel", JSON.stringify(ids));
    if (!ids.length) { data = null; lineChart($("#ch", root), [], { height: 380 }); $("#lg", root).innerHTML = `<span class="muted">Pick one or more tags</span>`; return; }
    const to = Date.now() / 1000; data = await api(`/history?tags=${ids.join(",")}&from=${to - range}&to=${to}&max_points=700`);
    const series = ids.map((id, i) => ({ name: tagLabel(id), unit: store.tagMap[id].unit, color: COLORS[i % 8], pts: data.series[id] || [] }));
    lineChart($("#ch", root), series, { height: 380 });
    $("#lg", root).innerHTML = series.map(s => { const v = s.pts.map(p => p[1]); return `<span><i style="background:${s.color}"></i>${esc(s.name)} - min ${fmt(Math.min(...s.pts.map(p => p[2])))} / avg ${fmt(v.reduce((a, b) => a + b, 0) / (v.length || 1))} / max ${fmt(Math.max(...s.pts.map(p => p[3])))} ${esc(s.unit)}</span>`; }).join("");
  }
  pick(); $("#q", root).oninput = e => { q = e.target.value.toLowerCase(); pick(); };
  $("#pk", root).onchange = e => { const id = +e.target.value; if (e.target.checked) { if (sel.size >= 8) { e.target.checked = false; return toast("Max 8 tags", "bad"); } sel.add(id); } else sel.delete(id); load().catch(err => toast(err.message, "bad")); };
  $("#rng", root).onchange = e => { range = +e.target.value; load(); };
  $("#auto", root).onchange = e => { clearInterval(timer); if (e.target.checked) timer = setInterval(load, 5000); };
  $("#csv", root).onclick = () => { if (!data) return; const rows = ["tag,timestamp_utc,avg,min,max"]; for (const [id, pts] of Object.entries(data.series)) for (const p of pts) rows.push(`${tagLabel(id)},${new Date(p[0] * 1000).toISOString()},${p[1]},${p[2]},${p[3]}`);
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([rows.join("\n")], { type: "text/csv" })); a.download = "trend.csv"; a.click(); };
  load(); return { destroy: () => clearInterval(timer) };
}

// ---------------- Alarms ----------------
export async function alarms(root) {
  let tab = "active";
  const stateChip = s => ({ active_unack: chip("Alarm", "ACTIVE - unacked"), active_ack: chip("high", "ACTIVE - acked"), cleared_unack: chip("medium", "RETURNED - unacked"), cleared: chip("ok", "Cleared") }[s]);
  async function draw() {
    root.innerHTML = `<div class="row"><h2 style="margin:0">Alarms</h2><span class="spacer"></span>${canOp() ? `<button id="ackall">Acknowledge all</button>` : ""}</div>
    <div class="tabs">${[["active", "Active"], ["history", "History"], ["defs", "Alarm settings"], ...(isAdmin() ? [["notif", "Notifications"]] : [])].map(([k, l]) => `<button data-tab="${k}" class="${tab === k ? "on" : ""}">${l}</button>`).join("")}</div><div id="body" class="card tablewrap"></div>`;
    const b = $("#body", root);
    if (tab === "active" || tab === "history") {
      const r = await api(`/alarms?state=${tab}&${siteQ()}`);
      b.innerHTML = `<table><tr><th>Raised</th><th>Priority</th><th>State</th><th>Alarm</th><th class="num">Value</th><th>Ack</th><th>Cleared</th><th></th></tr>${r.alarms.map(a => `<tr><td>${fmtTime(a.raised_at)}</td><td>${chip(a.priority)}</td><td>${stateChip(a.state)}</td><td>${esc(a.message)}</td><td class="num">${a.value == null ? "" : fmt(a.value)}</td><td>${a.ack_by ? esc(a.ack_by) + "<br><small>" + fmtTime(a.ack_at) + "</small>" : ""}</td><td>${fmtTime(a.cleared_at)}</td><td>${canOp() && a.state.endsWith("unack") ? `<button class="sm" data-ack="${a.id}">Ack</button>` : ""}</td></tr>`).join("") || `<tr><td colspan=8 class="muted">Nothing here</td></tr>`}</table>`;
    } else if (tab === "defs") {
      const r = await api("/alarm-defs?" + siteQ());
      b.innerHTML = `${isAdmin() ? `<div class="row"><button class="primary" id="adddef">+ Alarm limit</button></div>` : ""}<table><tr><th>Tag</th><th>Type</th><th class="num">Limit</th><th>Priority</th><th class="num">Deadband</th><th class="num">Delay</th><th>On</th><th></th></tr>${r.defs.map(d => `<tr><td>${esc(d.device_name)}.${esc(d.tag_name)}</td><td>${esc(d.kind.replace("_", " "))}</td><td class="num">${d.limit_val} ${esc(d.unit)}</td><td>${chip(d.priority)}</td><td class="num">${d.deadband}</td><td class="num">${d.delay_s}s</td><td>${d.enabled ? "yes" : "no"}</td><td class="right">${isAdmin() ? `<button class="sm" data-edit='${esc(JSON.stringify(d))}'>Edit</button> <button class="sm danger" data-deldef="${d.id}">x</button>` : ""}</td></tr>`).join("")}</table><p class="muted">Communication-loss alarms are created automatically for every device.</p>`;
    } else {
      const r = await api("/notifications");
      b.innerHTML = `<div class="note">Webhook notifications POST JSON (site, priority, message, value, ts) to your URL - usable with Slack/Teams/Telegram bridges, n8n, Node-RED. Browser pop-up/sound alerts are available per user in the top bar. Email/SMS are on the roadmap.</div>
      <div class="row"><input id="wh" placeholder="https://..." style="flex:1"><select id="mp" class="inline"><option>critical</option><option selected>high</option><option>medium</option><option>low</option></select><button class="primary" id="addwh">Add webhook</button></div>
      <table>${r.notifications.map(n => `<tr><td>${esc(n.target)}</td><td>min priority: ${chip(n.min_priority)}</td><td class="right"><button class="sm danger" data-delwh="${n.id}">x</button></td></tr>`).join("")}</table>`;
    }
  }
  function defForm(d) {
    modal({ title: d ? "Edit alarm limit" : "New alarm limit", html: `${d ? "" : `<label class="f">Tag<select name="tag_id">${vis(store.tags).map(t => `<option value="${t.id}">${esc(tagLabel(t.id))}</option>`).join("")}</select></label>`}
      <div class="two"><label class="f">Type<select name="kind">${["high_high", "high", "low", "low_low"].map(k => `<option ${d?.kind === k ? "selected" : ""}>${k}</option>`).join("")}</select></label><label class="f">Limit<input name="limit_val" type="number" step="any" required value="${d?.limit_val ?? ""}"></label>
      <label class="f">Priority<select name="priority">${["critical", "high", "medium", "low"].map(k => `<option ${d?.priority === k ? "selected" : ""}>${k}</option>`).join("")}</select></label><label class="f">Deadband<input name="deadband" type="number" step="any" value="${d?.deadband ?? 0}"></label>
      <label class="f">On-delay (s)<input name="delay_s" type="number" step="any" value="${d?.delay_s ?? 0}"></label><label class="f">Enabled<select name="enabled"><option value="1">yes</option><option value="0" ${d && !d.enabled ? "selected" : ""}>no</option></select></label></div>`,
      onSubmit: async f => { const body = { ...f, limit_val: +f.limit_val, deadband: +f.deadband, delay_s: +f.delay_s, enabled: +f.enabled }; if (d) await api("/alarm-defs/" + d.id, { method: "PUT", body }); else await api("/alarm-defs", { method: "POST", body: { ...body, tag_id: +f.tag_id } }); draw(); } });
  }
  root.onclick = async e => { const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.tab) { tab = b.dataset.tab; draw(); }
    if (b.dataset.ack) { await api(`/alarms/${b.dataset.ack}/ack`, { method: "POST" }); draw(); }
    if (b.id === "ackall") { const r = await api("/alarms/ack-all", { method: "POST" }); toast(`${r.acked} acknowledged`, "ok"); draw(); }
    if (b.id === "adddef") defForm(); if (b.dataset.edit) defForm(JSON.parse(b.dataset.edit));
    if (b.dataset.deldef && await confirmBox("Delete this alarm limit?", "Delete")) { await api("/alarm-defs/" + b.dataset.deldef, { method: "DELETE" }); draw(); }
    if (b.id === "addwh") { try { await api("/notifications", { method: "POST", body: { target: $("#wh", root).value, min_priority: $("#mp", root).value } }); draw(); } catch (err) { toast(err.message, "bad"); } }
    if (b.dataset.delwh) { await api("/notifications/" + b.dataset.delwh, { method: "DELETE" }); draw(); } };
  await draw(); return { update: () => {} };
}

// ---------------- Events / audit ----------------
export async function events(root) {
  let tab = "events";
  async function draw() {
    root.innerHTML = `<div class="row"><h2 style="margin:0">Event log</h2></div><div class="tabs"><button data-tab="events" class="${tab === "events" ? "on" : ""}">System events</button>${isAdmin() ? `<button data-tab="audit" class="${tab === "audit" ? "on" : ""}">Audit log</button>` : ""}</div><div class="card tablewrap" id="b"></div>`;
    if (tab === "events") { const r = await api("/events?limit=400&" + siteQ()); $("#b", root).innerHTML = `<table><tr><th>Time</th><th>Level</th><th>Category</th><th>Message</th></tr>${r.events.map(e => `<tr><td>${fmtTime(e.ts)}</td><td>${chip(e.level === "alarm" ? "Alarm" : e.level === "warning" ? "medium" : "low", e.level)}</td><td>${esc(e.category)}</td><td>${esc(e.message)}</td></tr>`).join("")}</table>`; }
    else { const r = await api("/audit?limit=500"); $("#b", root).innerHTML = `<table><tr><th>Time</th><th>User</th><th>IP</th><th>Action</th><th>Target</th><th>Detail</th><th>Result</th></tr>${r.audit.map(a => `<tr><td>${fmtTime(a.ts)}</td><td>${esc(a.username)}</td><td>${esc(a.ip)}</td><td>${esc(a.action)}</td><td>${esc(a.target)}</td><td>${esc(a.detail)}</td><td>${chip(a.result === "ok" ? "ok" : "Bad", a.result)}</td></tr>`).join("")}</table>`; }
  }
  root.onclick = e => { const b = e.target.closest("[data-tab]"); if (b) { tab = b.dataset.tab; draw(); } };
  await draw(); return {};
}

// ---------------- Reports ----------------
export async function reports(root) {
  const st = { kind: "energy", period: "day", days: 7 };
  root.innerHTML = `<h2>Reports</h2><div class="card"><div class="row">
    <label class="f inline">Report<select id="k"><option value="energy">Energy consumption &amp; production</option><option value="fuel">Generator fuel consumption</option><option value="alarms">Alarm history</option></select></label>
    <label class="f inline">Group by<select id="p"><option value="hour">Hourly</option><option value="day" selected>Daily</option><option value="month">Monthly</option><option value="year">Yearly</option></select></label>
    <label class="f inline">Range<select id="d"><option value="1">Last 24 h</option><option value="7" selected>Last 7 days</option><option value="30">Last 30 days</option><option value="365">Last 365 days</option></select></label>
    <button class="primary" id="run">Run report</button><button id="xlsx">Excel</button><button id="pdf">PDF</button></div><div id="out"></div></div>`;
  const qs = fmtx => `period=${$("#p", root).value}&from=${Date.now() / 1000 - $("#d", root).value * 86400}${fmtx ? "&format=" + fmtx : ""}&${siteQ()}`;
  async function run() {
    const r = await api(`/reports/${$("#k", root).value}?${qs()}`);
    $("#out", root).innerHTML = `<h3>${esc(r.title)}</h3><p class="muted">${esc(r.meta)}</p><div class="tablewrap"><table><tr>${r.columns.map(c => `<th>${esc(c)}</th>`).join("")}</tr>${r.rows.map(x => `<tr>${x.map(c => `<td class="${typeof c === "number" ? "num" : ""}">${c == null ? "" : esc(c)}</td>`).join("")}</tr>`).join("") || `<tr><td class="muted" colspan=${r.columns.length}>No data in range</td></tr>`}${r.totals ? `<tr>${r.totals.map(c => `<td class="${typeof c === "number" ? "num" : ""}"><b>${esc(c)}</b></td>`).join("")}</tr>` : ""}</table></div><div class="note">${esc(r.note || "")}</div>`;
  }
  root.onclick = async e => { const id = e.target.id; try { if (id === "run") await run(); if (id === "xlsx" || id === "pdf") await download(`/reports/${$("#k", root).value}?${qs(id)}`, `tbox-${$("#k", root).value}.${id}`); } catch (err) { toast(err.message, "bad"); } };
  run().catch(() => {}); return {};
}

// ---------------- Users ----------------
export async function users(root) {
  async function draw() {
    const r = await api("/users"); root.innerHTML = `<div class="row"><h2 style="margin:0">Users &amp; roles</h2><span class="spacer"></span><button class="primary" id="add">+ User</button></div>
    <div class="note"><b>admin</b>: configure everything. <b>operator</b>: view + acknowledge alarms (+ control only if "can control" is granted and the system is switched out of read-only mode). <b>viewer</b>: view only. Non-admins only see their assigned sites.</div>
    <div class="card tablewrap"><table><tr><th>User</th><th>Role</th><th>Control</th><th>Sites</th><th>Active</th><th>Last login</th><th></th></tr>${r.users.map(u => `<tr><td><b>${esc(u.username)}</b><br><small class="muted">${esc(u.full_name)}</small></td><td>${chip(u.role === "admin" ? "high" : u.role === "operator" ? "medium" : "low", u.role)}</td><td>${u.can_control ? "yes" : "no"}</td><td>${u.role === "admin" ? "all" : u.site_ids.map(i => esc((store.sites.find(s => s.id === i) || {}).name)).join(", ") || "none"}</td><td>${u.active ? "yes" : "no"}</td><td>${fmtTime(u.last_login)}</td><td class="right"><button class="sm" data-edit='${esc(JSON.stringify(u))}'>Edit</button> <button class="sm danger" data-del="${u.id}">x</button></td></tr>`).join("")}</table></div>`;
  }
  function form(u) {
    modal({ title: u ? "Edit " + u.username : "New user", html: `<div class="two">${u ? "" : `<label class="f">Username<input name="username" required></label>`}<label class="f">Full name<input name="full_name" value="${esc(u?.full_name)}"></label>
      <label class="f">${u ? "New password (blank = keep)" : "Password (min 8)"}<input name="password" type="password" ${u ? "" : "required"} minlength="8" autocomplete="new-password"></label>
      <label class="f">Role<select name="role">${["viewer", "operator", "admin"].map(r => `<option ${u?.role === r ? "selected" : ""}>${r}</option>`).join("")}</select></label>
      <label class="f">Can control<select name="can_control"><option value="0">no</option><option value="1" ${u?.can_control ? "selected" : ""}>yes</option></select></label>${u ? `<label class="f">Active<select name="active"><option value="1">yes</option><option value="0" ${u.active ? "" : "selected"}>no</option></select></label>` : ""}</div>
      <div class="muted">Sites</div><div class="picker">${store.sites.map(s => `<label><input type="checkbox" name="s_${s.id}" ${u?.site_ids.includes(s.id) ? "checked" : ""}>${esc(s.name)}</label>`).join("")}</div>`,
      onSubmit: async (f, c, form) => { const body = { full_name: f.full_name, role: f.role, can_control: +f.can_control, site_ids: store.sites.filter(s => form["s_" + s.id].checked).map(s => s.id) }; if (f.password) body.password = f.password; if (u) { body.active = +f.active; await api("/users/" + u.id, { method: "PUT", body }); } else await api("/users", { method: "POST", body: { ...body, username: f.username, password: f.password } }); draw(); } });
  }
  root.onclick = async e => { const b = e.target.closest("button"); if (!b) return; if (b.id === "add") form(); if (b.dataset.edit) form(JSON.parse(b.dataset.edit));
    if (b.dataset.del && await confirmBox("Delete this user?", "Delete")) { try { await api("/users/" + b.dataset.del, { method: "DELETE" }); draw(); } catch (err) { toast(err.message, "bad"); } } };
  await draw(); return {};
}
