export const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
export const fmt = (v, d) => v == null || Number.isNaN(v) ? "--" : Math.abs(v) >= 1000 ? v.toLocaleString(undefined, { maximumFractionDigits: 0 }) : (+v).toFixed(d ?? (Math.abs(v) >= 100 ? 1 : 2));
export const fmtTime = ts => ts ? new Date(ts * 1000).toLocaleString([], { hour12: false }) : "";
export const ago = ts => { if (!ts) return "never"; const s = Date.now() / 1000 - ts; return s < 90 ? Math.max(0, Math.round(s)) + "s ago" : s < 5400 ? Math.round(s / 60) + "m ago" : Math.round(s / 3600) + "h ago"; };
export const STATUS_LABEL = { Online: "Online", Offline: "Offline", Alarm: "Alarm", CommLost: "Communication Lost" };
export const chip = (cls, text) => `<span class="chip ${esc(cls)}">${esc(text ?? cls)}</span>`;
export const statusChip = s => chip(s, STATUS_LABEL[s] || s);
export const alarmClass = a => a ? "v-" + a : "";
export function toast(msg, kind = "info", ms = 4000) {
  const t = document.createElement("div"); t.className = "toast " + kind; t.textContent = msg; $("#toasts").appendChild(t); setTimeout(() => t.remove(), ms);
}
export function modal({ title, html, submit = "Save", onSubmit, wide }) {
  const o = document.createElement("div"); o.className = "overlay";
  o.innerHTML = `<form class="modal" ${wide ? 'style="width:min(860px,100%)"' : ""}><h2>${esc(title)}</h2><div class="body">${html}</div><div class="actions"><button type="button" class="cancel">Cancel</button>${onSubmit ? `<button class="primary">${esc(submit)}</button>` : ""}</div></form>`;
  document.body.appendChild(o); const close = () => o.remove(); $(".cancel", o).onclick = close; o.addEventListener("mousedown", e => { if (e.target === o) close(); });
  $("form", o).onsubmit = async e => {
    e.preventDefault(); if (!onSubmit) return; const btn = $(".primary", o); btn.disabled = true;
    try { if ((await onSubmit(Object.fromEntries(new FormData(e.target)), close, e.target)) !== false) close(); } catch (err) { toast(err.message, "bad", 6000); }
    btn.disabled = false;
  };
  return { close, el: o };
}
export const confirmBox = (msg, label = "Confirm") => new Promise(res => { let done = false; const m = modal({ title: "Please confirm", html: `<p>${esc(msg)}</p>`, submit: label, onSubmit: () => { done = true; res(true); } }); m.el.addEventListener("remove", () => 0); new MutationObserver((_, ob) => { if (!document.body.contains(m.el)) { ob.disconnect(); if (!done) res(false); } }).observe(document.body, { childList: true }); });
export const opts = (items, sel, val = x => x.id, lab = x => x.name) => items.map(x => `<option value="${esc(val(x))}" ${String(val(x)) === String(sel) ? "selected" : ""}>${esc(lab(x))}</option>`).join("");
