import { api, store, siteQ, tagLabel, liveVal, loadMeta, download } from "./api.js";
import { esc, $, $$, fmt, ago, fmtTime, statusChip, chip, toast, modal, opts, confirmBox, alarmClass, STATUS_LABEL } from "./ui.js";
import { lineChart, gaugeSvg, COLORS } from "./charts.js";

const isAdmin = () => store.user && store.user.role === "admin";
const canOp = () => store.user && store.user.role !== "viewer";
const vis = a => a.filter(x => store.siteId === "all" || x.site_id == store.siteId);
const sumRole = role => { let s = 0, n = 0; vis(store.tags).filter(t => t.role === role).forEach(t => { const v = liveVal(t.id); if (v && v[0] != null && v[2] === "Good") { s += v[0]; n++; } }); return n ? s : null; };
const kpi = (l, v, u = "", cls = "") => `<div class="card kpi"><div class="l">${l}</div><div class="v ${cls}">${v}<span class="u">${u}</span></div></div>`;
const tagName = n => n.replaceAll("_", " ");

export async function dashboard(root) {
  root.innerHTML = `<div class="grid kpis" id="kpis"></div><div class="cols"><div><h3>Equipment</h3><div class="grid devgrid" id="devs"></div>
  <div class="card" style="margin-top:12px"><h3>Power - last hour (kW)</h3><canvas class="chart" id="pw"></canvas></div></div>
  <div><div class="card"><h3>Active alarms</h3><div id="al"></div></div><div class="card" style="margin-top:12px"><h3>Recent events</h3><div id="ev"></div></div></div></div>`;
  let fuel = null;
  async function slow() {
    try {
      const [al, ev, fu] = await Promise.all([api("/alarms?state=active&limit=8&" + siteQ()), api("/events?limit=10&" + siteQ()), api("/reports/fuel?period=day&from=" + (Date.now() / 1000 - 86400) + "&" + siteQ())]);
      fuel = fu.totals ? fu.totals[2] : null;
      $("#al", root).innerHTML = al.alarms.length ? al.alarms.map(a => `<div class="kv"><span>${chip(a.priority)} ${esc(a.message)}<br><small class="muted">${fmtTime(a.raised_at)} ${a.state.includes("cleared") ? "(returned to normal)" : ""}</small></span>${a.state.endsWith("unack") && canOp() ? `<button class="sm" data-ack="${a.id}">Ack</button>` : ""}</div>`).join("") : `<span class="muted">No active alarms</span>`;
      $("#ev", root).innerHTML = ev.events.map(e => `<div class="kv"><span>${esc(e.message)}</span><small class="muted">${new Date(e.ts * 1000).toLocaleTimeString([], { hour12: false })}</small></div>`).join("") || `<span class="muted">No events</span>`;
      const pt = vis(store.tags).filter(t => ["gen_kw", "pv_kw", "grid_kw"].includes(t.role)).slice(0, 8);
      if (pt.length) { const h = await api(`/history?tags=${pt.map(t => t.id).join(",")}&from=${Date.now() / 1000 - 3600}&max_points=150`); lineChart($("#pw", root), pt.map((t, i) => ({ name: tagLabel(t.id), unit: "kW", color: COLORS[i], pts: h.series[t.id] || [] }))); }
    } catch (e) { console.warn(e); }
  }
  root.addEventListener("click", async e => { const b = e.target.closest("[data-ack]"); if (b) { await api(`/alarms/${b.dataset.ack}/ack`, { method: "POST" }); slow(); } const c = e.target.closest("[data-dev]"); if (c) location.hash = "#/device/" + c.dataset.dev; });
  function update(live) {
    const cnt = s => live.devices.filter(d => d.status === s).length, pw = sumRole("gen_kw"), pv = sumRole("pv_kw"), gr = sumRole("grid_kw"), fr = sumRole("fuel_rate_lph");
    $("#kpis", root).innerHTML = kpi("Equipment", `<span class="v-bad" style="color:var(--ok)">${cnt("Online")}</span>/${live.devices.length}`, "online") +
      kpi("Alarm / Comm lost / Offline", `<span style="color:var(--bad)">${cnt("Alarm")}</span> / <span style="color:var(--comm)">${cnt("CommLost")}</span> / ${cnt("Offline")}`) +
      kpi("Unacknowledged alarms", live.alarms.unack, "", live.alarms.unack ? "v-high_high" : "") + kpi("Generators", fmt(pw, 0), "kW") + kpi("Solar", fmt(pv, 0), "kW") + kpi("Grid import", fmt(gr, 0), "kW") +
      kpi("Fuel rate", fmt(fr, 1), "L/h") + kpi("Fuel used (24 h)", fmt(fuel, 0), "L");
    $("#devs", root).innerHTML = live.devices.map(d => { const feats = store.tags.filter(t => t.device_id === d.id && t.featured);
      return `<div class="card dev ${d.status}" data-dev="${d.id}"><div class="row" style="margin:0 0 6px"><span class="n">${esc(d.name)}</span><span class="spacer"></span>${statusChip(d.status)}</div>
      ${feats.map(t => { const v = liveVal(t.id); return `<div class="kv"><span class="muted">${esc(tagName(t.name))}</span><b class="${v ? alarmClass(v[3]) : ""} ${v && v[2] !== "Good" ? "v-bad" : ""}">${v ? fmt(v[0]) : "--"} ${esc(t.unit)}</b></div>`; }).join("")}
      ${vis([d]).length && store.sites.length > 1 && store.siteId === "all" ? `<small class="muted">${esc((store.sites.find(s => s.id === d.site_id) || {}).name)}</small>` : ""}</div>`; }).join("");
  }
  slow(); const timer = setInterval(slow, 15000); if (store.live) update(store.live);
  return { update, destroy: () => clearInterval(timer) };
}

export async function deviceDetail(root, id) {
  const dev = store.devices.find(d => d.id == id); if (!dev) { root.innerHTML = `<div class="card">Device not found</div>`; return {}; }
  const tags = store.tags.filter(t => t.device_id == id), gtags = tags.filter(t => t.featured && t.min_val != null && t.max_val != null && t.data_type !== "bool").slice(0, 6);
  root.innerHTML = `<div class="row"><a href="#/">&larr; Dashboard</a><h2 style="margin:0">${esc(dev.name)}</h2><span id="st"></span><span class="muted">${esc(dev.description)}</span></div>
  <div class="card"><div class="gauges" id="gg"></div></div><div class="cols" style="margin-top:12px"><div class="card"><h3>Trend (30 min)</h3><canvas class="chart" id="tr"></canvas></div>
  <div class="card"><h3>All tags</h3><div class="tablewrap"><table id="tt"></table></div></div></div>`;
  const ft = tags.filter(t => t.featured || t.role).slice(0, 4);
  if (ft.length) { const h = await api(`/history?tags=${ft.map(t => t.id).join(",")}&from=${Date.now() / 1000 - 1800}&max_points=200`); lineChart($("#tr", root), ft.map((t, i) => ({ name: t.name, unit: t.unit, color: COLORS[i], pts: h.series[t.id] || [] }))); }
  function update(live) {
    const d = live.devices.find(x => x.id == id); if (d) $("#st", root).innerHTML = statusChip(d.status);
    $("#gg", root).innerHTML = gtags.map(t => { const v = liveVal(t.id) || []; return `<div class="gauge">${gaugeSvg({ value: v[0], min: t.min_val, max: t.max_val, unit: t.unit, label: tagName(t.name), alarm: v[3], quality: v[2] || "Bad" })}</div>`; }).join("") || `<span class="muted">No gauge tags (set min/max on featured tags)</span>`;
    $("#tt", root).innerHTML = `<tr><th>Tag</th><th class="num">Value</th><th>Quality</th></tr>` + tags.map(t => { const v = liveVal(t.id); return `<tr><td>${esc(t.name)}<br><small class="muted">${esc(t.description)}</small></td><td class="num ${v ? alarmClass(v[3]) : ""}"><b>${v ? fmt(v[0]) : "--"}</b> ${esc(t.unit)}</td><td>${v ? chip(v[2]) : ""}</td></tr>`; }).join("");
  }
  if (store.live) update(store.live); return { update };
}

// ---------------- Device manager ----------------
let DRV = null;
const paramFields = (kind, p = {}) => ((DRV.drivers[kind] || {}).params || []).map(f => `<label class="f">${esc(f.label)}<input name="p_${f.key}" type="${f.type}" step="any" value="${esc(p[f.key] ?? f.default ?? "")}"></label>`).join("");
export async function devices(root) {
  DRV = DRV || await api("/drivers"); let list = [];
  async function load() { list = (await api("/devices?" + siteQ())).devices; await loadMeta(); draw(); }
  function draw() {
    root.innerHTML = `<div class="row"><h2 style="margin:0">Device manager</h2><span class="spacer"></span>${isAdmin() ? `<button class="primary" id="add">+ Add device</button>` : ""}</div>
    <div class="note">Devices are polled by the <b>edge gateway</b> at each site, never by this server. Only drivers marked <b>implemented</b> talk to hardware; see docs/DRIVERS.md.</div>
    <div class="card tablewrap"><table><tr><th>Device</th><th>Site</th><th>Driver</th><th>Status</th><th class="num">Poll</th><th class="num">Tags</th><th>Last data</th><th></th></tr>
    ${list.map(d => `<tr><td><a href="#/device/${d.id}"><b>${esc(d.name)}</b></a><br><small class="muted">${esc(d.description)}</small></td><td>${esc((store.sites.find(s => s.id === d.site_id) || {}).name)}</td>
    <td>${esc((DRV.drivers[d.kind] || {}).name || d.kind)}${d.profile ? `<br><small class="muted">${esc(d.profile)}</small>` : ""}</td><td>${statusChip(d.status)}${d.last_error && d.status === "CommLost" ? `<br><small class="muted">${esc(d.last_error)}</small>` : ""}</td>
    <td class="num">${d.poll_ms} ms</td><td class="num">${d.tag_count}</td><td>${ago(d.last_seen)}</td><td class="right">${isAdmin() ? `<button class="sm" data-edit="${d.id}">Edit</button> <button class="sm danger" data-del="${d.id}">Remove</button>` : ""}</td></tr>`).join("")}</table></div>`;
  }
  function form(d) {
    const kinds = Object.entries(DRV.drivers); const k = d ? d.kind : "simulator";
    const m = modal({ title: d ? "Edit device " + d.name : "Add device", wide: true, html: `<div class="two"><label class="f">Site<select name="site_id" ${d ? "disabled" : ""}>${opts(store.sites, d ? d.site_id : store.siteId !== "all" ? store.siteId : "")}</select></label>
      <label class="f">Name<input name="name" required value="${esc(d?.name)}"></label></div><label class="f">Description<input name="description" value="${esc(d?.description)}"></label>
      <div class="two"><label class="f">Driver<select name="kind" id="kind" ${d ? "disabled" : ""}>${kinds.map(([id, x]) => `<option value="${id}" ${id === k ? "selected" : ""}>${esc(x.name)} [${x.status}]</option>`).join("")}</select></label>
      <label class="f">Polling interval (ms)<input name="poll_ms" type="number" min="100" value="${d?.poll_ms ?? 1000}"></label></div>
      <label class="f" id="profwrap">Simulator profile (creates a tag template)<select name="profile">${Object.entries(DRV.profiles).map(([id, n]) => `<option value="${id}" ${d?.profile === id ? "selected" : ""}>${esc(n)}</option>`).join("")}</select></label>
      <div id="params" class="two">${paramFields(k, d?.params)}</div><div class="note warn" id="req"></div>
      <label class="f"><input type="checkbox" name="enabled" class="inline" ${d?.enabled !== 0 ? "checked" : ""}> Enabled (disabled devices show as Offline and are not polled)</label>`,
      onSubmit: async (f, close, form) => {
        const params = {}; for (const [k2, v] of Object.entries(f)) if (k2.startsWith("p_")) params[k2.slice(2)] = isNaN(v) || v === "" ? v : Number(v);
        const body = { name: f.name, description: f.description, poll_ms: +f.poll_ms, params, enabled: form.enabled.checked ? 1 : 0 };
        if (d) await api("/devices/" + d.id, { method: "PUT", body }); else { const r = await api("/devices", { method: "POST", body: { ...body, site_id: +f.site_id, kind: f.kind, profile: f.kind === "simulator" ? f.profile : "" } }); toast(`Device added (${r.tags_created} tags from template)`, "ok"); }
        await load();
      } });
    const sync = () => { const kind = $("#kind", m.el).value, x = DRV.drivers[kind]; $("#profwrap", m.el).style.display = kind === "simulator" && !d ? "" : "none"; if (!d) $("#params", m.el).innerHTML = paramFields(kind);
      $("#req", m.el).innerHTML = `<b>${esc(x.name)}</b> - status: <b>${esc(x.status)}</b><br>${esc(x.requirements)}`; };
    $("#kind", m.el).onchange = sync; sync();
  }
  root.onclick = async e => { const b = e.target.closest("button"); if (!b) return;
    if (b.id === "add") form(); if (b.dataset.edit) form(list.find(d => d.id == b.dataset.edit));
    if (b.dataset.del && await confirmBox("Remove this device and all its tags, alarms and history?", "Remove")) { await api("/devices/" + b.dataset.del, { method: "DELETE" }); toast("Device removed", "ok"); load(); } };
  await load(); return { update: () => {} };
}

// ---------------- Tag manager ----------------
const DT = ["bool", "int16", "uint16", "int32", "uint32", "float32"], RT = ["holding", "input", "coil", "discrete", "sim"];
export async function tags(root) {
  let devFilter = "", q = "";
  const draw = () => {
    const list = vis(store.tags).filter(t => (!devFilter || t.device_id == devFilter) && (!q || (t.name + t.description + t.device_name).toLowerCase().includes(q)));
    $("#tb", root).innerHTML = list.map(t => { const v = liveVal(t.id); return `<tr><td><b>${esc(t.device_name)}.${esc(t.name)}</b><br><small class="muted">${esc(t.description)}</small></td><td>${esc(t.address)}<br><small class="muted">${esc(t.reg_type)} / ${esc(t.data_type)}</small></td>
      <td>${esc(t.unit)}</td><td class="num">x${t.scale} +${t.offset}</td><td>${t.min_val ?? ""}${t.min_val != null || t.max_val != null ? " .. " : ""}${t.max_val ?? ""}</td><td>${t.access === "write" ? chip("high", "WRITE") : "read"}</td>
      <td class="num ${v ? alarmClass(v[3]) : ""}"><b>${v ? fmt(v[0]) : "--"}</b></td><td>${v ? chip(v[2]) : chip("Bad", "No data")}</td><td class="right">${isAdmin() ? `<button class="sm" data-edit="${t.id}">Edit</button> <button class="sm danger" data-del="${t.id}">x</button>` : ""}</td></tr>`; }).join("");
    $("#cnt", root).textContent = list.length + " tags";
  };
  root.innerHTML = `<div class="row"><h2 style="margin:0">Tag manager</h2><span class="spacer"></span><span id="cnt" class="muted"></span>
    <select id="df" class="inline"><option value="">All devices</option>${opts(vis(store.devices), "")}</select><input id="q" placeholder="Search..." class="inline" style="width:160px">
    ${isAdmin() ? `<button id="add" class="primary">+ Tag</button><button id="imp">Import CSV</button><input type="file" id="file" accept=".csv" hidden>` : ""}<button id="exp">Export CSV</button></div>
    <div class="card tablewrap"><table><thead><tr><th>Tag</th><th>Address</th><th>Unit</th><th>Scaling</th><th>Limits</th><th>Access</th><th class="num">Value</th><th>Quality</th><th></th></tr></thead><tbody id="tb"></tbody></table></div>`;
  function form(t) {
    const f = (n, l, type = "text", extra = "") => `<label class="f">${l}<input name="${n}" type="${type}" step="any" value="${esc(t?.[n] ?? "")}" ${extra}></label>`;
    modal({ title: t ? "Edit tag" : "New tag", wide: true, html: `<div class="two"><label class="f">Device<select name="device_id" ${t ? "disabled" : ""}>${opts(vis(store.devices), t?.device_id, d => d.id, d => d.name)}</select></label>${f("name", "Tag name", "text", "required")}</div>
      ${f("description", "Description")}<div class="two">${f("address", "Register address (0-based; sim:<signal> for simulator)", "text", "required")}<label class="f">Register type<select name="reg_type">${RT.map(x => `<option ${x === (t?.reg_type || "holding") ? "selected" : ""}>${x}</option>`).join("")}</select></label>
      <label class="f">Data type<select name="data_type">${DT.map(x => `<option ${x === (t?.data_type || "float32") ? "selected" : ""}>${x}</option>`).join("")}</select></label><label class="f">32-bit word order<select name="word_order"><option ${t?.word_order !== "little" ? "selected" : ""}>big</option><option ${t?.word_order === "little" ? "selected" : ""}>little</option></select></label>
      ${f("scale", "Scale (value = raw x scale + offset)", "number")}${f("offset", "Offset", "number")}${f("unit", "Engineering unit")}${f("log_interval_s", "Logging interval (s, min 1)", "number")}${f("min_val", "Min limit", "number")}${f("max_val", "Max limit", "number")}
      <label class="f">Access<select name="access"><option value="read" ${t?.access !== "write" ? "selected" : ""}>read-only</option><option value="write" ${t?.access === "write" ? "selected" : ""}>authorized write</option></select></label>${f("role", "Report role (e.g. fuel_level_l, energy_import_kwh)")}</div>
      <div class="note">Write access only takes effect when the server runs with TBOX_COMMANDS_ENABLED=true, the edge allows writes, and the driver supports writes. Default: monitoring only.</div>`,
      onSubmit: async f2 => { const b = { ...f2 }; if (t) delete b.device_id; if (t) await api("/tags/" + t.id, { method: "PUT", body: b }); else await api("/tags", { method: "POST", body: b }); await loadMeta(); draw(); } });
  }
  draw(); $("#df", root).onchange = e => { devFilter = e.target.value; draw(); }; $("#q", root).oninput = e => { q = e.target.value.toLowerCase(); draw(); };
  root.onclick = async e => { const b = e.target.closest("button"); if (!b) return;
    if (b.id === "add") form(); if (b.dataset.edit) form(store.tagMap[b.dataset.edit]);
    if (b.dataset.del && await confirmBox("Delete tag and its history?", "Delete")) { await api("/tags/" + b.dataset.del, { method: "DELETE" }); await loadMeta(); draw(); }
    if (b.id === "exp") download("/tags/export.csv?" + siteQ(devFilter ? "device_id=" + devFilter : ""), "tags.csv").catch(err => toast(err.message, "bad"));
    if (b.id === "imp") { if (!devFilter) return toast("Select a device in the filter first - tags are imported into that device", "bad"); $("#file", root).click(); } };
  const file = $("#file", root); if (file) file.onchange = async () => { const r = await api("/tags/import", { method: "POST", body: { device_id: +devFilter, csv: await file.files[0].text() } }); file.value = ""; await loadMeta(); draw();
    toast(`Imported: ${r.added} added, ${r.updated} updated, ${r.errors.length} errors`, r.errors.length ? "bad" : "ok", 7000); if (r.errors.length) modal({ title: "Import errors", html: `<pre>${esc(r.errors.join("\n"))}</pre>` }); };
  return { update: draw };
}
