const TK = "tbox_token";
export const store = { user: null, commands: false, sites: [], siteId: "all", devices: [], tags: [], tagMap: {}, live: null, listeners: new Set() };
export const getToken = () => localStorage.getItem(TK);
export const setToken = t => t ? localStorage.setItem(TK, t) : localStorage.removeItem(TK);

export async function api(path, { method = "GET", body, raw } = {}) {
  const r = await fetch("/api" + path, { method, headers: { ...(getToken() ? { Authorization: "Bearer " + getToken() } : {}), ...(body ? { "Content-Type": "application/json" } : {}) }, body: body ? JSON.stringify(body) : undefined });
  if (r.status === 401 && !path.startsWith("/auth/login")) { setToken(null); location.hash = "#/login"; throw new Error("Session expired"); }
  if (raw) { if (!r.ok) throw new Error((await r.json().catch(() => ({}))).message || r.statusText); return r; }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(j.message || j.error || r.statusText), { status: r.status, code: j.error });
  return j;
}
export async function download(path, filename) {
  const b = await (await api(path, { raw: true })).blob(); const a = document.createElement("a");
  a.href = URL.createObjectURL(b); a.download = filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
export const siteQ = (extra = "") => (store.siteId === "all" ? "" : "site_id=" + store.siteId) + (extra ? (store.siteId === "all" ? "" : "&") + extra : "");
export async function loadMeta() {
  const [s, t, d] = await Promise.all([api("/sites"), api("/tags"), api("/devices")]);
  store.sites = s.sites; store.tags = t.tags; store.devices = d.devices; store.tagMap = Object.fromEntries(t.tags.map(x => [x.id, x]));
}
export async function pollLive() {
  store.live = await api("/live" + (store.siteId === "all" ? "" : "?site_id=" + store.siteId));
  store.listeners.forEach(f => { try { f(store.live); } catch (e) { console.error(e); } });
}
export const tagLabel = id => { const t = store.tagMap[id]; return t ? `${t.device_name}.${t.name}` : "#" + id; };
export const liveVal = id => (store.live && store.live.tags[id]) || null;
