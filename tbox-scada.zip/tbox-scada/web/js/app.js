import { api, store, getToken, setToken, loadMeta, pollLive } from "./api.js";
import { esc, $, $$, toast, modal } from "./ui.js";
import * as P1 from "./pages1.js";
import * as P2 from "./pages2.js";
import * as H from "./hmi.js";

const app = $("#app");
let page = null, token = 0, lastUnack = null, timer = null;
const theme = localStorage.getItem("tbox_theme") || "dark"; document.documentElement.dataset.theme = theme;
const NAV = [["#/", "Dashboard", "\u25A6"], ["#/hmi", "SCADA screens", "\u25A3"], ["#/devices", "Devices", "\u2699"], ["#/tags", "Tags", "\u2630"], ["#/trends", "Trends", "\u223F"], ["#/alarms", "Alarms", "\u26A0"], ["#/events", "Events", "\u2261"], ["#/reports", "Reports", "\u25A4"], ["#/users", "Users", "\u263A", true]];
const beep = () => { try { const c = new AudioContext(), o = c.createOscillator(); o.frequency.value = 880; o.connect(c.destination); o.start(); setTimeout(() => { o.stop(); c.close(); }, 250); } catch { } };

function loginView() {
  app.innerHTML = `<form class="card login" style="margin:auto"><div class="brand"><img src="icon.svg" alt=""><div>TBox SCADA<small>Technical Power Systems</small></div></div>
  <label class="f">Username<input name="u" autocomplete="username" required autofocus></label><label class="f">Password<input name="p" type="password" autocomplete="current-password" required></label><button class="primary" style="width:100%">Sign in</button><p id="err" style="color:var(--bad)"></p></form>`;
  $("form", app).onsubmit = async e => { e.preventDefault(); try { const r = await api("/auth/login", { method: "POST", body: { username: e.target.u.value, password: e.target.p.value } }); setToken(r.token); location.hash = "#/"; boot(); } catch (err) { $("#err", app).textContent = err.message; } };
}

function shell() {
  const admin = store.user.role === "admin";
  app.innerHTML = `<div class="topbar"><button class="menu-btn" id="menu">\u2630</button><div class="brand"><img src="icon.svg" alt=""><div>TBox SCADA<small>Technical Power Systems</small></div></div><span class="spacer"></span>
  <span class="mode" title="${store.commands ? "Control commands are enabled on the server" : "No control commands can be issued"}" style="${store.commands ? "color:var(--warn);border-color:var(--warn)" : ""}">${store.commands ? "CONTROL ENABLED" : "READ-ONLY"}</span>
  <select id="site" class="inline" style="max-width:190px"><option value="all">All sites</option>${store.sites.map(s => `<option value="${s.id}" ${s.id == store.siteId ? "selected" : ""}>${esc(s.name)}${s.edge_online ? "" : " (edge offline)"}</option>`).join("")}</select>
  <a href="#/alarms" title="Unacknowledged alarms"><span class="badge zero" id="bell">0</span></a><button id="snd" title="Browser alerts and sound">\uD83D\uDD14</button><button id="th" title="Dark / light">\u25D0</button><span class="muted" style="font-size:12px">${esc(store.user.username)} (${store.user.role})</span><button id="out">Sign out</button></div>
  <div class="layout"><nav class="side" id="side">${NAV.filter(n => !n[3] || admin).map(n => `<a href="${n[0]}" data-nav="${n[0]}"><span>${n[2]}</span>${n[1]}</a>`).join("")}</nav><main class="main" id="main"></main></div>`;
  $("#site").onchange = async e => { store.siteId = e.target.value; localStorage.setItem("tbox_site", store.siteId); await pollLive(); route(); };
  $("#th").onclick = () => { const t = document.documentElement.dataset.theme === "dark" ? "light" : "dark"; document.documentElement.dataset.theme = t; localStorage.setItem("tbox_theme", t); route(); };
  $("#out").onclick = async () => { try { await api("/auth/logout", { method: "POST" }); } catch { } setToken(null); clearInterval(timer); location.hash = "#/login"; boot(); };
  $("#menu").onclick = () => $("#side").classList.toggle("open"); $("#side").onclick = () => $("#side").classList.remove("open");
  $("#snd").onclick = async () => { if ("Notification" in window) await Notification.requestPermission(); localStorage.setItem("tbox_snd", "1"); toast("Browser alerts and sound enabled for new alarms", "ok"); beep(); };
}

async function route() {
  if (!getToken()) return loginView();
  if (!$("#main")) return;
  const h = location.hash || "#/", seg = h.split("/").filter(Boolean); const my = ++token;
  $$("[data-nav]").forEach(a => a.classList.toggle("active", h === a.dataset.nav || (a.dataset.nav !== "#/" && h.startsWith(a.dataset.nav))));
  if (page && page.destroy) page.destroy(); page = null; const root = $("#main"); root.innerHTML = ""; root.onclick = null;
  try {
    let p;
    if (h === "#/" || h === "#/login" || h === "#") p = await P1.dashboard(root);
    else if (seg[1] === "device") p = await P1.deviceDetail(root, seg[2]);
    else if (seg[1] === "devices") p = await P1.devices(root);
    else if (seg[1] === "tags") p = await P1.tags(root);
    else if (seg[1] === "trends") p = await P2.trends(root);
    else if (seg[1] === "alarms") p = await P2.alarms(root);
    else if (seg[1] === "events") p = await P2.events(root);
    else if (seg[1] === "reports") p = await P2.reports(root);
    else if (seg[1] === "users") p = await P2.users(root);
    else if (seg[1] === "hmi") p = seg[3] === "edit" ? await H.screenEdit(root, seg[2]) : seg[2] ? await H.screenView(root, seg[2]) : await H.screens(root);
    else root.innerHTML = `<div class="card">Page not found</div>`;
    if (my !== token) { p && p.destroy && p.destroy(); return; } page = p || {};
  } catch (e) { if (my === token) root.innerHTML = `<div class="card"><b>Error:</b> ${esc(e.message)}</div>`; }
}

function onLive(live) {
  const b = $("#bell"); if (b) { b.textContent = live.alarms.unack; b.classList.toggle("zero", !live.alarms.unack); }
  if (lastUnack != null && live.alarms.unack > lastUnack) { toast(`New alarm (${live.alarms.unack} unacknowledged)`, "bad", 6000); if (localStorage.getItem("tbox_snd")) { beep(); if (window.Notification && Notification.permission === "granted") new Notification("TBox SCADA alarm", { body: `${live.alarms.unack} unacknowledged alarm(s)` }); } }
  lastUnack = live.alarms.unack; if (page && page.update) page.update(live);
}

async function boot() {
  clearInterval(timer);
  if (!getToken()) return loginView();
  try {
    const me = await api("/auth/me"); store.user = me.user; store.commands = me.commands_enabled; await loadMeta();
    const saved = localStorage.getItem("tbox_site"); store.siteId = saved && (saved === "all" || store.sites.some(s => s.id == saved)) ? saved : "all";
    shell(); store.listeners.clear(); store.listeners.add(onLive); await pollLive(); route();
    timer = setInterval(() => { if (!document.hidden) pollLive().catch(e => { if (!getToken()) return; $("#bell") && ($("#bell").textContent = "!"); }); }, 2000);
  } catch (e) { loginView(); }
}
window.addEventListener("hashchange", () => { if (getToken() && $("#main")) route(); else if (!getToken()) loginView(); });
boot();
