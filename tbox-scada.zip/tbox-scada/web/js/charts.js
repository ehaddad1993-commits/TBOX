import { esc, fmt } from "./ui.js";
export const COLORS = ["#3ea6ff", "#f5a623", "#30a46c", "#e5484d", "#a78bfa", "#2dd4bf", "#f472b6", "#a3e635"];
const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();

/** Interactive line chart on canvas. series: [{name,color,unit,pts:[[t,avg,min,max],...]}] */
export function lineChart(canvas, series, { height = 300 } = {}) {
  const dpr = window.devicePixelRatio || 1, W = canvas.clientWidth, H = height; canvas.width = W * dpr; canvas.height = H * dpr; canvas.style.height = H + "px";
  const g = canvas.getContext("2d"); g.scale(dpr, dpr); const L = 52, R = 10, T = 10, B = 24;
  const all = series.flatMap(s => s.pts); g.clearRect(0, 0, W, H);
  const draw = hover => {
    g.clearRect(0, 0, W, H); g.font = "11px system-ui"; g.fillStyle = css("--muted"); g.strokeStyle = css("--line");
    if (!all.length) { g.fillText("No data in this range", W / 2 - 50, H / 2); return; }
    let t0 = Math.min(...all.map(p => p[0])), t1 = Math.max(...all.map(p => p[0])), lo = Math.min(...all.map(p => p[2] ?? p[1])), hi = Math.max(...all.map(p => p[3] ?? p[1]));
    if (hi === lo) { hi += 1; lo -= 1; } const pad = (hi - lo) * .08; lo -= pad; hi += pad; if (t1 === t0) t1 += 1;
    const X = t => L + (t - t0) / (t1 - t0) * (W - L - R), Y = v => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
    for (let i = 0; i <= 4; i++) { const y = T + i * (H - T - B) / 4; g.beginPath(); g.moveTo(L, y); g.lineTo(W - R, y); g.stroke(); g.fillText(fmt(hi - i * (hi - lo) / 4), 4, y + 4); }
    for (let i = 0; i <= 5; i++) { const t = t0 + i * (t1 - t0) / 5, d = new Date(t * 1000); g.fillText((t1 - t0 > 86400 * 2 ? d.toLocaleDateString([], { month: "short", day: "numeric" }) + " " : "") + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false }), X(t) - 18, H - 7); }
    series.forEach((s, i) => { g.strokeStyle = s.color || COLORS[i % 8]; g.lineWidth = 1.8; g.beginPath(); s.pts.forEach((p, k) => k ? g.lineTo(X(p[0]), Y(p[1])) : g.moveTo(X(p[0]), Y(p[1]))); g.stroke(); });
    if (hover != null) {
      const t = t0 + (hover - L) / (W - L - R) * (t1 - t0); g.strokeStyle = css("--muted"); g.beginPath(); g.moveTo(hover, T); g.lineTo(hover, H - B); g.stroke();
      const rows = series.map((s, i) => { const p = s.pts.reduce((a, b) => Math.abs(b[0] - t) < Math.abs(a[0] - t) ? b : a, s.pts[0] || [0, null]); return [s.color || COLORS[i % 8], `${s.name}: ${fmt(p[1])} ${s.unit || ""}`, p[0]]; }).filter(r => r[2]);
      if (rows.length) { const w = Math.max(...rows.map(r => g.measureText(r[1]).width)) + 22, h = rows.length * 15 + 22, x = hover > W / 2 ? hover - w - 8 : hover + 8;
        g.fillStyle = css("--panel"); g.strokeStyle = css("--line"); g.fillRect(x, T + 4, w, h); g.strokeRect(x, T + 4, w, h); g.fillStyle = css("--muted"); g.fillText(new Date(rows[0][2] * 1000).toLocaleString([], { hour12: false }), x + 6, T + 18);
        rows.forEach((r, i) => { g.fillStyle = r[0]; g.fillRect(x + 6, T + 26 + i * 15, 8, 8); g.fillStyle = css("--text"); g.fillText(r[1], x + 18, T + 34 + i * 15); }); }
    }
  };
  const move = e => { const r = canvas.getBoundingClientRect(), x = (e.touches ? e.touches[0].clientX : e.clientX) - r.left; draw(x); };
  canvas.onmousemove = move; canvas.ontouchmove = move; canvas.onmouseleave = () => draw(); draw();
}

export function sparkline(values, w = 120, h = 30, color = "#3ea6ff") {
  if (values.length < 2) return ""; const lo = Math.min(...values), hi = Math.max(...values), r = hi - lo || 1;
  return `<svg width="${w}" height="${h}"><polyline fill="none" stroke="${color}" stroke-width="1.5" points="${values.map((v, i) => `${(i / (values.length - 1) * w).toFixed(1)},${(h - 2 - (v - lo) / r * (h - 4)).toFixed(1)}`).join(" ")}"/></svg>`;
}

export const STATE_COLOR = (alarm, quality) => quality === "Bad" || quality === "Stale" ? "#6b7280" : alarm === "high_high" || alarm === "low_low" ? "#e5484d" : alarm === "high" || alarm === "low" ? "#f5a623" : "#30a46c";

/** Semi-circular SVG gauge. */
export function gaugeSvg({ value, min = 0, max = 100, unit = "", label = "", alarm = null, quality = "Good", size = 170 }) {
  const r = 62, cx = 85, cy = 85, a = f => Math.PI * (1 - f), pt = f => [cx + r * Math.cos(a(f)), cy - r * Math.sin(a(f))];
  const f = value == null ? 0 : Math.max(0, Math.min(1, (value - min) / ((max - min) || 1))), col = STATE_COLOR(alarm, quality), [x0, y0] = pt(0), [x1, y1] = pt(1), [xv, yv] = pt(f);
  return `<svg viewBox="0 0 170 120" width="${size}"><path d="M${x0} ${y0} A${r} ${r} 0 0 1 ${x1} ${y1}" fill="none" stroke="var(--line)" stroke-width="12" stroke-linecap="round"/>
  ${value == null ? "" : `<path d="M${x0} ${y0} A${r} ${r} 0 0 1 ${xv} ${yv}" fill="none" stroke="${col}" stroke-width="12" stroke-linecap="round"/>`}
  <text x="${cx}" y="${cy - 8}" text-anchor="middle" font-size="22" font-weight="700" fill="var(--text)">${fmt(value)}</text><text x="${cx}" y="${cy + 10}" text-anchor="middle" font-size="11" fill="var(--muted)">${esc(unit)}</text>
  <text x="${cx - r}" y="${cy + 24}" text-anchor="middle" font-size="10" fill="var(--muted)">${fmt(min, 0)}</text><text x="${cx + r}" y="${cy + 24}" text-anchor="middle" font-size="10" fill="var(--muted)">${fmt(max, 0)}</text>
  <text x="${cx}" y="116" text-anchor="middle" font-size="12" fill="var(--text)">${esc(label)}</text></svg>`;
}
