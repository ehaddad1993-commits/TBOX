import json, socket, struct, sys, tempfile, threading, time, unittest, os
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tbox_edge.drivers import make_driver, TagError, UnavailableDriver
from tbox_edge.drivers.base import ReadOnlyError
from tbox_edge.buffer import Outbox
from tbox_edge.uploader import Http, Uploader

class FakeModbus(threading.Thread):
    """Minimal Modbus TCP slave: holding regs 0..99, coil 0..15; address >=200 -> exception 2."""
    def __init__(self):
        super().__init__(daemon=True); self.srv = socket.socket(); self.srv.bind(("127.0.0.1", 0)); self.srv.listen(5); self.port = self.srv.getsockname()[1]
        self.regs = {i: i * 10 for i in range(100)}; self.regs[20], self.regs[21] = struct.unpack(">HH", struct.pack(">f", 12.5)); self.regs[30] = 0xFFFE; self.requests = []
    def run(self):
        while True:
            try: conn, _ = self.srv.accept()
            except OSError: return
            threading.Thread(target=self.handle, args=(conn,), daemon=True).start()
    def handle(self, conn):
        try:
            while True:
                h = conn.recv(7)
                if len(h) < 7: return
                tid, _, ln, unit = struct.unpack(">HHHB", h); pdu = conn.recv(ln - 1); fc, start, count = struct.unpack(">BHH", pdu[:5]); self.requests.append((fc, start, count, unit))
                if start >= 200: resp = bytes([fc | 0x80, 2])
                elif fc in (3, 4): resp = bytes([fc, count * 2]) + b"".join(struct.pack(">H", self.regs.get(start + i, 0)) for i in range(count))
                elif fc in (1, 2):
                    bits = bytearray((count + 7) // 8)
                    for i in range(count):
                        if (start + i) % 2 == 0: bits[i // 8] |= 1 << (i % 8)
                    resp = bytes([fc, len(bits)]) + bytes(bits)
                else: resp = bytes([fc | 0x80, 1])
                conn.sendall(struct.pack(">HHHB", tid, 0, len(resp) + 1, unit) + resp)
        except OSError: pass

def tag(i, addr, dt="uint16", rt="holding", **kw): return {"id": i, "name": f"t{i}", "address": str(addr), "reg_type": rt, "data_type": dt, **kw}

class ModbusTests(unittest.TestCase):
    def setUp(self): self.s = FakeModbus(); self.s.start()
    def drv(self, tags, **p): return make_driver({"id": 1, "kind": "modbus_tcp", "params": {"host": "127.0.0.1", "port": self.s.port, "unit_id": 7, **p}, "tags": tags})
    def test_types_and_blocks(self):
        d = self.drv([tag(1, 5), tag(2, 6), tag(3, 20, "float32"), tag(4, 30, "int16"), tag(5, 2, rt="coil", dt="bool"), tag(6, 3, rt="coil", dt="bool")]); r = d.read()
        self.assertEqual(r[1], 50); self.assertEqual(r[2], 60); self.assertAlmostEqual(r[3], 12.5); self.assertEqual(r[4], -2); self.assertEqual((r[5], r[6]), (1.0, 0.0))   # fake slave: even coil addresses read 1
        hold = [q for q in self.s.requests if q[0] == 3]; self.assertEqual(len(hold), 2, "regs 5-6 merge into one read; regs 20-31 (gap 14 > 8) are a second read"); self.assertEqual(hold[0][:3], (3, 5, 2)); self.assertEqual(hold[0][3], 7)
    def test_word_order(self):
        self.s.regs[40], self.s.regs[41] = struct.unpack(">HH", struct.pack(">f", 3.25)[::-1][::-1]); w = self.s.regs[40], self.s.regs[41]; self.s.regs[40], self.s.regs[41] = w[1], w[0]
        self.assertAlmostEqual(self.drv([tag(1, 40, "float32", word_order="little")]).read()[1], 3.25)
    def test_address_offset(self): self.assertEqual(self.drv([tag(1, 6)], addr_offset=-1).read()[1], 50)
    def test_exception_is_tag_error_not_comm_failure(self):
        r = self.drv([tag(1, 5), tag(2, 250)]).read(); self.assertEqual(r[1], 50); self.assertIsInstance(r[2], TagError)
    def test_connection_refused_raises(self):
        self.s.srv.close(); d = make_driver({"id": 1, "kind": "modbus_tcp", "params": {"host": "127.0.0.1", "port": 1, "timeout_ms": 300}, "tags": [tag(1, 0)]})
        with self.assertRaises(ConnectionError): d.read()
    def test_read_only(self):
        with self.assertRaises(ReadOnlyError): self.drv([tag(1, 5)]).write(tag(1, 5), 1)
    def test_unimplemented_driver_reports_comm_error(self):
        with self.assertRaises(ConnectionError): make_driver({"id": 1, "kind": "deye", "tags": []}).read()

class UploadTests(unittest.TestCase):
    def test_buffer_survives_outage_and_drains_in_order(self):
        received, mode = [], {"up": False}
        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                if not mode["up"]: self.send_response(503); self.end_headers(); return
                received.extend(b["n"] for b in body["batches"]); self.send_response(200); self.end_headers(); self.wfile.write(b"{}")
        srv = HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
        ob = Outbox(os.path.join(tempfile.mkdtemp(), "b.db")); [ob.put({"n": i}) for i in range(100)]
        st = {}; up = Uploader(Http({"server_url": f"http://127.0.0.1:{srv.server_port}", "site_key": "k"}), ob, st, lambda m: None); up.start()
        time.sleep(1.2); self.assertEqual(ob.size(), 100); self.assertFalse(st.get("online", False))          # outage: nothing lost
        mode["up"] = True; deadline = time.time() + 10
        while ob.size() and time.time() < deadline: time.sleep(0.2)
        self.assertEqual(received, list(range(100))); up.stop_evt.set()                                       # recovery: complete + ordered
    def test_buffer_cap_drops_oldest(self):
        ob = Outbox(os.path.join(tempfile.mkdtemp(), "b.db"), max_rows=10); [ob.put({"n": i}) for i in range(25)]
        self.assertEqual([p["n"] for _, p in ob.peek(100)], list(range(15, 25)))

if __name__ == "__main__": unittest.main()
