"""TBox edge gateway: polls local devices via drivers, buffers to disk, uploads to the TBox server, serves a local status page."""
import argparse, json, os, threading, time, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from html import escape
from .buffer import Outbox
from .drivers import make_driver, TagError, UnavailableDriver, ReadOnlyError
from .uploader import Http, Uploader

DEFAULTS = {"server_url": "http://127.0.0.1:8000", "site_key": "", "buffer_path": "edge_buffer.db", "cache_path": "edge_config_cache.json", "config_poll_s": 10,
            "batch_interval_s": 2, "max_buffer_rows": 500000, "allow_writes": False, "verify_tls": True, "local_ui": {"enabled": True, "bind": "127.0.0.1", "port": 8081}}
log = lambda m: print(time.strftime("%H:%M:%S"), m, flush=True)

def load_config(path=None):
    cfg = dict(DEFAULTS)
    if path: cfg.update(json.load(open(path)))
    cfg["server_url"] = os.environ.get("TBOX_SERVER_URL", cfg["server_url"]); cfg["site_key"] = os.environ.get("TBOX_SITE_KEY", cfg["site_key"])
    return cfg

class Sink:
    def __init__(self): self.lock, self.samples, self.devices, self.latest = threading.Lock(), [], {}, {}
    def push(self, dev_id, ts, comm_ok, error, samples):
        with self.lock:
            self.devices[dev_id] = {"comm_ok": comm_ok, "ts": ts, "error": error}; self.samples.extend(samples)
            for s in samples: self.latest[s["tag"]] = s
    def flush(self):
        with self.lock:
            p = {"batch_id": uuid.uuid4().hex, "ts": time.time(), "devices": {str(k): v for k, v in self.devices.items()}, "samples": self.samples}; self.samples = []
        return p

class Poller(threading.Thread):
    def __init__(self, dev, sink):
        super().__init__(daemon=True, name=f"poll-{dev['name']}"); self.dev, self.sink, self.stop_evt = dev, sink, threading.Event()
    def run(self):
        dev, fails = self.dev, 0
        try: drv = make_driver(dev)
        except Exception as e: drv = UnavailableDriver(dev); log(f"{dev['name']}: driver init failed: {e}")
        tags = {t["id"]: t for t in dev["tags"]}; interval = max(dev.get("poll_ms", 1000), 100) / 1000
        while not self.stop_evt.is_set():
            t0, ts, samples, err = time.monotonic(), time.time(), [], None
            try:
                for tid, raw in drv.read().items():
                    t = tags[tid]
                    if isinstance(raw, TagError): samples.append({"tag": tid, "ts": ts, "v": None, "q": "Bad"}); continue
                    samples.append({"tag": tid, "ts": ts, "v": float(raw) * (t.get("scale") or 1) + (t.get("offset") or 0), "q": "Good"})
                fails = 0
            except Exception as e:
                fails += 1; err = f"{type(e).__name__}: {e}"; drv.close()
                if fails in (1, 10): log(f"{dev['name']}: {err}")
            self.sink.push(dev["id"], ts, fails < 3, err, samples)
            self.stop_evt.wait(max(0.0, interval - (time.monotonic() - t0)))
        drv.close()

class Engine:
    def __init__(self, cfg):
        self.cfg, self.pollers, self.sigs, self.meta = cfg, {}, {}, {}
        self.sink, self.state = Sink(), {"online": False, "last_ok": None, "error": None}
        self.outbox, self.http, self.stop_evt = Outbox(cfg["buffer_path"], cfg["max_buffer_rows"]), Http(cfg), threading.Event()
        self.uploader = Uploader(self.http, self.outbox, self.state, log)
    def apply(self, conf):
        ids = set()
        for dev in conf["devices"]:
            ids.add(dev["id"]); sig = json.dumps(dev, sort_keys=True)
            for t in dev["tags"]: self.meta[t["id"]] = (dev["name"], t["name"], t.get("unit", ""))
            if self.sigs.get(dev["id"]) != sig:
                if dev["id"] in self.pollers: self.pollers[dev["id"]].stop_evt.set()
                self.sigs[dev["id"]] = sig; self.pollers[dev["id"]] = Poller(dev, self.sink); self.pollers[dev["id"]].start(); log(f"polling {dev['name']} ({dev['kind']}, {len(dev['tags'])} tags)")
        for did in list(self.pollers):
            if did not in ids: self.pollers.pop(did).stop_evt.set(); self.sigs.pop(did, None); log(f"stopped device {did}")
        for c in conf.get("commands", []): self.run_command(c, conf)
    def run_command(self, c, conf):
        res, ok = "edge allow_writes is false: command rejected", False
        if self.cfg["allow_writes"]:
            dev = next((d for d in conf["devices"] if d["id"] == c["device_id"]), None); tag = next((t for t in (dev or {}).get("tags", []) if t["id"] == c["tag_id"]), None)
            try:
                if not tag or tag.get("access") != "write": raise ReadOnlyError("tag not writable")
                make_driver(dev).write(tag, c["value"]); ok, res = True, "written"
            except Exception as e: res = f"{type(e).__name__}: {e}"
        log(f"command {c['id']}: {res}")
        try: self.http.call("/api/edge/command-result", {"id": c["id"], "ok": ok, "result": res})
        except Exception: pass
    def sync_loop(self):
        while not self.stop_evt.is_set():
            try:
                conf = self.http.call("/api/edge/config"); json.dump(conf, open(self.cfg["cache_path"], "w")); self.apply(conf)
            except Exception as e:
                if not self.pollers and os.path.exists(self.cfg["cache_path"]):
                    log(f"server unreachable ({e}); starting from cached config"); self.apply(json.load(open(self.cfg["cache_path"])))
            self.stop_evt.wait(self.cfg["config_poll_s"])
    def batch_loop(self):
        while not self.stop_evt.wait(self.cfg["batch_interval_s"]):
            if self.sink.devices: self.outbox.put(self.sink.flush())
    def start(self):
        for fn in (self.sync_loop, self.batch_loop): threading.Thread(target=fn, daemon=True).start()
        self.uploader.start()
        ui = self.cfg["local_ui"]
        if ui.get("enabled"): serve_local(self, ui["bind"], ui["port"])

def serve_local(engine, bind, port):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_GET(self):
            live = {"server_online": engine.state["online"], "buffered_batches": engine.outbox.size(), "error": engine.state["error"],
                    "devices": engine.sink.devices, "tags": [{"device": engine.meta.get(i, ("?", "?", ""))[0], "tag": engine.meta.get(i, ("?", "?", ""))[1], "unit": engine.meta.get(i, ("?", "?", ""))[2], **s} for i, s in engine.sink.latest.items()]}
            if self.path.startswith("/api/local/live"): body, ctype = json.dumps(live).encode(), "application/json"
            else:
                rows = "".join(f"<tr><td>{escape(t['device'])}</td><td>{escape(t['tag'])}</td><td>{'' if t['v'] is None else round(t['v'], 3)} {escape(t['unit'])}</td><td>{t['q']}</td></tr>" for t in sorted(live["tags"], key=lambda t: (t["device"], t["tag"])))
                body = (f"<meta http-equiv=refresh content=2><body style='font-family:sans-serif;background:#10151f;color:#e8ecf4'><h2>TBox Edge - local monitor (read-only)</h2>"
                        f"<p>Server link: <b>{'ONLINE' if live['server_online'] else 'OFFLINE (buffering)'}</b> | buffered batches: {live['buffered_batches']}</p><table cellpadding=4>{rows}</table>").encode(); ctype = "text/html"
            self.send_response(200); self.send_header("Content-Type", ctype); self.end_headers(); self.wfile.write(body)
    srv = ThreadingHTTPServer((bind, port), H); threading.Thread(target=srv.serve_forever, daemon=True).start(); log(f"local monitor on http://{bind}:{port}")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config"); a = ap.parse_args()
    cfg = load_config(a.config)
    if not cfg["site_key"]: raise SystemExit("site_key missing (config file or TBOX_SITE_KEY)")
    e = Engine(cfg); e.start(); log(f"TBox edge started -> {cfg['server_url']} (allow_writes={cfg['allow_writes']})")
    try:
        while True: time.sleep(3600)
    except KeyboardInterrupt: e.stop_evt.set()

if __name__ == "__main__": main()
