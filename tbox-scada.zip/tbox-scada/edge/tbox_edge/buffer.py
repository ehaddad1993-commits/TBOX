"""Store-and-forward outbox (SQLite). Every batch is written here first, so nothing is lost during internet or server outages."""
import json, sqlite3, threading, time

class Outbox:
    def __init__(self, path, max_rows=500_000):
        self.db = sqlite3.connect(path, check_same_thread=False, isolation_level=None); self.lock = threading.Lock(); self.max_rows = max_rows
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY AUTOINCREMENT, created REAL, payload TEXT)")
    def put(self, payload):
        with self.lock:
            self.db.execute("INSERT INTO outbox(created,payload) VALUES(?,?)", (time.time(), json.dumps(payload)))
            n = self.db.execute("SELECT COUNT(*) FROM outbox").fetchone()[0]
            if n > self.max_rows: self.db.execute("DELETE FROM outbox WHERE id IN (SELECT id FROM outbox ORDER BY id LIMIT ?)", (n - self.max_rows,))
    def peek(self, n=30):
        with self.lock: return [(i, json.loads(p)) for i, p in self.db.execute("SELECT id,payload FROM outbox ORDER BY id LIMIT ?", (n,))]
    def delete(self, ids):
        with self.lock: self.db.executemany("DELETE FROM outbox WHERE id=?", [(i,) for i in ids])
    def size(self):
        with self.lock: return self.db.execute("SELECT COUNT(*) FROM outbox").fetchone()[0]
