import json, ssl, threading, time, urllib.error, urllib.request

class Http:
    def __init__(self, cfg):
        self.base, self.key = cfg["server_url"].rstrip("/"), cfg["site_key"]
        self.ctx = ssl.create_default_context() if cfg.get("verify_tls", True) else ssl._create_unverified_context()
    def call(self, path, payload=None, timeout=10):
        req = urllib.request.Request(self.base + path, json.dumps(payload).encode() if payload is not None else None,
                                     {"Content-Type": "application/json", "X-Site-Key": self.key}, method="POST" if payload is not None else "GET")
        with urllib.request.urlopen(req, timeout=timeout, context=self.ctx) as r: return json.loads(r.read() or b"{}")

class Uploader(threading.Thread):
    def __init__(self, http, outbox, state, log):
        super().__init__(daemon=True); self.http, self.outbox, self.state, self.log, self.stop_evt = http, outbox, state, log, threading.Event()
    def run(self):
        backoff = 1.0
        while not self.stop_evt.is_set():
            rows = self.outbox.peek(30)
            if not rows: self.stop_evt.wait(0.5); continue
            try:
                self.http.call("/api/ingest", {"batches": [p for _, p in rows]}); self.outbox.delete([i for i, _ in rows])
                self.state.update(online=True, last_ok=time.time(), error=None); backoff = 1.0
            except urllib.error.HTTPError as e:
                if e.code in (400, 413, 422): self.log(f"dropping {len(rows)} rejected batches (HTTP {e.code})"); self.outbox.delete([i for i, _ in rows]); continue
                self.state.update(online=False, error=f"HTTP {e.code}"); self.stop_evt.wait(backoff); backoff = min(backoff * 2, 30)
            except Exception as e:
                self.state.update(online=False, error=str(e)); self.stop_evt.wait(backoff); backoff = min(backoff * 2, 30)
