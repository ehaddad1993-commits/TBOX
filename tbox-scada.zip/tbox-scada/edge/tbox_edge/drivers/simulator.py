"""Deterministic plant simulator for development. Signals are functions of absolute time (schedules) plus integrals (fuel, kWh),
so history seeded offline and live data from the edge are continuous: both fast-forward from the same fixed EPOCH."""
import calendar, math, random, time
from .base import Driver, TagError

EPOCH = calendar.timegm((2026, 10, 1, 0, 0, 0))
clamp = lambda x, lo, hi: max(lo, min(hi, x))
lag = lambda cur, target, dt, tau: cur + (target - cur) * (1 - math.exp(-dt / tau))

class Sim:
    def __init__(self, seed=1, utc_offset_h=0):
        self.rng = random.Random(seed); self.t = EPOCH; self.utc = utc_offset_h * 3600; self.s = {}; self.seed = seed; self.init(); self.advance(EPOCH + 60)
    def n(self, a): return self.rng.gauss(0, a)
    def advance(self, now):
        while self.t + 60 <= now: self._step(self.t + 60)
        if now - self.t >= 0.2: self._step(now)
    def _step(self, t):
        dt = t - self.t; self.t = t; self.update(t, dt)
    def local_h(self, t): return ((t + self.utc) % 86400) / 3600
    def init(self): pass

class Generator(Sim):
    RATED, TANK = 500.0, 1000.0
    def init(self):
        self.off = 5400 * (self.seed % 2); self.ph = self.seed
        self.fuel, self.kwh, self.hours, self.cool = 600 + 80 * self.seed, 25000.0 * self.seed, 1800.0 + 100 * self.seed, 28.0
    def update(self, t, dt):
        phase = (t + self.off) % 10800; run = phase < 7200; ramp = min(1.0, phase / 30) if run else 0.0
        load = 0.55 + 0.3 * math.sin(2 * math.pi * t / 5400 + self.ph)
        kw = self.RATED * load * ramp * (1 + self.n(0.01)) if run else 0.0
        pf = 0.86 + self.n(0.004); kva = kw / pf if kw > 0 else 0.0
        v = (lambda: 230 * ramp + self.n(0.8) if run else 0.0)
        overheat = run and (t // 10800) % 4 == self.seed % 4 + 1 and phase > 3600 and self.seed % 2 == 0
        self.cool = lag(self.cool, 108 if overheat else (80 + 8 * load if run else 28), dt, 300)
        rate = (18 + 0.24 * kw) if run else 0.0
        self.fuel -= rate * dt / 3600
        if self.fuel < 120: self.fuel = 950.0                      # simulated delivery
        self.kwh += kw * dt / 3600; self.hours += dt / 3600 if run else 0
        s = self.s
        s.update(run_state=1 if run else 0, voltage_l1=v(), voltage_l2=v(), voltage_l3=v(), current=kva * 1000 / (3 * 230) if kw > 0 else 0.0,
                 frequency=50 + self.n(0.05) if run else 0.0, kw=kw, kva=kva, pf=pf if run else 0.0, rpm=1500 * ramp + (self.n(2) if run else 0), oil_pressure=4.5 * ramp + (self.n(0.05) if run else 0),
                 coolant_temp=self.cool, battery_voltage=27.4 + self.n(0.05) if run else 26.2 + self.n(0.02), fuel_level_l=self.fuel + self.n(0.03), fuel_level_pct=self.fuel / self.TANK * 100,
                 fuel_rate_lph=rate, energy_kwh=self.kwh, run_hours=self.hours)

class Solar(Sim):
    CAP = 300.0
    def init(self): self.soc, self.total, self.today, self.day, self.ph = 60.0, 48000.0, 0.0, -1, self.seed
    def update(self, t, dt):
        h, day = self.local_h(t), int((t + self.utc) // 86400)
        if day != self.day: self.day, self.today = day, 0.0
        sun = math.sin(math.pi * (h - 6) / 12) if 6 < h < 18 else 0.0
        pv = max(0.0, 150 * sun * (0.6 + 0.4 * ((day * 37) % 10) / 10) * (0.9 + 0.1 * math.sin(t / 900 + self.ph)) + (self.n(0.4) if sun > 0 else 0))
        load = 70 + 35 * math.sin(2 * math.pi * (h - 14) / 24) + self.n(1)
        bat = clamp(pv - load, -40, 40)
        if (self.soc >= 99.5 and bat > 0) or (self.soc <= 10 and bat < 0): bat = 0.0
        self.soc = clamp(self.soc + bat * dt / 3600 / self.CAP * 100, 10, 100)
        ac = pv * 0.97; self.today += ac * dt / 3600; self.total += ac * dt / 3600
        self.s.update(status=(1 if pv > 1 else 0), pv_voltage=(520 + 40 * sun + self.n(1)) if pv > 1 else 0.0, pv_current=pv * 1000 / 540 if pv > 1 else 0.0, pv_kw=pv,
                      ac_voltage=230 + self.n(0.7), ac_frequency=50 + self.n(0.03), ac_kw=ac, battery_soc=self.soc, battery_voltage=48 + 6 * self.soc / 100 + self.n(0.05), battery_kw=bat,
                      grid_kw=load - pv + bat, temperature=lag(self.s.get("temperature", 30), 32 + 0.28 * pv, dt, 600), energy_today_kwh=self.today, energy_total_kwh=self.total)

class Meter(Sim):
    def init(self): self.imp, self.exp = 152000.0, 120.0
    def update(self, t, dt):
        h = self.local_h(t); kw = 110 + 55 * math.sin(2 * math.pi * (h - 15) / 24) + self.n(1.5); pf = 0.93 + self.n(0.003); kva = kw / pf
        self.imp += kw * dt / 3600; i = kw * 1000 / (3 * 230 * pf)
        self.s.update(voltage_l1=230 + self.n(0.8), voltage_l2=230.5 + self.n(0.8), voltage_l3=229.5 + self.n(0.8), current_l1=i * 1.02 + self.n(0.4), current_l2=i * 0.98 + self.n(0.4), current_l3=i + self.n(0.4),
                      kw=kw, kva=kva, kvar=math.sqrt(max(kva ** 2 - kw ** 2, 0)), pf=pf, frequency=50 + self.n(0.03), import_kwh=self.imp, export_kwh=self.exp)

class PlcStation(Sim):
    def init(self): self.level, self.pump, self.temp, self.bulk = 45.0 + 5 * self.seed, False, 30.0, 55.0 + 8 * self.seed
    def update(self, t, dt):
        if self.level < 30: self.pump = True
        if self.level > 80: self.pump = False
        use = 0.012 * (1 + 0.4 * math.sin(t / 1800 + self.seed)) + abs(self.n(0.001))
        self.level = clamp(self.level + ((0.033 if self.pump else 0) - use) * dt, 0, 100)
        self.temp = lag(self.temp, 58 if self.pump else 30, dt, 400)
        self.bulk -= 0.0006 * (1 + 0.5 * math.sin(t / 7200)) * dt
        if self.bulk < 12: self.bulk = 95.0
        p = (3.4 + 0.8 if self.pump else 3.0) + self.n(0.03) - (1.6 if (t % 21600) < 180 else 0)
        self.s.update(pump_run=1 if self.pump else 0, tank_level_pct=self.level, pressure_bar=p, flow_m3h=(45 + self.n(0.6)) if self.pump else 0.0,
                      pump_current=(17 + self.n(0.25)) if self.pump else 0.0, motor_temp=self.temp, bulk_fuel_pct=self.bulk)

class Vfd(Sim):
    def init(self): self.act, self.temp = 0.0, 32.0
    def update(self, t, dt):
        sp = [30, 35, 40, 45][int(t // 1200) % 4]; fault = 20000 <= (t % 43200) < 20120; run = not fault and (t % 7200) < 6900
        target = sp if run else 0.0
        self.act += clamp(target - self.act, -3 * dt, 3 * dt); a = self.act
        self.temp = lag(self.temp, 32 + 0.7 * a, dt, 500)
        cur = 0.45 * a * (0.9 + 0.2 * math.sin(t / 600)) + (self.n(0.2) if a > 1 else 0)
        self.s.update(running=1 if a > 0.5 else 0, freq_actual=a, freq_setpoint=sp, speed_rpm=a * 30 * 0.97, current=cur, power_kw=0.4 * cur * 0.4, dc_bus_v=540 + self.n(1.5), drive_temp=self.temp, fault_code=12 if fault else 0)

PROFILES = {"generator": Generator, "solar_inverter": Solar, "energy_meter": Meter, "plc_station": PlcStation, "vfd": Vfd}

def make_sim(profile, seed=1, utc_offset_h=0): return PROFILES[profile](seed, utc_offset_h)

class SimulatorDriver(Driver):
    def __init__(self, device):
        super().__init__(device)
        self.sim = make_sim(device.get("profile") or "generator", seed=device["id"], utc_offset_h=float(self.params.get("utc_offset_h", 0)))
    def read(self):
        self.sim.advance(time.time()); out = {}
        for t in self.tags:
            key = t["address"].split(":", 1)[-1]
            out[t["id"]] = float(self.sim.s[key]) if key in self.sim.s else TagError(f"unknown simulator signal '{key}'")
        return out
