from .base import Driver, UnavailableDriver, TagError, ReadOnlyError
from .simulator import SimulatorDriver
from .modbus_tcp import ModbusTcpDriver

REGISTRY = {"simulator": SimulatorDriver, "modbus_tcp": ModbusTcpDriver}   # add new drivers here (see docs/DRIVERS.md)

def make_driver(device):
    cls = REGISTRY.get(device.get("kind"), UnavailableDriver)
    return cls(device)
