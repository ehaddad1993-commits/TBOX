"""Modbus TCP client (stdlib only). READ-ONLY: function codes 01, 02, 03, 04. No write function is implemented in this build."""
import socket, struct
from .base import Driver, TagError

WORDS = {"bool": 1, "int16": 1, "uint16": 1, "int32": 2, "uint32": 2, "float32": 2}
FC = {"coil": 1, "discrete": 2, "holding": 3, "input": 4}
MAX_REGS, MAX_BITS, MAX_GAP = 120, 1900, 8

class ModbusTcpDriver(Driver):
    def __init__(self, device):
        super().__init__(device); p = self.params
        if not p.get("host"): raise ValueError("modbus_tcp device needs params.host")
        self.host, self.port, self.unit = p["host"], int(p.get("port", 502)), int(p.get("unit_id", 1))
        self.timeout, self.off, self.sock, self.tid = float(p.get("timeout_ms", 2000)) / 1000, int(p.get("addr_offset", 0)), None, 0

    def close(self):
        if self.sock:
            try: self.sock.close()
            except OSError: pass
        self.sock = None

    def _recv(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk: raise ConnectionError("connection closed by device")
            buf += chunk
        return buf

    def _txn(self, fc, start, count):
        self.tid = (self.tid + 1) & 0xFFFF
        pdu = struct.pack(">BHH", fc, start, count)
        self.sock.sendall(struct.pack(">HHHB", self.tid, 0, len(pdu) + 1, self.unit) + pdu)
        tid, proto, ln, _unit = struct.unpack(">HHHB", self._recv(7))
        if tid != self.tid or proto != 0 or not 2 <= ln <= 260: raise ConnectionError("invalid Modbus response header")
        resp = self._recv(ln - 1)
        if resp[0] == fc | 0x80: raise TagError(f"Modbus exception code {resp[1]}")
        if resp[0] != fc: raise ConnectionError("unexpected function code in response")
        return resp[2:2 + resp[1]]

    def _plan(self):
        items, out = [], {}
        for t in self.tags:
            try:
                rt, dt = t.get("reg_type", "holding"), t.get("data_type", "uint16")
                if rt not in FC or dt not in WORDS: raise ValueError(f"unsupported reg_type/data_type {rt}/{dt}")
                if rt in ("coil", "discrete") and dt != "bool": raise ValueError("coil/discrete tags must be bool")
                items.append((rt, int(t["address"]) + self.off, 1 if rt in ("coil", "discrete") else WORDS[dt], t))
            except (ValueError, TypeError) as e: out[t["id"]] = TagError(str(e))
        items.sort(key=lambda x: (x[0], x[1])); blocks = []
        for it in items:
            lim = MAX_BITS if it[0] in ("coil", "discrete") else MAX_REGS
            b = blocks[-1] if blocks else None
            if b and b["rt"] == it[0] and it[1] <= b["end"] + MAX_GAP and max(b["end"], it[1] + it[2]) - b["start"] <= lim:
                b["end"] = max(b["end"], it[1] + it[2]); b["items"].append(it)
            else: blocks.append({"rt": it[0], "start": it[1], "end": it[1] + it[2], "items": [it]})
        return blocks, out

    @staticmethod
    def _decode(dt, order, words):
        if dt == "bool": return float(words[0] != 0)
        if dt == "uint16": return float(words[0])
        if dt == "int16": return float(struct.unpack(">h", struct.pack(">H", words[0]))[0])
        if order == "little": words = words[::-1]
        raw = struct.pack(">HH", *words)
        return float(struct.unpack({"int32": ">i", "uint32": ">I", "float32": ">f"}[dt], raw)[0])

    def read(self):
        blocks, out = self._plan()
        try:
            if self.sock is None:
                self.sock = socket.create_connection((self.host, self.port), self.timeout); self.sock.settimeout(self.timeout)
            for b in blocks:
                count = b["end"] - b["start"]
                try: data = self._txn(FC[b["rt"]], b["start"], count)
                except TagError as e:
                    for it in b["items"]: out[it[3]["id"]] = e
                    continue
                bits = b["rt"] in ("coil", "discrete")
                if len(data) < ((count + 7) // 8 if bits else count * 2): raise ConnectionError("short Modbus response")
                regs = None if bits else struct.unpack(f">{count}H", data[:count * 2])
                for rt, addr, n, t in b["items"]:
                    i = addr - b["start"]
                    out[t["id"]] = float((data[i // 8] >> (i % 8)) & 1) if bits else self._decode(t.get("data_type"), t.get("word_order", "big"), regs[i:i + n])
            return out
        except (OSError, ConnectionError, struct.error) as e:
            self.close(); raise ConnectionError(f"{type(e).__name__}: {e}")
