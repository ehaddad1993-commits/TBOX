class TagError(Exception):
    """Per-tag failure (e.g. illegal address). The tag gets quality Bad; the device stays online."""

class ReadOnlyError(Exception):
    pass

class Driver:
    """Driver contract. read() returns {tag_id: raw_value | TagError}; it raises ConnectionError when the device is unreachable.
    Drivers are read-only unless write() is implemented AND the edge config sets allow_writes=true."""
    writable = False
    def __init__(self, device):
        self.dev, self.params, self.tags = device, device.get("params") or {}, device.get("tags") or []
    def read(self): raise NotImplementedError
    def write(self, tag, value): raise ReadOnlyError(f"{type(self).__name__} is read-only in this build")
    def close(self): pass

class UnavailableDriver(Driver):
    def read(self): raise ConnectionError(f"driver '{self.dev.get('kind')}' is not implemented yet (see docs/DRIVERS.md)")
