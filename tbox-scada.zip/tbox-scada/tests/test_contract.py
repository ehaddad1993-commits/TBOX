"""Server tag templates and the edge simulator must agree on signal names (the 'sim:<signal>' address contract)."""
import sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path[:0] = [str(ROOT / "server"), str(ROOT / "edge")]
from tbox_server.templates import PROFILE_TAGS
from tbox_edge.drivers.simulator import make_sim, PROFILES

class Contract(unittest.TestCase):
    def test_templates_match_simulator(self):
        self.assertEqual(set(PROFILE_TAGS), set(PROFILES))
        for p, tags in PROFILE_TAGS.items():
            sim = make_sim(p, seed=2); names = {t["name"] for t in tags}
            self.assertEqual(names, set(sim.s), f"{p}: template and simulator signals differ: {names ^ set(sim.s)}")
if __name__ == "__main__": unittest.main()
