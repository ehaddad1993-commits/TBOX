import os, sys, tempfile, time, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ["TBOX_ADMIN_PASSWORD"] = "admin-test-pw"
from tbox_server.app import create_app
from tbox_server import db, alarms, ingest

class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.app = create_app(os.path.join(self.tmp, "t.db"), background=False); self.c = self.app.test_client()
        alarms._pending.clear(); alarms.invalidate(); ingest._last_logged.clear()
        self.admin = self.login("admin", "admin-test-pw")
        r = self.c.post("/api/sites", json={"code": "S1", "name": "Site 1"}, headers=self.admin); self.sid, self.key = r.json["id"], r.json["api_key"]
        r = self.c.post("/api/devices", json={"site_id": self.sid, "name": "GEN-1", "kind": "simulator", "profile": "generator"}, headers=self.admin); self.did = r.json["id"]
        self.tags = {t["name"]: t["id"] for t in self.c.get("/api/tags", headers=self.admin).json["tags"]}
    def login(self, u, p):
        r = self.c.post("/api/auth/login", json={"username": u, "password": p}); self.assertEqual(r.status_code, 200, r.json); return {"Authorization": "Bearer " + r.json["token"]}
    def send(self, samples, devices=None, key=None):
        return self.c.post("/api/ingest", json={"devices": devices or {str(self.did): {"comm_ok": True, "ts": time.time()}}, "samples": samples}, headers={"X-Site-Key": key or self.key})
    def sample(self, name, v, ts=None, q="Good"): return {"tag": self.tags[name], "ts": ts or time.time(), "v": v, "q": q}

class AuthTests(Base):
    def test_bad_login(self): self.assertEqual(self.c.post("/api/auth/login", json={"username": "admin", "password": "x"}).status_code, 401)
    def test_requires_token(self): self.assertEqual(self.c.get("/api/devices").status_code, 401)
    def test_viewer_cannot_configure(self):
        self.c.post("/api/users", json={"username": "v", "password": "viewerpass1", "role": "viewer", "site_ids": [self.sid]}, headers=self.admin); h = self.login("v", "viewerpass1")
        self.assertEqual(self.c.post("/api/devices", json={"site_id": self.sid, "name": "X", "kind": "simulator"}, headers=h).status_code, 403)
        self.assertEqual(self.c.post("/api/alarms/1/ack", headers=h).status_code, 403)
    def test_site_isolation(self):
        s2 = self.c.post("/api/sites", json={"code": "S2", "name": "Site 2"}, headers=self.admin).json["id"]
        self.c.post("/api/users", json={"username": "op", "password": "operatorpw1", "role": "operator", "site_ids": [s2]}, headers=self.admin); h = self.login("op", "operatorpw1")
        self.assertEqual(self.c.get("/api/devices", headers=h).json["devices"], [])
        self.assertEqual(self.c.get(f"/api/devices?site_id={self.sid}", headers=h).status_code, 403)
    def test_audit_records_login_and_config(self):
        acts = [a["action"] for a in self.c.get("/api/audit", headers=self.admin).json["audit"]]; self.assertIn("login", acts); self.assertIn("device.create", acts)

class IngestTests(Base):
    def test_rejects_bad_site_key(self): self.assertEqual(self.send([self.sample("kw", 1)], key="nope").status_code, 401)
    def test_live_and_status(self):
        self.assertEqual(self.send([self.sample("kw", 123.0), self.sample("run_state", 1)]).status_code, 200)
        live = self.c.get("/api/live", headers=self.admin).json
        self.assertEqual(live["tags"][str(self.tags["kw"])][0], 123.0); self.assertEqual(live["tags"][str(self.tags["kw"])][2], "Good")
        self.assertEqual(live["devices"][0]["status"], "Online")
    def test_replay_is_idempotent(self):
        s = [self.sample("kw", 5.0, ts=time.time() - 100)]; self.send(s); ingest._last_logged.clear(); self.send(s)
        self.assertEqual(db.one("SELECT COUNT(*) n FROM history WHERE tag_id=?", (self.tags["kw"],))["n"], 1)
    def test_log_interval_downsamples(self):
        t0 = time.time() - 60   # kw log interval = 10 s
        self.send([self.sample("kw", i, ts=t0 + i) for i in range(30)])
        n = db.one("SELECT COUNT(*) n FROM history WHERE tag_id=?", (self.tags["kw"],))["n"]; self.assertTrue(3 <= n <= 4, n)
    def test_bad_quality_not_logged(self):
        self.send([self.sample("kw", None, q="Bad")]); self.assertEqual(db.one("SELECT COUNT(*) n FROM history")["n"], 0)
        self.assertEqual(self.c.get("/api/live", headers=self.admin).json["tags"][str(self.tags["kw"])][2], "Bad")
    def test_stale_after_timeout(self):
        self.send([self.sample("kw", 1.0, ts=time.time() - 60)]); self.assertEqual(self.c.get("/api/live", headers=self.admin).json["tags"][str(self.tags["kw"])][2], "Stale")
    def test_history_query(self):
        t0 = time.time() - 600; self.send([self.sample("kw", 100 + i, ts=t0 + i * 10) for i in range(60)])
        r = self.c.get(f"/api/history?tags={self.tags['kw']}&from={t0 - 1}&to={t0 + 700}&max_points=10", headers=self.admin).json["series"][str(self.tags["kw"])]
        self.assertTrue(5 <= len(r) <= 12); self.assertTrue(all(len(p) == 4 for p in r))

class AlarmTests(Base):
    def test_alarm_delay_is_respected(self):
        self.send([self.sample("coolant_temp", 99)])      # high limit 95 with 5 s delay -> must not alarm on a single sample
        self.assertEqual(self.c.get("/api/alarms", headers=self.admin).json["alarms"], [])
        self.assertEqual(self.c.get("/api/live", headers=self.admin).json["devices"][0]["status"], "Online")
    def test_delay_then_raise_ack_clear(self):
        t = time.time() - 30
        self.send([self.sample("coolant_temp", 99, ts=t), self.sample("coolant_temp", 99, ts=t + 6)])
        al = self.c.get("/api/alarms", headers=self.admin).json["alarms"]; self.assertEqual(len(al), 1); self.assertEqual(al[0]["state"], "active_unack"); self.assertEqual(al[0]["kind"], "high")
        self.assertEqual(self.c.get("/api/live", headers=self.admin).json["tags"][str(self.tags["coolant_temp"])][3], "high")
        self.c.post(f"/api/alarms/{al[0]['id']}/ack", headers=self.admin); self.assertEqual(self.c.get("/api/alarms", headers=self.admin).json["alarms"][0]["state"], "active_ack")
        self.send([self.sample("coolant_temp", 94, ts=t + 7)]); self.assertEqual(self.c.get("/api/alarms", headers=self.admin).json["alarms"][0]["state"], "active_ack")  # inside deadband
        self.send([self.sample("coolant_temp", 80, ts=t + 8)]); self.assertEqual(self.c.get("/api/alarms?state=history", headers=self.admin).json["alarms"][0]["state"], "cleared")
    def test_comm_alarm_and_recovery(self):
        self.send([self.sample("kw", 1)]); self.send([], devices={str(self.did): {"comm_ok": False, "ts": time.time(), "error": "timeout"}})
        al = self.c.get("/api/alarms", headers=self.admin).json["alarms"]; self.assertEqual(al[0]["kind"], "comm")
        self.assertEqual(self.c.get("/api/live", headers=self.admin).json["devices"][0]["status"], "CommLost")
        self.send([self.sample("kw", 2)]); self.assertEqual(self.c.get("/api/live", headers=self.admin).json["devices"][0]["status"], "Online")
    def test_ack_all(self):
        self.send([], devices={str(self.did): {"comm_ok": False, "ts": time.time()}}); self.assertEqual(self.c.post("/api/alarms/ack-all", headers=self.admin).json["acked"], 1)

class ControlSafetyTests(Base):
    def test_write_denied_in_read_only_mode_and_audited(self):
        tid = self.tags["kw"]; self.c.put(f"/api/tags/{tid}", json={"access": "write"}, headers=self.admin)
        r = self.c.post(f"/api/tags/{tid}/write", json={"value": 10}, headers=self.admin); self.assertEqual(r.status_code, 403); self.assertEqual(r.json["error"], "control_disabled")
        self.assertEqual(db.one("SELECT COUNT(*) n FROM commands")["n"], 0)
        self.assertTrue(any(a["action"] == "write" and a["result"] == "denied" for a in self.c.get("/api/audit", headers=self.admin).json["audit"]))
    def test_write_requires_confirmation_range_and_permission(self):
        self.app.config["COMMANDS_ENABLED"] = True; tid = self.tags["kw"]; w = f"/api/tags/{tid}/write"
        self.assertEqual(self.c.post(w, json={"value": 1}, headers=self.admin).json["error"], "tag_read_only")
        self.c.put(f"/api/tags/{tid}", json={"access": "write", "min_val": 0, "max_val": 100}, headers=self.admin)
        self.assertEqual(self.c.post(w, json={"value": 500}, headers=self.admin).json["error"], "out_of_range")
        r = self.c.post(w, json={"value": 50}, headers=self.admin); self.assertEqual(r.status_code, 202); self.assertTrue(r.json["confirm_required"])
        self.assertEqual(db.one("SELECT COUNT(*) n FROM commands")["n"], 0)
        self.assertEqual(self.c.post(w, json={"value": 51, "confirm_token": r.json["token"]}, headers=self.admin).status_code, 400)   # token bound to value
        r = self.c.post(w, json={"value": 50}, headers=self.admin)
        self.assertEqual(self.c.post(w, json={"value": 50, "confirm_token": r.json["token"]}, headers=self.admin).json["queued"], True)
        self.c.post("/api/users", json={"username": "op", "password": "operatorpw1", "role": "operator", "site_ids": [self.sid]}, headers=self.admin)
        self.assertEqual(self.c.post(w, json={"value": 5}, headers=self.login("op", "operatorpw1")).json["error"], "no_control_permission")

class TagAndReportTests(Base):
    def test_csv_import_export_roundtrip(self):
        d = self.c.post("/api/devices", json={"site_id": self.sid, "name": "M221", "kind": "modbus_tcp", "params": {"host": "10.0.0.5"}}, headers=self.admin).json["id"]
        csv = "name,address,reg_type,data_type,scale,unit\ntank_level,10,holding,uint16,0.1,%\nbad,1,holding,float99,1,\n"
        r = self.c.post("/api/tags/import", json={"device_id": d, "csv": csv}, headers=self.admin).json; self.assertEqual(r["added"], 1); self.assertEqual(len(r["errors"]), 1)
        out = self.c.get(f"/api/tags/export.csv?device_id={d}", headers=self.admin).data.decode(); self.assertIn("tank_level,", out)
    def test_validation(self):
        self.assertEqual(self.c.post("/api/tags", json={"device_id": self.did, "name": "x", "address": "1", "data_type": "nope"}, headers=self.admin).status_code, 400)
    def test_energy_and_fuel_reports_and_exports(self):
        t0 = time.time() - 3 * 3600; n = 36
        self.c.put(f"/api/tags/{self.tags['energy_kwh']}", json={"log_interval_s": 1}, headers=self.admin); self.c.put(f"/api/tags/{self.tags['fuel_level_l']}", json={"log_interval_s": 1}, headers=self.admin)
        self.send([self.sample("energy_kwh", 1000 + i * 5.0, ts=t0 + i * 300) for i in range(n)] + [self.sample("fuel_level_l", 500 - i * 2.0, ts=t0 + i * 300) for i in range(n)])
        e = self.c.get(f"/api/reports/energy?period=day&from={t0 - 10}", headers=self.admin).json; self.assertAlmostEqual(e["totals"][3], 175.0, 1)
        f = self.c.get(f"/api/reports/fuel?period=day&from={t0 - 10}", headers=self.admin).json; self.assertAlmostEqual(f["totals"][2], 70.0, 1)
        for fmt, magic in (("xlsx", b"PK"), ("pdf", b"%PDF")): self.assertTrue(self.c.get(f"/api/reports/fuel?period=hour&format={fmt}&from={t0 - 10}", headers=self.admin).data.startswith(magic))
    def test_counter_reset_ignored(self):
        from tbox_server.reports import counter_deltas, _tz
        self.assertEqual(counter_deltas([(1, 100), (2, 110), (3, 5), (4, 12)], "day", _tz("UTC"), 0), {"1970-01-01": 17})
    def test_screen_roundtrip_and_validation(self):
        r = self.c.post("/api/screens", json={"site_id": self.sid, "name": "S", "doc": {"widgets": [{"type": "label"}]}}, headers=self.admin); self.assertEqual(r.status_code, 201)
        self.assertEqual(self.c.get(f"/api/screens/{r.json['id']}", headers=self.admin).json["doc"]["widgets"][0]["type"], "label")
        self.assertEqual(self.c.post("/api/screens", json={"site_id": self.sid, "name": "S", "doc": {}}, headers=self.admin).status_code, 400)
    def test_edge_config_and_backup(self):
        c = self.c.get("/api/edge/config", headers={"X-Site-Key": self.key}).json; self.assertEqual(c["devices"][0]["name"], "GEN-1"); self.assertTrue(c["devices"][0]["tags"])
        os.environ["TBOX_BACKUP_DIR"] = os.path.join(self.tmp, "bk"); self.assertTrue(os.path.exists(self.c.post("/api/admin/backup", headers=self.admin).json["path"]))

if __name__ == "__main__": unittest.main()
