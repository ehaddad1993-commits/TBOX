"""Alarm engine: threshold alarms with deadband + delay, communication alarms, ack workflow, notifications."""
import json, threading, time, urllib.request
from . import db

LOCK = threading.RLock()
SEVERITY = ["high_high", "low_low", "high", "low"]          # worst first (for tag alarm_state)
RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1}
ACTIVE = ("active_unack", "active_ack")
_pending, _defs, _defs_dirty = {}, {}, True

def invalidate(): 
    global _defs_dirty; _defs_dirty = True

def _defs_for(tag_id):
    global _defs, _defs_dirty
    if _defs_dirty:
        _defs = {}
        for d in db.q("SELECT * FROM alarm_defs WHERE enabled=1"): _defs.setdefault(d["tag_id"], []).append(d)
        _defs_dirty = False
    return _defs.get(tag_id, ())

def event(level, category, message, site_id=None, device_id=None):
    db.run("INSERT INTO events(ts,site_id,device_id,level,category,message) VALUES(?,?,?,?,?,?)", (time.time(), site_id, device_id, level, category, message))

def _violates(kind, lim, v): return v >= lim if kind.startswith("high") else v <= lim
def _clears(kind, lim, dbd, v): return v < lim - dbd if kind.startswith("high") else v > lim + dbd

def evaluate(tag_id, device_id, site_id, value, ts):
    defs = _defs_for(tag_id)
    if not defs: return
    with LOCK:
        for d in defs:
            act = db.one("SELECT id FROM alarms WHERE def_id=? AND state IN ('active_unack','active_ack')", (d["id"],))
            if _violates(d["kind"], d["limit_val"], value):
                if act: continue
                first = _pending.setdefault(d["id"], ts)
                if ts - first >= d["delay_s"]: _raise(d, tag_id, device_id, site_id, value, ts)
            else:
                _pending.pop(d["id"], None)
                if act and _clears(d["kind"], d["limit_val"], d["deadband"], value): _clear(act["id"], tag_id, ts)

def _raise(d, tag_id, device_id, site_id, value, ts):
    info = db.one("SELECT t.name tag, t.unit, dv.name dev FROM tags t JOIN devices dv ON dv.id=t.device_id WHERE t.id=?", (tag_id,))
    msg = d["message"] or f"{info['dev']} {info['tag']} {d['kind'].replace('_', ' ').upper()}: {value:.2f} {info['unit']} (limit {d['limit_val']:g})"
    aid = db.run("""INSERT INTO alarms(def_id,tag_id,device_id,site_id,kind,priority,message,value,raised_at,state) VALUES(?,?,?,?,?,?,?,?,?,'active_unack')""",
                 (d["id"], tag_id, device_id, site_id, d["kind"], d["priority"], msg, value, ts))
    event("alarm" if d["priority"] in ("critical", "high") else "warning", "alarm", "ALARM " + msg, site_id, device_id)
    _tag_state(tag_id); notify(aid)

def _clear(alarm_id, tag_id, ts):
    a = db.one("SELECT * FROM alarms WHERE id=?", (alarm_id,))
    db.run("UPDATE alarms SET cleared_at=?, state=? WHERE id=?", (ts, "cleared" if a["ack_at"] else "cleared_unack", alarm_id))
    event("info", "alarm", "RETURN TO NORMAL " + a["message"], a["site_id"], a["device_id"])
    if tag_id: _tag_state(tag_id)

def _tag_state(tag_id):
    kinds = [r["kind"] for r in db.q("SELECT kind FROM alarms WHERE tag_id=? AND state IN ('active_unack','active_ack')", (tag_id,))]
    worst = next((k for k in SEVERITY if k in kinds), None)
    db.run("UPDATE tag_current SET alarm_state=? WHERE tag_id=?", (worst, tag_id))

def comm_change(device_id, ok, error=None):
    with LOCK:
        dev = db.one("SELECT * FROM devices WHERE id=?", (device_id,))
        if not dev: return
        act = db.one("SELECT id FROM alarms WHERE device_id=? AND kind='comm' AND state IN ('active_unack','active_ack')", (device_id,))
        if not ok and not act:
            msg = f"Communication lost: {dev['name']}" + (f" ({error})" if error else "")
            aid = db.run("INSERT INTO alarms(device_id,site_id,kind,priority,message,raised_at,state) VALUES(?,?,?,?,?,?,'active_unack')",
                         (device_id, dev["site_id"], "comm", "high", msg, time.time()))
            event("alarm", "comm", msg, dev["site_id"], device_id); notify(aid)
        elif ok and act:
            _clear(act["id"], None, time.time())
            event("info", "comm", f"Communication restored: {dev['name']}", dev["site_id"], device_id)

def ack(alarm_id, user):
    with LOCK:
        a = db.one("SELECT * FROM alarms WHERE id=?", (alarm_id,))
        if not a or a["state"] not in ("active_unack", "cleared_unack"): return False
        new = "active_ack" if a["state"] == "active_unack" else "cleared"
        db.run("UPDATE alarms SET state=?, ack_at=?, ack_by=? WHERE id=?", (new, time.time(), user, alarm_id))
        event("info", "alarm", f"ACK by {user}: {a['message']}", a["site_id"], a["device_id"])
        return True

def notify(alarm_id):
    a = db.one("SELECT a.*, s.name site_name FROM alarms a LEFT JOIN sites s ON s.id=a.site_id WHERE a.id=?", (alarm_id,))
    for n in db.q("SELECT * FROM notif_settings WHERE enabled=1"):
        if RANK[a["priority"]] < RANK[n["min_priority"]]: continue
        if n["channel"] == "webhook":
            threading.Thread(target=_webhook, args=(n["target"], a), daemon=True).start()

def _webhook(url, a):
    try:
        body = json.dumps({"source": "TBox SCADA", "site": a["site_name"], "priority": a["priority"], "message": a["message"], "value": a["value"], "ts": a["raised_at"]}).encode()
        urllib.request.urlopen(urllib.request.Request(url, body, {"Content-Type": "application/json"}), timeout=5).read()
    except Exception as e:
        with LOCK: event("warning", "notify", f"Webhook failed: {e}")

_edge_down = set()
def watchdog_loop(stop):
    """Raises communication alarms when a device or its edge gateway stops reporting."""
    while not stop.wait(5):
        try:
            now = time.time()
            with LOCK, db.tx():
                for d in db.q("SELECT * FROM devices WHERE enabled=1"):
                    ref = d["last_seen"] or d["created_at"]
                    if now - ref > max(15, 5 * d["poll_ms"] / 1000):
                        if d["comm_ok"]: db.run("UPDATE devices SET comm_ok=0, last_error='No data received' WHERE id=?", (d["id"],))
                        comm_change(d["id"], False, "No data received")
                for s in db.q("SELECT * FROM sites WHERE edge_last_seen IS NOT NULL"):
                    down = now - s["edge_last_seen"] > 30
                    if down and s["id"] not in _edge_down: _edge_down.add(s["id"]); event("alarm", "edge", f"Edge gateway offline: {s['name']}", s["id"])
                    if not down and s["id"] in _edge_down: _edge_down.discard(s["id"]); event("info", "edge", f"Edge gateway online: {s['name']}", s["id"])
        except Exception as e:
            print("watchdog error:", e)
