"""Edge -> server ingest. Idempotent: replays after an outage never duplicate history rows."""
import math, time
from . import db, alarms

_last_logged = {}

def process(site, payload):
    batches = payload.get("batches") or [payload]
    stats = {"samples": 0, "stored": 0}
    with alarms.LOCK, db.tx() as c:
        tags = {r["id"]: r for r in db.q("SELECT t.id, t.device_id, t.log_interval_s FROM tags t JOIN devices d ON d.id=t.device_id WHERE d.site_id=?", (site["id"],))}
        devs = {r["id"]: r for r in db.q("SELECT id, comm_ok FROM devices WHERE site_id=?", (site["id"],))}
        for b in batches:
            for did, st in (b.get("devices") or {}).items():
                did = int(did)
                if did not in devs: continue
                ok, ts = 1 if st.get("comm_ok") else 0, float(st.get("ts") or time.time())
                c.execute("UPDATE devices SET comm_ok=?, last_error=?, last_seen=CASE WHEN ?=1 THEN MAX(COALESCE(last_seen,0),?) ELSE last_seen END WHERE id=?",
                          (ok, st.get("error"), ok, ts, did))
                if ok != devs[did]["comm_ok"]: alarms.comm_change(did, bool(ok), st.get("error"))
                devs[did]["comm_ok"] = ok
            for s in b.get("samples") or []:
                tid = int(s.get("tag", -1)); t = tags.get(tid)
                if not t: continue
                stats["samples"] += 1
                ts, q, v = float(s["ts"]), s.get("q", "Good"), s.get("v")
                if q == "Good" and (v is None or not math.isfinite(float(v))): q = "Bad"
                v = float(v) if q == "Good" else None
                c.execute("""INSERT INTO tag_current(tag_id,value,ts,quality) VALUES(?,?,?,?) ON CONFLICT(tag_id) DO UPDATE SET
                             value=COALESCE(excluded.value,tag_current.value), ts=excluded.ts, quality=excluded.quality WHERE excluded.ts>=tag_current.ts""", (tid, v, ts, q))
                if q != "Good": continue
                last = _last_logged.get(tid)
                if last is None: last = (db.one("SELECT MAX(ts) m FROM history WHERE tag_id=?", (tid,)) or {}).get("m") or 0
                if ts - last >= (t["log_interval_s"] or 0) - 1e-6:
                    c.execute("INSERT OR IGNORE INTO history(tag_id,ts,value) VALUES(?,?,?)", (tid, ts, v)); stats["stored"] += 1; last = ts
                _last_logged[tid] = last
                alarms.evaluate(tid, t["device_id"], site["id"], v, ts)
        c.execute("UPDATE sites SET edge_last_seen=? WHERE id=?", (time.time(), site["id"]))
    return stats
