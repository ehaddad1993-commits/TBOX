"""Tag templates for simulator profiles. Address 'sim:<signal>' is the contract with edge/tbox_edge/drivers/simulator.py
(verified by tests/test_contract.py). Real hardware tags are NOT templated: import vendor register maps via CSV."""
# (name, description, unit, dtype, min, max, log_s, role, featured, alarms{kind:(limit,priority,deadband,delay)})
def T(n, d, u="", dt="float32", lo=None, hi=None, log=10, role="", feat=0, al=None):
    return dict(name=n, description=d, unit=u, data_type=dt, min_val=lo, max_val=hi, log_interval_s=log, role=role, featured=feat, alarms=al or {})

V = lambda n, d: T(n, d, "V", lo=0, hi=300, feat=0, al={"high": (253, "medium", 3, 5), "low": (207, "medium", 3, 5)})
PROFILE_TAGS = {
 "generator": [
  T("run_state", "0=stopped 1=running", "", "int16", 0, 1, 5, "run_state", 1),
  V("voltage_l1", "Phase L1-N voltage"), V("voltage_l2", "Phase L2-N voltage"), V("voltage_l3", "Phase L3-N voltage"),
  T("current", "Average phase current", "A", lo=0, hi=1000),
  T("frequency", "Frequency", "Hz", lo=0, hi=65, al={"high": (52, "high", 0.2, 3), "low": (48, "high", 0.2, 3)}),
  T("kw", "Active power", "kW", lo=0, hi=600, role="gen_kw", feat=1), T("kva", "Apparent power", "kVA", lo=0, hi=700),
  T("pf", "Power factor", "", lo=0, hi=1), T("rpm", "Engine speed", "rpm", lo=0, hi=2000),
  T("oil_pressure", "Oil pressure", "bar", lo=0, hi=10),
  T("coolant_temp", "Coolant temperature", "°C", lo=0, hi=130, feat=1, al={"high": (95, "high", 2, 5), "high_high": (105, "critical", 2, 0)}),
  T("battery_voltage", "Starter battery", "V", lo=0, hi=32, al={"low": (22, "medium", 0.5, 10)}),
  T("fuel_level_l", "Fuel level", "L", lo=0, hi=1000, role="fuel_level_l", feat=1, al={"low": (200, "high", 10, 30)}),
  T("fuel_level_pct", "Fuel level", "%", lo=0, hi=100),
  T("fuel_rate_lph", "Fuel consumption rate", "L/h", lo=0, hi=200, role="fuel_rate_lph"),
  T("energy_kwh", "Energy produced (counter)", "kWh", "float32", None, None, 60, "energy_gen_kwh"),
  T("run_hours", "Engine run hours (counter)", "h", "float32", None, None, 60)],
 "solar_inverter": [
  T("status", "0=standby 1=generating 2=fault", "", "int16", 0, 2, 5, "run_state", 1),
  T("pv_voltage", "PV string voltage", "V", lo=0, hi=1000), T("pv_current", "PV current", "A", lo=0, hi=100),
  T("pv_kw", "PV power", "kW", lo=0, hi=200, role="pv_kw", feat=1), T("ac_voltage", "AC voltage", "V", lo=0, hi=300),
  T("ac_frequency", "AC frequency", "Hz", lo=0, hi=65), T("ac_kw", "AC output power", "kW", lo=0, hi=200),
  T("battery_soc", "Battery state of charge", "%", lo=0, hi=100, feat=1, al={"low": (20, "high", 2, 30)}),
  T("battery_voltage", "Battery voltage", "V", lo=0, hi=600), T("battery_kw", "Battery power (+charge/-discharge)", "kW", lo=-60, hi=60),
  T("grid_kw", "Grid exchange (+import)", "kW", lo=-200, hi=400),
  T("temperature", "Inverter temperature", "°C", lo=0, hi=120, al={"high": (75, "medium", 3, 30)}),
  T("energy_today_kwh", "Energy today", "kWh", lo=None, hi=None, log=60),
  T("energy_total_kwh", "Energy total (counter)", "kWh", "float32", None, None, 60, "energy_pv_kwh")],
 "energy_meter": [
  V("voltage_l1", "L1-N voltage"), V("voltage_l2", "L2-N voltage"), V("voltage_l3", "L3-N voltage"),
  T("current_l1", "L1 current", "A", lo=0, hi=1000), T("current_l2", "L2 current", "A", lo=0, hi=1000), T("current_l3", "L3 current", "A", lo=0, hi=1000),
  T("kw", "Active power", "kW", lo=0, hi=500, role="grid_kw", feat=1), T("kva", "Apparent power", "kVA", lo=0, hi=600),
  T("kvar", "Reactive power", "kvar", lo=0, hi=400), T("pf", "Power factor", "", lo=0, hi=1, al={"low": (0.8, "low", 0.02, 60)}),
  T("frequency", "Frequency", "Hz", lo=0, hi=65, feat=1),
  T("import_kwh", "Imported energy (counter)", "kWh", "float32", None, None, 60, "energy_import_kwh"),
  T("export_kwh", "Exported energy (counter)", "kWh", "float32", None, None, 60, "energy_export_kwh")],
 "plc_station": [
  T("pump_run", "Pump running", "", "bool", 0, 1, 5, "run_state", 1),
  T("tank_level_pct", "Tank level", "%", lo=0, hi=100, feat=1, al={"low": (15, "high", 2, 10), "high": (95, "medium", 1, 5)}),
  T("pressure_bar", "Line pressure", "bar", lo=0, hi=10, feat=1, al={"low": (2.0, "medium", 0.1, 10), "high": (5.0, "high", 0.1, 5)}),
  T("flow_m3h", "Flow", "m³/h", lo=0, hi=100), T("pump_current", "Pump motor current", "A", lo=0, hi=40),
  T("motor_temp", "Motor temperature", "°C", lo=0, hi=120, al={"high": (80, "high", 3, 10)}),
  T("bulk_fuel_pct", "Bulk fuel tank level", "%", lo=0, hi=100, feat=1, al={"low": (20, "high", 2, 30)})],
 "vfd": [
  T("running", "Drive running", "", "bool", 0, 1, 5, "run_state", 1),
  T("freq_actual", "Output frequency", "Hz", lo=0, hi=60, feat=1), T("freq_setpoint", "Frequency setpoint", "Hz", lo=0, hi=60),
  T("speed_rpm", "Motor speed", "rpm", lo=0, hi=1800), T("current", "Motor current", "A", lo=0, hi=60),
  T("power_kw", "Output power", "kW", lo=0, hi=30, feat=1), T("dc_bus_v", "DC bus voltage", "V", lo=0, hi=800),
  T("drive_temp", "Heatsink temperature", "°C", lo=0, hi=120, al={"high": (75, "high", 3, 10)}),
  T("fault_code", "Fault code (0=none)", "", "int16", 0, 100, 5, "", 0, {"high": (0.5, "critical", 0, 0)})],
}

def create_tags(db, device_id, profile, now):
    n = 0
    for t in PROFILE_TAGS.get(profile, []):
        tid = db.run("""INSERT INTO tags(device_id,name,description,address,reg_type,data_type,unit,min_val,max_val,log_interval_s,role,featured,created_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (device_id, t["name"], t["description"], "sim:" + t["name"], "sim", t["data_type"], t["unit"], t["min_val"], t["max_val"],
                      t["log_interval_s"], t["role"], t["featured"], now))
        for kind, (lim, pri, dbd, dly) in t["alarms"].items():
            db.run("INSERT INTO alarm_defs(tag_id,kind,limit_val,priority,deadband,delay_s) VALUES(?,?,?,?,?,?)", (tid, kind, lim, pri, dbd, dly))
        n += 1
    return n
