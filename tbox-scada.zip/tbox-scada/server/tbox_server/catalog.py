"""Driver catalog shown in the Device Manager. Status is deliberately honest: only 'implemented' drivers talk to hardware."""
DRIVERS = {
 "simulator": dict(name="Simulator (development)", status="implemented", params=[
    dict(key="utc_offset_h", label="Simulated UTC offset (h)", type="number", default=0)],
  requirements="None. Generates deterministic generator / solar / meter / PLC / VFD data for development and demos."),
 "modbus_tcp": dict(name="Modbus TCP (Ethernet)", status="implemented", params=[
    dict(key="host", label="IP address / host", type="text", default="192.168.1.10"),
    dict(key="port", label="TCP port", type="number", default=502),
    dict(key="unit_id", label="Unit / slave ID", type="number", default=1),
    dict(key="timeout_ms", label="Timeout (ms)", type="number", default=2000),
    dict(key="addr_offset", label="Address offset (-1 if vendor docs are 1-based)", type="number", default=0)],
  requirements="Read-only in this build (FC 01/02/03/04). The device must have its Modbus TCP server enabled and be reachable from the EDGE gateway on the plant LAN (never from the internet). Register addresses come from the vendor register map. Also used for RS-485 devices behind a Modbus TCP-to-RTU gateway: point host at the gateway and set unit_id to the slave ID."),
 "modbus_rtu": dict(name="Modbus RTU (RS-485)", status="via_gateway", params=[],
  requirements="Use an RS-485 to Ethernet gateway in Modbus TCP-to-RTU mode and the 'modbus_tcp' driver today. Native serial polling from the edge PC is planned (needs a USB-RS485 adapter, baud/parity/stop settings)."),
 "deye": dict(name="Deye solar inverter", status="planned", params=[],
  requirements="Register map is model- and firmware-specific: obtain Deye's Modbus protocol document for your exact inverter. Connection is typically RS-485 Modbus RTU or the data-logger's network interface. Until a dedicated driver exists, configure tags manually (CSV import) on a modbus_tcp device via a gateway."),
 "socomec": dict(name="Socomec energy meter", status="planned", params=[],
  requirements="Socomec DIRIS/COUNTIS meters expose Modbus RTU or TCP depending on model/comm module. Use the model's Modbus map from Socomec documentation; import it as tags on a modbus_tcp device. A pre-built template needs hardware verification."),
 "dse": dict(name="DSE generator controller", status="planned", params=[],
  requirements="DSE controllers expose Modbus via RS-485 or an Ethernet/gateway module depending on model. Use DSE's published register list for your controller and enable Modbus in DSE Configuration Suite. Start read-only; engine protection stays in the controller."),
 "mqtt": dict(name="MQTT subscriber", status="planned", params=[], requirements="Planned: subscribe to broker topics and map JSON paths to tags."),
 "opcua": dict(name="OPC UA client", status="planned", params=[], requirements="Planned: browse/subscribe to node IDs with security policy and certificates."),
}
PROFILES = {
 "generator": "Generator set (simulated, DSE-style)", "solar_inverter": "Solar/hybrid inverter (simulated, Deye-style)",
 "energy_meter": "Energy meter (simulated, Socomec-style)", "plc_station": "PLC station: pump, tank, pressure, flow (simulated, M221-style)",
 "vfd": "Variable frequency drive (simulated)"}
