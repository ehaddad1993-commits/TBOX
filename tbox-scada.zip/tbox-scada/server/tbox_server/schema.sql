-- TBox SCADA schema (SQLite dialect; portable to PostgreSQL/TimescaleDB, see docs/ARCHITECTURE.md)
CREATE TABLE IF NOT EXISTS sites(
  id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, location TEXT DEFAULT '',
  timezone TEXT DEFAULT 'UTC', api_key_hash TEXT, edge_last_seen REAL, created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, full_name TEXT DEFAULT '', pw_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN('admin','operator','viewer')), can_control INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1, created_at REAL NOT NULL, last_login REAL);
CREATE TABLE IF NOT EXISTS user_sites(user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  site_id INTEGER REFERENCES sites(id) ON DELETE CASCADE, PRIMARY KEY(user_id,site_id));
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  created REAL, expires REAL, ip TEXT);
CREATE TABLE IF NOT EXISTS devices(
  id INTEGER PRIMARY KEY, site_id INTEGER NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  name TEXT NOT NULL, description TEXT DEFAULT '', kind TEXT NOT NULL, profile TEXT DEFAULT '',
  enabled INTEGER DEFAULT 1, params TEXT DEFAULT '{}', poll_ms INTEGER DEFAULT 1000,
  comm_ok INTEGER DEFAULT 1, last_error TEXT, last_seen REAL, created_at REAL NOT NULL, UNIQUE(site_id,name));
CREATE TABLE IF NOT EXISTS tags(
  id INTEGER PRIMARY KEY, device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  name TEXT NOT NULL, description TEXT DEFAULT '', address TEXT NOT NULL, reg_type TEXT DEFAULT 'holding',
  data_type TEXT DEFAULT 'float32', word_order TEXT DEFAULT 'big', scale REAL DEFAULT 1, offset REAL DEFAULT 0,
  unit TEXT DEFAULT '', min_val REAL, max_val REAL, access TEXT DEFAULT 'read' CHECK(access IN('read','write')),
  log_interval_s REAL DEFAULT 10, role TEXT DEFAULT '', featured INTEGER DEFAULT 0, enabled INTEGER DEFAULT 1,
  created_at REAL NOT NULL, UNIQUE(device_id,name));
CREATE TABLE IF NOT EXISTS tag_current(tag_id INTEGER PRIMARY KEY REFERENCES tags(id) ON DELETE CASCADE,
  value REAL, ts REAL, quality TEXT DEFAULT 'Bad', raw REAL, alarm_state TEXT);
CREATE TABLE IF NOT EXISTS history(tag_id INTEGER NOT NULL, ts REAL NOT NULL, value REAL NOT NULL,
  PRIMARY KEY(tag_id,ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS alarm_defs(id INTEGER PRIMARY KEY, tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK(kind IN('high_high','high','low','low_low')), limit_val REAL NOT NULL,
  priority TEXT DEFAULT 'medium' CHECK(priority IN('critical','high','medium','low')),
  deadband REAL DEFAULT 0, delay_s REAL DEFAULT 0, enabled INTEGER DEFAULT 1, message TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS alarms(id INTEGER PRIMARY KEY, def_id INTEGER, tag_id INTEGER, device_id INTEGER, site_id INTEGER,
  kind TEXT, priority TEXT, message TEXT, value REAL, raised_at REAL NOT NULL, ack_at REAL, ack_by TEXT, cleared_at REAL,
  state TEXT NOT NULL CHECK(state IN('active_unack','active_ack','cleared_unack','cleared')));
CREATE INDEX IF NOT EXISTS ix_alarms_state ON alarms(state); CREATE INDEX IF NOT EXISTS ix_alarms_raised ON alarms(raised_at);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, ts REAL NOT NULL, site_id INTEGER, device_id INTEGER,
  level TEXT DEFAULT 'info', category TEXT DEFAULT 'system', message TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_events_ts ON events(ts);
CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY, ts REAL NOT NULL, username TEXT, ip TEXT, action TEXT NOT NULL,
  target TEXT DEFAULT '', detail TEXT DEFAULT '', result TEXT DEFAULT 'ok');
CREATE INDEX IF NOT EXISTS ix_audit_ts ON audit_log(ts);
CREATE TABLE IF NOT EXISTS screens(id INTEGER PRIMARY KEY, site_id INTEGER NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  name TEXT NOT NULL, doc TEXT NOT NULL, updated_at REAL, updated_by TEXT);
CREATE TABLE IF NOT EXISTS commands(id INTEGER PRIMARY KEY, ts REAL NOT NULL, site_id INTEGER, device_id INTEGER, tag_id INTEGER,
  value REAL, status TEXT DEFAULT 'pending', requested_by TEXT, result TEXT);
CREATE TABLE IF NOT EXISTS notif_settings(id INTEGER PRIMARY KEY, channel TEXT NOT NULL, target TEXT NOT NULL,
  min_priority TEXT DEFAULT 'high', enabled INTEGER DEFAULT 1);
