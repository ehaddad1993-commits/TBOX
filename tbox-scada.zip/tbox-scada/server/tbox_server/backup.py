import sqlite3, time, threading
from pathlib import Path
from . import db

def make_backup(dest_dir, keep=14):
    d = Path(dest_dir); d.mkdir(parents=True, exist_ok=True)
    out = d / time.strftime("tbox-%Y%m%d-%H%M%S.db")
    dst = sqlite3.connect(out)
    with dst: db.conn().backup(dst)      # online, consistent backup (safe while the server runs)
    dst.close()
    for old in sorted(d.glob("tbox-*.db"))[:-keep]: old.unlink()
    return str(out)

def loop(stop, dest_dir, every_h=24, keep=14):
    while not stop.wait(every_h * 3600):
        try: make_backup(dest_dir, keep)
        except Exception as e: print("backup failed:", e)
