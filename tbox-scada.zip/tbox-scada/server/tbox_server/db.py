"""Thin SQLite access layer. All SQL lives behind q/one/run/tx so a PostgreSQL swap is localized."""
import sqlite3, threading
from contextlib import contextmanager
from pathlib import Path

DB_PATH = "tbox.db"
_local = threading.local()

def configure(path):
    global DB_PATH
    DB_PATH = str(path)

def conn():
    c = getattr(_local, "c", None)
    if c is None or getattr(_local, "path", None) != DB_PATH:
        c = sqlite3.connect(DB_PATH, timeout=30, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL"); c.execute("PRAGMA foreign_keys=ON"); c.execute("PRAGMA synchronous=NORMAL")
        _local.c, _local.path = c, DB_PATH
    return c

def init():
    conn().executescript(Path(__file__).with_name("schema.sql").read_text())

def q(sql, args=()):
    return [dict(r) for r in conn().execute(sql, args).fetchall()]

def one(sql, args=()):
    r = conn().execute(sql, args).fetchone()
    return dict(r) if r else None

def run(sql, args=()):
    return conn().execute(sql, args).lastrowid

@contextmanager
def tx():
    c = conn()
    if c.in_transaction:      # nested: join the outer transaction
        yield c; return
    c.execute("BEGIN IMMEDIATE")
    try:
        yield c
        c.execute("COMMIT")
    except BaseException:
        c.execute("ROLLBACK"); raise
