import csv, io, json, os, secrets, threading, time
from pathlib import Path
from flask import Flask, g, jsonify, request, send_from_directory, Response
from . import db, auth, alarms, reports, catalog, templates, ingest, backup
from .auth import ApiError, require, require_edge, audit

VERSION = "0.1.0"
DTYPES = {"bool", "int16", "uint16", "int32", "uint32", "float32"}
REGTYPES = {"holding", "input", "coil", "discrete", "sim"}
TAG_FIELDS = ["name", "description", "address", "reg_type", "data_type", "word_order", "scale", "offset", "unit", "min_val", "max_val", "access", "log_interval_s", "role", "featured", "enabled"]
DEV_FIELDS = ["name", "description", "kind", "profile", "enabled", "poll_ms"]
_pending_writes = {}

def create_app(db_path=None, background=True):
    root = Path(__file__).resolve().parents[2]
    app = Flask(__name__, static_folder=None)
    db.configure(db_path or os.environ.get("TBOX_DB", "tbox.db")); db.init()
    web_dir = Path(os.environ.get("TBOX_WEB_DIR", root / "web"))
    app.config["COMMANDS_ENABLED"] = os.environ.get("TBOX_COMMANDS_ENABLED", "false").lower() == "true"
    _bootstrap_admin()
    stop = threading.Event(); app.stop = stop
    if background:
        threading.Thread(target=alarms.watchdog_loop, args=(stop,), daemon=True).start()
        threading.Thread(target=backup.loop, args=(stop, os.environ.get("TBOX_BACKUP_DIR", "backups")), daemon=True).start()

    @app.errorhandler(ApiError)
    def _api_err(e): return jsonify(error=e.code, message=e.message), e.status
    @app.errorhandler(404)
    def _404(e): return jsonify(error="not_found"), 404
    @app.errorhandler(Exception)
    def _500(e):
        if isinstance(e, ApiError): raise e
        app.logger.exception(e); return jsonify(error="server_error", message=str(e)), 500
    @app.after_request
    def _hdr(r):
        r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "same-origin",
                          "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'"})
        if request.headers.get("X-Forwarded-Proto") == "https" or request.is_secure: r.headers["Strict-Transport-Security"] = "max-age=31536000"
        if request.path.startswith("/api/"): r.headers["Cache-Control"] = "no-store"
        return r

    body = lambda: request.get_json(silent=True) or {}
    def need(d, *keys):
        for k in keys:
            if d.get(k) in (None, ""): raise ApiError(400, "missing_field", f"'{k}' is required")
    def update_row(table, id_, d, fields):
        s = [f for f in fields if f in d]
        if s: db.run(f"UPDATE {table} SET " + ",".join(f"{f}=?" for f in s) + " WHERE id=?", [d[f] for f in s] + [id_])
    def intarg(n, default=None):
        v = request.args.get(n); return int(v) if v not in (None, "") else default
    def visible_sites():
        sid = intarg("site_id")
        if sid is not None: auth.check_site(sid); return [sid]
        return auth.site_ids() or [-1]
    ph = lambda xs: ",".join("?" * len(xs))
    def device_site(did):
        d = db.one("SELECT * FROM devices WHERE id=?", (did,))
        if not d: raise ApiError(404, "not_found", "Device not found")
        auth.check_site(d["site_id"]); return d
    def tag_row(tid):
        t = db.one("SELECT t.*, d.site_id, d.name device_name FROM tags t JOIN devices d ON d.id=t.device_id WHERE t.id=?", (tid,))
        if not t: raise ApiError(404, "not_found", "Tag not found")
        auth.check_site(t["site_id"]); return t

    # ---------- system / auth ----------
    @app.get("/api/health")
    def health(): return jsonify(ok=True, version=VERSION, time=time.time(), commands_enabled=app.config["COMMANDS_ENABLED"])
    @app.post("/api/auth/login")
    def login():
        d = body(); tok, u = auth.login(d.get("username", ""), d.get("password", ""))
        return jsonify(token=tok, user=auth.public_user(u), commands_enabled=app.config["COMMANDS_ENABLED"])
    @app.post("/api/auth/logout")
    @require()
    def logout():
        db.run("DELETE FROM sessions WHERE token_hash=?", (auth.sha(g.token),)); audit("logout"); return jsonify(ok=True)
    @app.get("/api/auth/me")
    @require()
    def me(): return jsonify(user=auth.public_user(g.user), commands_enabled=app.config["COMMANDS_ENABLED"])
    @app.get("/api/drivers")
    @require()
    def drivers(): return jsonify(drivers=catalog.DRIVERS, profiles=catalog.PROFILES)

    # ---------- sites ----------
    @app.get("/api/sites")
    @require()
    def sites():
        ids = auth.site_ids()
        rows = db.q(f"SELECT id,code,name,location,timezone,edge_last_seen FROM sites WHERE id IN ({ph(ids)}) ORDER BY name", ids) if ids else []
        for s in rows: s["edge_online"] = bool(s["edge_last_seen"] and time.time() - s["edge_last_seen"] < 30)
        return jsonify(sites=rows)
    @app.post("/api/sites")
    @require("admin")
    def site_create():
        d = body(); need(d, "code", "name"); key = secrets.token_urlsafe(32)
        try: sid = db.run("INSERT INTO sites(code,name,location,timezone,api_key_hash,created_at) VALUES(?,?,?,?,?,?)",
                          (d["code"], d["name"], d.get("location", ""), d.get("timezone", "UTC"), auth.sha(key), time.time()))
        except Exception as e: raise ApiError(409, "conflict", str(e))
        audit("site.create", d["code"]); return jsonify(id=sid, api_key=key, note="Store this key in the edge config now; it is not shown again."), 201
    @app.put("/api/sites/<int:sid>")
    @require("admin")
    def site_update(sid): update_row("sites", sid, body(), ["name", "location", "timezone"]); audit("site.update", sid); return jsonify(ok=True)
    @app.post("/api/sites/<int:sid>/rotate-key")
    @require("admin")
    def site_rotate(sid):
        key = secrets.token_urlsafe(32); db.run("UPDATE sites SET api_key_hash=? WHERE id=?", (auth.sha(key), sid)); audit("site.rotate_key", sid)
        return jsonify(api_key=key)

    # ---------- devices ----------
    @app.get("/api/devices")
    @require()
    def devices():
        s = visible_sites(); now = time.time()
        rows = db.q(f"SELECT * FROM devices WHERE site_id IN ({ph(s)}) ORDER BY site_id, name", s)
        alarm_devs = {r["device_id"] for r in db.q("SELECT DISTINCT device_id FROM alarms WHERE state IN ('active_unack','active_ack') AND kind!='comm'")}
        for d in rows:
            d["params"] = json.loads(d["params"] or "{}"); d["status"] = _status(d, alarm_devs, now)
            d["tag_count"] = db.one("SELECT COUNT(*) n FROM tags WHERE device_id=?", (d["id"],))["n"]
        return jsonify(devices=rows)
    def _status(d, alarm_devs, now):
        if not d["enabled"]: return "Offline"
        if not d["comm_ok"] or now - (d["last_seen"] or 0) > max(15, 5 * d["poll_ms"] / 1000): return "CommLost"
        return "Alarm" if d["id"] in alarm_devs else "Online"
    @app.post("/api/devices")
    @require("admin")
    def device_create():
        d = body(); need(d, "site_id", "name", "kind"); auth.check_site(int(d["site_id"]))
        if d["kind"] not in catalog.DRIVERS: raise ApiError(400, "bad_kind", "Unknown driver kind")
        if int(d.get("poll_ms", 1000)) < 100: raise ApiError(400, "bad_poll", "poll_ms must be >= 100")
        try: did = db.run("INSERT INTO devices(site_id,name,description,kind,profile,enabled,params,poll_ms,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                          (d["site_id"], d["name"], d.get("description", ""), d["kind"], d.get("profile", ""), int(d.get("enabled", 1)), json.dumps(d.get("params") or {}), int(d.get("poll_ms", 1000)), time.time()))
        except Exception as e: raise ApiError(409, "conflict", str(e))
        n = templates.create_tags(db, did, d.get("profile", ""), time.time()) if d["kind"] == "simulator" else 0
        alarms.invalidate(); alarms.event("info", "config", f"Device added: {d['name']} ({d['kind']})", d["site_id"], did); audit("device.create", d["name"], d["kind"])
        return jsonify(id=did, tags_created=n), 201
    @app.put("/api/devices/<int:did>")
    @require("admin")
    def device_update(did):
        dev = device_site(did); d = body()
        if "params" in d: db.run("UPDATE devices SET params=? WHERE id=?", (json.dumps(d["params"]), did))
        update_row("devices", did, d, DEV_FIELDS); alarms.event("info", "config", f"Device changed: {dev['name']}", dev["site_id"], did); audit("device.update", dev["name"], list(d))
        return jsonify(ok=True)
    @app.delete("/api/devices/<int:did>")
    @require("admin")
    def device_delete(did):
        dev = device_site(did); db.run("DELETE FROM devices WHERE id=?", (did,)); alarms.invalidate()
        alarms.event("warning", "config", f"Device removed: {dev['name']}", dev["site_id"]); audit("device.delete", dev["name"]); return jsonify(ok=True)

    # ---------- tags ----------
    def _validate_tag(d, partial=False):
        if d.get("data_type") and d["data_type"] not in DTYPES: raise ApiError(400, "bad_data_type", f"data_type must be one of {sorted(DTYPES)}")
        if d.get("reg_type") and d["reg_type"] not in REGTYPES: raise ApiError(400, "bad_reg_type", f"reg_type must be one of {sorted(REGTYPES)}")
        if d.get("access") and d["access"] not in ("read", "write"): raise ApiError(400, "bad_access", "access must be read or write")
        for k in ("scale", "offset", "min_val", "max_val", "log_interval_s"):
            if k not in d: continue
            if d[k] in ("", None):
                if k in ("min_val", "max_val"): d[k] = None
                else: d.pop(k)
            else:
                try: d[k] = float(d[k])
                except (TypeError, ValueError): raise ApiError(400, "bad_number", f"{k} must be numeric")
        if d.get("log_interval_s") is not None and d["log_interval_s"] < 1: raise ApiError(400, "bad_log_interval", "log_interval_s must be >= 1")
    @app.get("/api/tags")
    @require()
    def tags():
        s = visible_sites(); sql = f"SELECT t.*, d.name device_name, d.site_id FROM tags t JOIN devices d ON d.id=t.device_id WHERE d.site_id IN ({ph(s)})"; a = list(s)
        if intarg("device_id"): sql += " AND t.device_id=?"; a.append(intarg("device_id"))
        return jsonify(tags=db.q(sql + " ORDER BY d.name, t.name", a))
    @app.post("/api/tags")
    @require("admin")
    def tag_create():
        d = body(); need(d, "device_id", "name", "address"); device_site(int(d["device_id"])); _validate_tag(d)
        cols = ["device_id"] + [f for f in TAG_FIELDS if f in d and f not in ("enabled",)]
        try: tid = db.run(f"INSERT INTO tags({','.join(cols)},created_at) VALUES({ph(cols)},?)", [d[c] for c in cols] + [time.time()])
        except Exception as e: raise ApiError(409, "conflict", str(e))
        audit("tag.create", d["name"]); return jsonify(id=tid), 201
    @app.put("/api/tags/<int:tid>")
    @require("admin")
    def tag_update(tid):
        t = tag_row(tid); d = body(); _validate_tag(d, True); update_row("tags", tid, d, TAG_FIELDS); alarms.invalidate(); audit("tag.update", t["name"], list(d)); return jsonify(ok=True)
    @app.delete("/api/tags/<int:tid>")
    @require("admin")
    def tag_delete(tid):
        t = tag_row(tid); db.run("DELETE FROM tags WHERE id=?", (tid,)); alarms.invalidate(); audit("tag.delete", t["name"]); return jsonify(ok=True)
    CSV_COLS = ["name", "description", "address", "reg_type", "data_type", "word_order", "scale", "offset", "unit", "min_val", "max_val", "access", "log_interval_s", "role"]
    @app.get("/api/tags/export.csv")
    @require()
    def tags_export():
        s = visible_sites(); sql = f"SELECT t.* FROM tags t JOIN devices d ON d.id=t.device_id WHERE d.site_id IN ({ph(s)})"; a = list(s)
        if intarg("device_id"): sql += " AND t.device_id=?"; a.append(intarg("device_id"))
        out = io.StringIO(); w = csv.writer(out); w.writerow(CSV_COLS)
        for t in db.q(sql + " ORDER BY t.id", a): w.writerow([t[c] if t[c] is not None else "" for c in CSV_COLS])
        return Response(out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=tags.csv"})
    @app.post("/api/tags/import")
    @require("admin")
    def tags_import():
        d = body(); need(d, "device_id", "csv"); dev = device_site(int(d["device_id"])); added = updated = 0; errors = []
        for i, row in enumerate(csv.DictReader(io.StringIO(d["csv"])), start=2):
            row = {k.strip(): (v or "").strip() for k, v in row.items() if k}
            try:
                if not row.get("name") or not row.get("address"): raise ApiError(400, "x", "name and address are required")
                row = {k: v for k, v in row.items() if v != "" and k in CSV_COLS}; _validate_tag(row, True)
                ex = db.one("SELECT id FROM tags WHERE device_id=? AND name=?", (dev["id"], row["name"]))
                if ex: update_row("tags", ex["id"], row, TAG_FIELDS); updated += 1
                else:
                    cols = ["device_id"] + list(row); db.run(f"INSERT INTO tags({','.join(cols)},created_at) VALUES({ph(cols)},?)", [dev["id"]] + list(row.values()) + [time.time()]); added += 1
            except ApiError as e: errors.append(f"line {i}: {e.message}")
            except Exception as e: errors.append(f"line {i}: {e}")
        audit("tag.import", dev["name"], f"added={added} updated={updated} errors={len(errors)}"); return jsonify(added=added, updated=updated, errors=errors)

    # ---------- live / history ----------
    @app.get("/api/live")
    @require()
    def live():
        s = visible_sites(); now = time.time()
        devs = devices().json["devices"]
        rows = db.q(f"""SELECT tc.tag_id,tc.value,tc.ts,tc.quality,tc.alarm_state,d.poll_ms FROM tag_current tc JOIN tags t ON t.id=tc.tag_id
                        JOIN devices d ON d.id=t.device_id WHERE d.site_id IN ({ph(s)})""", s)
        tg = {str(r["tag_id"]): [r["value"], r["ts"], "Stale" if r["quality"] == "Good" and now - (r["ts"] or 0) > max(5, 3 * r["poll_ms"] / 1000) else r["quality"], r["alarm_state"]] for r in rows}
        a = db.one(f"""SELECT COUNT(*) active, SUM(state IN ('active_unack','cleared_unack')) unack, SUM(priority='critical' AND state IN ('active_unack','active_ack')) critical
                       FROM alarms WHERE site_id IN ({ph(s)}) AND state!='cleared'""", s)
        sites_ = db.q(f"SELECT id, edge_last_seen FROM sites WHERE id IN ({ph(s)})", s)
        return jsonify(ts=now, devices=[{k: d[k] for k in ("id", "site_id", "name", "status", "last_seen")} for d in devs], tags=tg,
                       alarms={"active": a["active"] or 0, "unack": a["unack"] or 0, "critical": a["critical"] or 0},
                       edge={str(x["id"]): bool(x["edge_last_seen"] and now - x["edge_last_seen"] < 30) for x in sites_})
    @app.get("/api/history")
    @require()
    def history():
        ids = [int(x) for x in request.args.get("tags", "").split(",") if x]
        if not ids or len(ids) > 12: raise ApiError(400, "bad_tags", "Provide 1-12 tag ids")
        t1 = float(request.args.get("to") or time.time()); t0 = float(request.args.get("from") or t1 - 3600); mp = min(int(request.args.get("max_points", 600)), 5000)
        bsize = max(1.0, (t1 - t0) / mp); out = {}
        for tid in ids:
            tag_row(tid)
            out[str(tid)] = [[r["t"], r["a"], r["lo"], r["hi"]] for r in db.q(
                "SELECT MIN(ts) t, AVG(value) a, MIN(value) lo, MAX(value) hi FROM history WHERE tag_id=? AND ts BETWEEN ? AND ? GROUP BY CAST((ts-?)/? AS INTEGER) ORDER BY 1", (tid, t0, t1, t0, bsize))]
        return jsonify(from_=t0, to=t1, bucket_s=bsize, series=out)

    # ---------- control (disabled by default) ----------
    @app.post("/api/tags/<int:tid>/write")
    @require("operator")
    def tag_write(tid):
        t = tag_row(tid); d = body()
        def deny(code, msg, status=403):
            audit("write", f"{t['device_name']}.{t['name']}", f"value={d.get('value')} reason={code}", "denied"); raise ApiError(status, code, msg)
        if not app.config["COMMANDS_ENABLED"]: deny("control_disabled", "Server is in read-only monitoring mode (TBOX_COMMANDS_ENABLED=false)")
        if not g.user["can_control"]: deny("no_control_permission", "Your account has no control permission")
        if t["access"] != "write": deny("tag_read_only", "Tag is configured read-only")
        try: val = float(d.get("value"))
        except (TypeError, ValueError): deny("bad_value", "Numeric value required", 400)
        if (t["min_val"] is not None and val < t["min_val"]) or (t["max_val"] is not None and val > t["max_val"]): deny("out_of_range", f"Value outside {t['min_val']}..{t['max_val']}", 400)
        tok = d.get("confirm_token")
        if not tok:
            tok = secrets.token_urlsafe(12); _pending_writes[tok] = (g.user["id"], tid, val, time.time() + 30)
            audit("write.request", f"{t['device_name']}.{t['name']}", f"value={val}", "pending")
            return jsonify(confirm_required=True, token=tok, summary=f"Write {val:g} {t['unit']} to {t['device_name']}.{t['name']}", expires_in=30), 202
        p = _pending_writes.pop(tok, None)
        if not p or p[:3] != (g.user["id"], tid, val) or p[3] < time.time(): deny("confirm_invalid", "Confirmation expired or does not match", 400)
        cid = db.run("INSERT INTO commands(ts,site_id,device_id,tag_id,value,requested_by) VALUES(?,?,?,?,?,?)", (time.time(), t["site_id"], t["device_id"], tid, val, g.user["username"]))
        audit("write.confirmed", f"{t['device_name']}.{t['name']}", f"value={val} command={cid}"); return jsonify(queued=True, command_id=cid), 202

    # ---------- alarms / events / audit ----------
    @app.get("/api/alarms")
    @require()
    def alarm_list():
        s = visible_sites(); mode = request.args.get("state", "active")
        w = "state!='cleared'" if mode == "active" else "1=1"
        rows = db.q(f"SELECT a.*, d.name device_name FROM alarms a LEFT JOIN devices d ON d.id=a.device_id WHERE a.site_id IN ({ph(s)}) AND {w} ORDER BY a.raised_at DESC LIMIT ?", (*s, intarg("limit", 500)))
        return jsonify(alarms=rows)
    @app.post("/api/alarms/<int:aid>/ack")
    @require("operator")
    def alarm_ack(aid):
        a = db.one("SELECT site_id FROM alarms WHERE id=?", (aid,))
        if not a: raise ApiError(404, "not_found"); 
        auth.check_site(a["site_id"]); ok = alarms.ack(aid, g.user["username"]); audit("alarm.ack", aid); return jsonify(ok=ok)
    @app.post("/api/alarms/ack-all")
    @require("operator")
    def alarm_ack_all():
        n = 0
        for a in db.q(f"SELECT id FROM alarms WHERE state IN ('active_unack','cleared_unack') AND site_id IN ({ph(visible_sites())})", visible_sites()): n += alarms.ack(a["id"], g.user["username"])
        audit("alarm.ack_all", detail=n); return jsonify(acked=n)
    @app.get("/api/alarm-defs")
    @require()
    def defs_list():
        s = visible_sites()
        return jsonify(defs=db.q(f"""SELECT a.*, t.name tag_name, t.unit, d.name device_name FROM alarm_defs a JOIN tags t ON t.id=a.tag_id JOIN devices d ON d.id=t.device_id
                                     WHERE d.site_id IN ({ph(s)}) ORDER BY d.name, t.name, a.kind""", s))
    @app.post("/api/alarm-defs")
    @require("admin")
    def defs_create():
        d = body(); need(d, "tag_id", "kind", "limit_val"); tag_row(int(d["tag_id"]))
        if d["kind"] not in ("high_high", "high", "low", "low_low"): raise ApiError(400, "bad_kind")
        i = db.run("INSERT INTO alarm_defs(tag_id,kind,limit_val,priority,deadband,delay_s,message) VALUES(?,?,?,?,?,?,?)",
                   (d["tag_id"], d["kind"], float(d["limit_val"]), d.get("priority", "medium"), float(d.get("deadband", 0)), float(d.get("delay_s", 0)), d.get("message", "")))
        alarms.invalidate(); audit("alarmdef.create", i); return jsonify(id=i), 201
    @app.put("/api/alarm-defs/<int:i>")
    @require("admin")
    def defs_update(i): update_row("alarm_defs", i, body(), ["kind", "limit_val", "priority", "deadband", "delay_s", "enabled", "message"]); alarms.invalidate(); audit("alarmdef.update", i); return jsonify(ok=True)
    @app.delete("/api/alarm-defs/<int:i>")
    @require("admin")
    def defs_delete(i): db.run("DELETE FROM alarm_defs WHERE id=?", (i,)); alarms.invalidate(); audit("alarmdef.delete", i); return jsonify(ok=True)
    @app.get("/api/notifications")
    @require("admin")
    def notif_list(): return jsonify(notifications=db.q("SELECT * FROM notif_settings"))
    @app.post("/api/notifications")
    @require("admin")
    def notif_create():
        d = body(); need(d, "target")
        if not str(d["target"]).startswith(("http://", "https://")): raise ApiError(400, "bad_target", "Webhook URL must start with http(s)://")
        i = db.run("INSERT INTO notif_settings(channel,target,min_priority) VALUES('webhook',?,?)", (d["target"], d.get("min_priority", "high"))); audit("notify.create", d["target"]); return jsonify(id=i), 201
    @app.delete("/api/notifications/<int:i>")
    @require("admin")
    def notif_delete(i): db.run("DELETE FROM notif_settings WHERE id=?", (i,)); audit("notify.delete", i); return jsonify(ok=True)
    @app.get("/api/events")
    @require()
    def events():
        s = visible_sites(); return jsonify(events=db.q(f"SELECT * FROM events WHERE (site_id IN ({ph(s)}) OR site_id IS NULL) ORDER BY ts DESC LIMIT ?", (*s, intarg("limit", 300))))
    @app.get("/api/audit")
    @require("admin")
    def audit_list(): return jsonify(audit=db.q("SELECT * FROM audit_log ORDER BY ts DESC LIMIT ?", (intarg("limit", 500),)))

    # ---------- reports ----------
    @app.get("/api/reports/<kind>")
    @require()
    def report(kind):
        if kind not in reports.KINDS: raise ApiError(404, "bad_report")
        s = visible_sites(); period = request.args.get("period", "day")
        if period not in reports.FMT: raise ApiError(400, "bad_period")
        t1 = float(request.args.get("to") or time.time()); t0 = float(request.args.get("from") or t1 - 7 * 86400)
        tzname = request.args.get("tz") or (db.one("SELECT timezone FROM sites WHERE id=?", (s[0],)) or {}).get("timezone", "UTC") if len(s) == 1 else "UTC"
        rep = reports.KINDS[kind](s, period, t0, t1, tzname)
        meta = f"Range: {time.strftime('%Y-%m-%d %H:%M', time.gmtime(t0))} to {time.strftime('%Y-%m-%d %H:%M', time.gmtime(t1))} UTC | timezone for buckets: {tzname}"
        fmt = request.args.get("format", "json"); audit("report", kind, f"{period} {fmt}")
        if fmt == "xlsx": return Response(reports.to_xlsx(rep, meta), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f"attachment; filename={kind}-{period}.xlsx"})
        if fmt == "pdf": return Response(reports.to_pdf(rep, meta), mimetype="application/pdf", headers={"Content-Disposition": f"attachment; filename={kind}-{period}.pdf"})
        return jsonify({**rep, "meta": meta})

    # ---------- HMI screens ----------
    def _doc(d):
        doc = d.get("doc")
        if not isinstance(doc, dict) or not isinstance(doc.get("widgets"), list): raise ApiError(400, "bad_doc", "doc.widgets must be a list")
        s = json.dumps(doc)
        if len(s) > 500_000: raise ApiError(400, "doc_too_large")
        return s
    @app.get("/api/screens")
    @require()
    def screens_list():
        s = visible_sites(); return jsonify(screens=db.q(f"SELECT id,site_id,name,updated_at,updated_by FROM screens WHERE site_id IN ({ph(s)}) ORDER BY name", s))
    @app.get("/api/screens/<int:i>")
    @require()
    def screen_get(i):
        r = db.one("SELECT * FROM screens WHERE id=?", (i,))
        if not r: raise ApiError(404, "not_found")
        auth.check_site(r["site_id"]); r["doc"] = json.loads(r["doc"]); return jsonify(r)
    @app.post("/api/screens")
    @require("admin")
    def screen_create():
        d = body(); need(d, "site_id", "name"); auth.check_site(int(d["site_id"]))
        i = db.run("INSERT INTO screens(site_id,name,doc,updated_at,updated_by) VALUES(?,?,?,?,?)", (d["site_id"], d["name"], _doc(d), time.time(), g.user["username"])); audit("screen.create", d["name"]); return jsonify(id=i), 201
    @app.put("/api/screens/<int:i>")
    @require("admin")
    def screen_update(i):
        d = body(); r = db.one("SELECT site_id FROM screens WHERE id=?", (i,))
        if not r: raise ApiError(404, "not_found")
        auth.check_site(r["site_id"])
        db.run("UPDATE screens SET name=COALESCE(?,name), doc=?, updated_at=?, updated_by=? WHERE id=?", (d.get("name"), _doc(d), time.time(), g.user["username"], i)); audit("screen.update", i); return jsonify(ok=True)
    @app.delete("/api/screens/<int:i>")
    @require("admin")
    def screen_delete(i): db.run("DELETE FROM screens WHERE id=?", (i,)); audit("screen.delete", i); return jsonify(ok=True)

    # ---------- users ----------
    @app.get("/api/users")
    @require("admin")
    def users_list():
        rows = db.q("SELECT id,username,full_name,role,can_control,active,last_login FROM users ORDER BY username")
        for u in rows: u["site_ids"] = [r["site_id"] for r in db.q("SELECT site_id FROM user_sites WHERE user_id=?", (u["id"],))]
        return jsonify(users=rows)
    def _set_sites(uid, ids):
        db.run("DELETE FROM user_sites WHERE user_id=?", (uid,))
        for s in ids or []: db.run("INSERT OR IGNORE INTO user_sites(user_id,site_id) VALUES(?,?)", (uid, int(s)))
    @app.post("/api/users")
    @require("admin")
    def user_create():
        d = body(); need(d, "username", "password", "role")
        if len(d["password"]) < 8: raise ApiError(400, "weak_password", "Password must be at least 8 characters")
        if d["role"] not in auth.RANK: raise ApiError(400, "bad_role")
        try: uid = db.run("INSERT INTO users(username,full_name,pw_hash,role,can_control,created_at) VALUES(?,?,?,?,?,?)", (d["username"], d.get("full_name", ""), auth.hash_pw(d["password"]), d["role"], int(bool(d.get("can_control"))), time.time()))
        except Exception as e: raise ApiError(409, "conflict", str(e))
        _set_sites(uid, d.get("site_ids")); audit("user.create", d["username"], d["role"]); return jsonify(id=uid), 201
    @app.put("/api/users/<int:uid>")
    @require("admin")
    def user_update(uid):
        d = body()
        if uid == g.user["id"] and (d.get("active") == 0 or d.get("role", "admin") != "admin"): raise ApiError(400, "self_lockout", "You cannot demote or disable yourself")
        if d.get("password"):
            if len(d["password"]) < 8: raise ApiError(400, "weak_password")
            db.run("UPDATE users SET pw_hash=? WHERE id=?", (auth.hash_pw(d["password"]), uid)); db.run("DELETE FROM sessions WHERE user_id=?", (uid,))
        update_row("users", uid, d, ["full_name", "role", "can_control", "active"])
        if "site_ids" in d: _set_sites(uid, d["site_ids"])
        audit("user.update", uid, [k for k in d if k != "password"]); return jsonify(ok=True)
    @app.delete("/api/users/<int:uid>")
    @require("admin")
    def user_delete(uid):
        if uid == g.user["id"]: raise ApiError(400, "self_lockout")
        db.run("DELETE FROM users WHERE id=?", (uid,)); audit("user.delete", uid); return jsonify(ok=True)
    @app.post("/api/admin/backup")
    @require("admin")
    def admin_backup(): p = backup.make_backup(os.environ.get("TBOX_BACKUP_DIR", "backups")); audit("backup", p); return jsonify(path=p)

    # ---------- edge gateway API (authenticated by per-site key) ----------
    @app.post("/api/ingest")
    @require_edge
    def ingest_route(): return jsonify(ingest.process(g.site, request.get_json(force=True)))
    @app.get("/api/edge/config")
    @require_edge
    def edge_config():
        db.run("UPDATE sites SET edge_last_seen=? WHERE id=?", (time.time(), g.site["id"]))
        devs = db.q("SELECT id,name,kind,profile,params,poll_ms FROM devices WHERE site_id=? AND enabled=1", (g.site["id"],))
        for d in devs:
            d["params"] = json.loads(d["params"] or "{}")
            d["tags"] = db.q("SELECT id,name,address,reg_type,data_type,word_order,scale,offset,access,unit FROM tags WHERE device_id=? AND enabled=1", (d["id"],))
        cmds = db.q("SELECT id,device_id,tag_id,value FROM commands WHERE site_id=? AND status='pending' ORDER BY id", (g.site["id"],))
        for c in cmds: db.run("UPDATE commands SET status='sent' WHERE id=?", (c["id"],))
        return jsonify(server_time=time.time(), site=g.site["code"], devices=devs, commands=cmds)
    @app.post("/api/edge/command-result")
    @require_edge
    def edge_cmd_result():
        d = body(); st = "done" if d.get("ok") else "failed"
        db.run("UPDATE commands SET status=?, result=? WHERE id=? AND site_id=?", (st, str(d.get("result", ""))[:300], d.get("id"), g.site["id"]))
        audit("command.result", d.get("id"), d.get("result", ""), st, user={"username": "edge:" + g.site["code"]}); return jsonify(ok=True)

    # ---------- static web UI ----------
    @app.get("/")
    def index(): return send_from_directory(web_dir, "index.html")
    @app.get("/<path:p>")
    def static_files(p):
        if p.startswith("api/"): raise ApiError(404, "not_found")
        return send_from_directory(web_dir, p)
    return app

def _bootstrap_admin():
    if db.one("SELECT id FROM users LIMIT 1"): return
    pw = os.environ.get("TBOX_ADMIN_PASSWORD") or secrets.token_urlsafe(12)
    db.run("INSERT INTO users(username,full_name,pw_hash,role,can_control,created_at) VALUES('admin','Administrator',?,'admin',1,?)", (auth.hash_pw(pw), time.time()))
    if not os.environ.get("TBOX_ADMIN_PASSWORD"): print(f"\n*** First start: created user 'admin' with password: {pw}  (change it!) ***\n")
