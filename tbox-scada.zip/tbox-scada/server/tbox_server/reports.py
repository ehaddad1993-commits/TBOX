"""Reports: energy, fuel, alarms, events. Returns {title, columns, rows, totals}; exporters write XLSX / PDF."""
import io, time
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from . import db

FMT = {"hour": "%Y-%m-%d %H:00", "day": "%Y-%m-%d", "month": "%Y-%m", "year": "%Y"}

def _tz(name):
    try: return ZoneInfo(name)
    except Exception: return timezone.utc

def bucket(ts, period, tz): return datetime.fromtimestamp(ts, tz).strftime(FMT[period])

def _rows(tag_id, t0, t1):
    # include one sample before the range so the first bucket has a delta
    prev = db.one("SELECT ts,value FROM history WHERE tag_id=? AND ts<? ORDER BY ts DESC LIMIT 1", (tag_id, t0))
    rows = [(r["ts"], r["value"]) for r in db.q("SELECT ts,value FROM history WHERE tag_id=? AND ts>=? AND ts<=? ORDER BY ts", (tag_id, t0, t1))]
    return ([(prev["ts"], prev["value"])] if prev else []) + rows

def counter_deltas(rows, period, tz, t0):
    """Cumulative counter (kWh): sum of positive increments per bucket. Negative step = counter reset, ignored."""
    out = {}
    for (ta, a), (tb, b) in zip(rows, rows[1:]):
        if tb < t0: continue
        d = b - a
        if d >= 0: out[bucket(tb, period, tz)] = out.get(bucket(tb, period, tz), 0) + d
    return out

def level_drops(rows, period, tz, t0, noise=0.05):
    """Tank level (L): sum of decreases per bucket. Rises (refuelling) are ignored; drops < noise L are treated as sensor noise."""
    out = {}
    for (ta, a), (tb, b) in zip(rows, rows[1:]):
        if tb < t0: continue
        d = a - b
        if d > noise: out[bucket(tb, period, tz)] = out.get(bucket(tb, period, tz), 0) + d
    return out

def rate_integral(rows, period, tz, t0):
    """Trapezoidal integral of a flow rate in L/h over time -> litres per bucket."""
    out = {}
    for (ta, a), (tb, b) in zip(rows, rows[1:]):
        if tb < t0 or tb - ta > 600: continue
        out[bucket(tb, period, tz)] = out.get(bucket(tb, period, tz), 0) + (a + b) / 2 * (tb - ta) / 3600
    return out

def _site_tags(site_ids, role):
    ph = ",".join("?" * len(site_ids))
    return db.q(f"""SELECT t.id, t.name, d.name dev, d.site_id FROM tags t JOIN devices d ON d.id=t.device_id
                    WHERE t.role=? AND d.site_id IN ({ph}) ORDER BY d.name""", (role, *site_ids))

def _keys(a, b): return sorted(set(a) | set(b))

def energy(site_ids, period, t0, t1, tzname):
    tz = _tz(tzname); cols = {"energy_import_kwh": "Grid import (kWh)", "energy_export_kwh": "Grid export (kWh)",
                              "energy_gen_kwh": "Generators (kWh)", "energy_pv_kwh": "Solar production (kWh)"}
    data = {}
    for role in cols:
        agg = {}
        for t in _site_tags(site_ids, role):
            for k, v in counter_deltas(_rows(t["id"], t0, t1), period, tz, t0).items(): agg[k] = agg.get(k, 0) + v
        data[role] = agg
    keys = sorted({k for a in data.values() for k in a})
    rows = []
    for k in keys:
        g = lambda r: round(data[r].get(k, 0), 2)
        imp, exp, gen, pv = g("energy_import_kwh"), g("energy_export_kwh"), g("energy_gen_kwh"), g("energy_pv_kwh")
        rows.append([k, imp, exp, gen, pv, round(imp + gen + pv - exp, 2)])
    totals = ["Total"] + [round(sum(r[i] for r in rows), 2) for i in range(1, 6)]
    return dict(title=f"Energy report ({period})", columns=["Period", *cols.values(), "Estimated consumption (kWh)"], rows=rows, totals=totals,
                note="Estimated consumption = grid import + generators + solar - grid export. Requires counter tags with energy_* roles.")

def fuel(site_ids, period, t0, t1, tzname):
    tz = _tz(tzname); rows = []
    for t in _site_tags(site_ids, "fuel_level_l"):
        lvl = level_drops(_rows(t["id"], t0, t1), period, tz, t0)
        rate_tag = db.one("SELECT id FROM tags WHERE device_id=(SELECT device_id FROM tags WHERE id=?) AND role='fuel_rate_lph'", (t["id"],))
        rate = rate_integral(_rows(rate_tag["id"], t0, t1), period, tz, t0) if rate_tag else {}
        for k in _keys(lvl, rate):
            rows.append([k, t["dev"], round(lvl.get(k, 0), 1), round(rate.get(k, 0), 1) if rate_tag else None])
    rows.sort(key=lambda r: (r[0], r[1]))
    tot = ["Total", "", round(sum(r[2] for r in rows), 1), round(sum(r[3] or 0 for r in rows), 1)]
    return dict(title=f"Fuel consumption report ({period})", columns=["Period", "Generator", "Consumed from level (L)", "Consumed from flow rate (L)"], rows=rows, totals=tot,
                note="Level-based = sum of tank level decreases (refuels ignored, drops <0.05 L treated as noise). Flow-based = integral of fuel-rate tag.")

def alarms_report(site_ids, period, t0, t1, tzname):
    tz = _tz(tzname); ph = ",".join("?" * len(site_ids)); f = lambda x: datetime.fromtimestamp(x, tz).strftime("%Y-%m-%d %H:%M:%S") if x else ""
    rows = [[f(a["raised_at"]), a["priority"], a["kind"], a["message"], a["value"], f(a["ack_at"]), a["ack_by"] or "", f(a["cleared_at"])] for a in
            db.q(f"SELECT * FROM alarms WHERE site_id IN ({ph}) AND raised_at BETWEEN ? AND ? ORDER BY raised_at DESC", (*site_ids, t0, t1))]
    return dict(title="Alarm history", columns=["Raised", "Priority", "Type", "Message", "Value", "Acknowledged", "Ack by", "Cleared"], rows=rows, totals=None, note="")

KINDS = {"energy": energy, "fuel": fuel, "alarms": alarms_report}

def to_xlsx(rep, meta):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = Workbook(); ws = wb.active; ws.title = "Report"
    ws.append(["TBox SCADA - Technical Power Systems"]); ws["A1"].font = Font(bold=True, size=14)
    ws.append([rep["title"]]); ws.append([meta]); ws.append([])
    ws.append(rep["columns"])
    for c in ws[5]: c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1F2A44"); c.alignment = Alignment(wrap_text=True)
    for r in rep["rows"]: ws.append(r)
    if rep.get("totals"):
        ws.append(rep["totals"])
        for c in ws[ws.max_row]: c.font = Font(bold=True)
    if rep.get("note"): ws.append([]); ws.append([rep["note"]])
    for i, col in enumerate(ws.iter_cols(min_row=5, max_row=min(ws.max_row, 60)), 1):
        ws.column_dimensions[col[0].column_letter].width = min(60, max(12, max(len(str(c.value or "")) for c in col) + 2))
    ws.freeze_panes = "A6"
    b = io.BytesIO(); wb.save(b); return b.getvalue()

def to_pdf(rep, meta):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer
    b = io.BytesIO(); st = getSampleStyleSheet()
    doc = SimpleDocTemplate(b, pagesize=landscape(A4), leftMargin=24, rightMargin=24, topMargin=28, bottomMargin=28, title=rep["title"])
    cell = st["BodyText"]; cell.fontSize = 8; cell.leading = 10
    data = [rep["columns"]] + [[Paragraph(str(x if x is not None else ""), cell) if isinstance(x, str) and len(x) > 24 else ("" if x is None else x) for x in r] for r in rep["rows"]]
    if rep.get("totals"): data.append(rep["totals"])
    t = Table(data, repeatRows=1)
    style = [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F2A44")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), 8),
             ("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F4F8")]), ("VALIGN", (0, 0), (-1, -1), "TOP")]
    if rep.get("totals"): style += [("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"), ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#FFE9B8"))]
    t.setStyle(TableStyle(style))
    story = [Paragraph("<b>TBox SCADA</b> - Technical Power Systems", st["Title"]), Paragraph(rep["title"], st["Heading2"]), Paragraph(meta, st["Normal"]), Spacer(1, 8), t]
    if rep.get("note"): story += [Spacer(1, 6), Paragraph("<i>" + rep["note"] + "</i>", st["Normal"])]
    def footer(canv, d): canv.setFont("Helvetica", 7); canv.drawString(24, 14, "TBox SCADA - generated " + time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime())); canv.drawRightString(d.pagesize[0] - 24, 14, f"Page {d.page}")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return b.getvalue()
