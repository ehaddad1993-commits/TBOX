import hashlib, hmac, secrets, time
from functools import wraps
from flask import request, g
from . import db

SESSION_TTL = 12 * 3600
RANK = {"viewer": 1, "operator": 2, "admin": 3}
_attempts = {}

class ApiError(Exception):
    def __init__(self, status, code, message=""):
        self.status, self.code, self.message = status, code, message or code

def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200_000).hex()
    return f"pbkdf2${salt}${h}"

def verify_pw(pw, stored):
    try:
        _, salt, h = stored.split("$")
    except ValueError:
        return False
    return hmac.compare_digest(hash_pw(pw, salt).split("$")[2], h)

def sha(s): return hashlib.sha256(s.encode()).hexdigest()

def client_ip(): return request.headers.get("X-Forwarded-For", request.remote_addr or "").split(",")[0].strip()

def audit(action, target="", detail="", result="ok", user=None):
    u = user or getattr(g, "user", None)
    db.run("INSERT INTO audit_log(ts,username,ip,action,target,detail,result) VALUES(?,?,?,?,?,?,?)",
           (time.time(), (u or {}).get("username", ""), client_ip() if request else "", action, target, str(detail)[:500], result))

def login(username, password):
    ip = client_ip(); now = time.time()
    n, first = _attempts.get(ip, (0, now))
    if now - first > 300: n, first = 0, now
    if n >= 10: raise ApiError(429, "too_many_attempts", "Too many login attempts, try again in a few minutes")
    u = db.one("SELECT * FROM users WHERE username=? AND active=1", (username,))
    if not u or not verify_pw(password, u["pw_hash"]):
        _attempts[ip] = (n + 1, first)
        audit("login", username, result="denied", user={"username": username})
        raise ApiError(401, "bad_credentials", "Invalid username or password")
    _attempts.pop(ip, None)
    tok = secrets.token_urlsafe(32)
    db.run("INSERT INTO sessions(token_hash,user_id,created,expires,ip) VALUES(?,?,?,?,?)", (sha(tok), u["id"], now, now + SESSION_TTL, ip))
    db.run("UPDATE users SET last_login=? WHERE id=?", (now, u["id"]))
    audit("login", username, user=u)
    return tok, u

def public_user(u):
    return {k: u[k] for k in ("id", "username", "full_name", "role", "can_control", "active")}

def load_user():
    h = request.headers.get("Authorization", "")
    tok = h[7:] if h.startswith("Bearer ") else request.args.get("token", "")
    if not tok: raise ApiError(401, "unauthenticated", "Login required")
    row = db.one("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires>? AND u.active=1", (sha(tok), time.time()))
    if not row: raise ApiError(401, "session_expired", "Session expired")
    g.user, g.token = row, tok
    return row

def require(role="viewer"):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            u = load_user()
            if RANK[u["role"]] < RANK[role]:
                audit("forbidden", request.path, result="denied")
                raise ApiError(403, "forbidden", f"Requires {role} role")
            return fn(*a, **kw)
        return wrapper
    return deco

def site_ids(u=None):
    """Sites visible to the user. Admins see everything; others only assigned sites."""
    u = u or g.user
    if u["role"] == "admin": return [r["id"] for r in db.q("SELECT id FROM sites")]
    return [r["site_id"] for r in db.q("SELECT site_id FROM user_sites WHERE user_id=?", (u["id"],))]

def check_site(site_id):
    if site_id not in site_ids(): raise ApiError(403, "site_forbidden", "No access to this site")

def require_edge(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        key = request.headers.get("X-Site-Key", "")
        site = db.one("SELECT * FROM sites WHERE api_key_hash=?", (sha(key),)) if key else None
        if not site: raise ApiError(401, "bad_site_key", "Invalid site key")
        g.site = site
        return fn(*a, **kw)
    return wrapper
