import os
from .app import create_app
if __name__ == "__main__":
    create_app().run(host=os.environ.get("TBOX_HOST", "127.0.0.1"), port=int(os.environ.get("TBOX_PORT", "8000")), threaded=True)
