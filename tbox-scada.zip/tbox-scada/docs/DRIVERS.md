# Drivers and hardware requirements

**Honesty rule:** a device is "supported" only when its driver is `implemented` *and* you have verified the register map on real hardware. Nothing here is auto-detected.

| Driver | Status in v0.1 | What it needs |
|---|---|---|
| `simulator` | implemented | nothing; 5 profiles (generator, solar inverter, energy meter, PLC station, VFD) |
| `modbus_tcp` | implemented, **read-only** (FC 01/02/03/04), unit-tested against a protocol-level fake slave, **not yet tested on real hardware** | device with Modbus TCP server enabled, reachable from the edge PC, vendor register map |
| Modbus RTU / RS-485 | via gateway | RS-485-to-Ethernet gateway in Modbus TCP-to-RTU mode; use `modbus_tcp` with host = gateway, `unit_id` = slave ID. Native serial driver: planned |
| Schneider M221 | via `modbus_tcp` | see below |
| Deye inverters | planned | exact model's Modbus protocol document (maps differ by model/firmware); RS-485 or logger interface |
| Socomec meters | planned (use `modbus_tcp` + CSV import today) | Modbus map of your exact DIRIS/COUNTIS model and comm module |
| DSE controllers | planned (use `modbus_tcp` + CSV import today) | DSE register list for your controller; Modbus enabled in DSE Configuration Suite; RS-485 or Ethernet module |
| VFDs / pumps / sensors | via `modbus_tcp` | vendor register map |
| MQTT, OPC UA | planned | broker/topic mapping; OPC UA endpoint, node IDs, security policy |

## Schneider Modicon M221 (what to verify on your unit)
1. In EcoStruxure Machine Expert - Basic, give the PLC a fixed IP and confirm the Modbus TCP server is reachable (check the *M221 Programming Guide* for your model/firmware).
2. Memory words (`%MW`) are the usual exchange area: in your program copy values you want to monitor (analog inputs, counters, states) into `%MW` words. `%MWn` is normally holding register `n` (zero-based) - verify on your firmware and set `addr_offset` if your docs are 1-based.
3. In TBox: Devices -> Add -> *Modbus TCP*, host = PLC IP, port 502, unit ID per the M221 docs (commonly 1 or 255; try both). Add tags (or CSV-import) with `reg_type=holding`, `data_type=uint16/int16`, and `scale` (e.g. 0.1 for tenths).
4. 32-bit values and floats span two registers; if values look wrong, flip `word_order`.
5. Keep the PLC on the plant LAN only. The **edge** PC talks to it; the cloud never does.
6. Writing is intentionally not implemented (see Safety in ARCHITECTURE.md).

## Adding a driver
Create `edge/tbox_edge/drivers/<name>.py` with a class extending `Driver` (`read()` returns `{tag_id: raw | TagError}`; raise `ConnectionError` when the device is unreachable), register it in `drivers/__init__.py`, add its entry (params form + requirements text) to `server/tbox_server/catalog.py`, and write a test against a fake device like `edge/tests/test_edge.py` does.

## CSV tag import format
`name,description,address,reg_type,data_type,word_order,scale,offset,unit,min_val,max_val,access,log_interval_s,role` (only `name` and `address` are required). Re-importing updates tags with the same name.
