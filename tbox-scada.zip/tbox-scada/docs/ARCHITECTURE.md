# TBox SCADA architecture (Technical Power Systems)

```
 PLANT (per site)                                  CLOUD / SERVER
 +-----------+ Modbus TCP   +------------------+  HTTPS (outbound only)  +------------------------------+
 | M221, VFD,| <----------> | EDGE GATEWAY     | ---- batches + key ---> | Caddy (TLS) -> TBox server   |
 | meters,   | (RTU via     | drivers->poller  | <--- config/commands -- |  REST API, auth, alarms      |
 | gens, inv.|  gateway)    | ->disk outbox    |                         |  ingest, reports, screens    |
 +-----------+              | ->uploader       |                         |  SQLite (->Postgres/Timescale)|
  never exposed             | local page :8081 |                         +---------------^--------------+
  to the internet           +------------------+                      Browsers: Windows / Android / tablets
```
**Separation:** the web UI and API never speak to PLCs. Only the edge does, from inside the plant LAN. Drivers are plug-ins behind one small contract (`read`, optional `write`, `close`).

## Stack: recommended vs. what v0.1 uses
| Layer | Recommended at scale | v0.1 (this repo) | Why |
|---|---|---|---|
| Edge | Python + pymodbus / asyncua / paho-mqtt | Python stdlib (own Modbus TCP client) | Python runs on Windows/Linux/ARM and has the best protocol libraries; stdlib keeps v0.1 dependency-free and testable offline |
| API | FastAPI | Flask | Same REST+JSON shape; Flask was what the offline build environment had |
| Database | PostgreSQL + TimescaleDB (hypertable on `history`, continuous aggregates) | SQLite (WAL) behind `db.py` | Zero admin for v0.1; schema is portable |
| Frontend | React/TypeScript (Vite) | Vanilla ES modules, canvas + SVG, no build step | Works offline on a plant LAN, no CDN; HMI widgets are plain SVG functions that port directly |
| Edge->cloud | HTTPS batches (here) or MQTT/TLS | HTTPS batches, idempotent replay | Outbound-only, firewall friendly |
| TLS | Caddy / nginx | Caddy (compose file) | Automatic certificates |

The REST contract and the `/api/ingest` payload are the stable seams: swapping Flask->FastAPI or SQLite->Postgres does not touch the edge or the UI.

## Data flow and reliability
1. One poller thread per device reads tags at its `poll_ms`, applies `raw*scale+offset`, and marks per-tag quality (Good/Bad). A device is reported comm-failed after 3 consecutive failures.
2. Every 2 s a batch is written to a **disk outbox** first; the uploader sends up to 30 batches per request, oldest first, with exponential back-off to 30 s. Nothing is deleted until the server confirms. (Tested: 100 batches buffered during an outage drained complete and in order.)
3. Server ingest is **idempotent**, applies each tag's logging interval, updates `tag_current`, and runs the alarm engine in the same transaction.
4. Quality *Stale* is computed on read (no update for more than 3x poll). Device status = Offline (disabled) / Communication Lost / Alarm / Online. A watchdog raises comm alarms if a device or edge goes silent.
5. The edge pulls its config every 10 s and caches it on disk, so it starts polling even if the server is unreachable.

## Data model
See `server/tbox_server/schema.sql`: sites -> devices -> tags; tag_current; history; alarm_defs -> alarms (active_unack -> active_ack -> cleared, or returned-unacked); events; audit_log; users / user_sites / sessions; screens (JSON documents); commands; notif_settings.

## Security
Per-site API keys (hashed) for edges. User sessions with PBKDF2-SHA256 (200k iterations), 12 h tokens, login rate-limit. Roles admin / operator / viewer plus per-site assignment. CSP, HSTS and frame headers. Every login, config change, report, and denied or confirmed write goes to `audit_log`. HTTPS via the proxy. Not yet implemented: 2FA, SSO, per-device permissions, HttpOnly-cookie sessions.

## Safety
- v0.1 is **monitoring only**. `modbus_tcp` has no write function; the server defaults to `TBOX_COMMANDS_ENABLED=false`; the edge defaults to `allow_writes=false`. Three independent gates would have to be opened, and the Modbus driver would still refuse.
- The command path is built and tested end to end (permission -> tag `access=write` -> range check -> **two-step confirmation token bound to user, tag and value, 30 s expiry** -> queued -> edge executes or rejects -> result audited), so enabling it later is a review, not a rewrite.
- Safety-critical logic (E-stops, interlocks, engine protection, breaker synchronising, tank overfill trips) stays in the PLC, safety relay or controller. SCADA alarms are informational and must never be the only protection.

## Implemented vs. needs hardware / future work
| Area | Status |
|---|---|
| Dashboard (status, KPIs, gauges, trends, alarm feed, dark/light), device detail | working on simulated data |
| Device manager, tag manager (CRUD, CSV import/export), driver catalog | working |
| Historian with per-tag log interval (min 1 s), trends with downsampling | working (many tags at 1 s needs TimescaleDB) |
| Reports: energy, fuel (level- and flow-based), alarms; hourly/daily/monthly/yearly; XLSX + PDF | working |
| Alarms: HH/H/L/LL, deadband, delay, priorities, ack, history, comm alarms, webhook, browser sound/pop-up | working (email/SMS planned) |
| HMI editor: 13 widget types, tag binding, alarm colours, navigation, save/edit | working (control buttons, symbol library, images planned) |
| Multi-site, roles, audit, HTTPS deployment files, backups | working |
| Edge: Modbus TCP read, buffering, local status page, simulator | unit-tested; **needs validation on real M221 and other hardware** |
| Native RS-485, Deye, Socomec, DSE templates, MQTT, OPC UA | planned: need the real devices and vendor register maps |
| Cloud-to-site sync for a full local UI during outages; load testing; Timescale migration; 2FA | planned |

## Roadmap
1. Validate Modbus TCP against the real M221 (read-only) and build its tag list. 2. Verify meter, generator and inverter register maps on site. 3. Timescale + FastAPI when tag count or rate demands. 4. Reviewed control phase (per-tag permissions, two-person confirm). 5. MQTT/OPC UA, email/SMS, PWA offline shell.
