# Deployment

## Local development
```bash
pip install -r server/requirements.txt
scripts/dev.sh          # seeds demo data on first run, starts server + 2 simulated edges
# open http://127.0.0.1:8000   admin / TBoxDemo#1  (DEMO ONLY)
```
Tests: `cd server && python -m unittest discover -s tests`, `cd edge && python -m unittest discover -s tests`, `python -m unittest tests.test_contract`.
Demo note: seeded history ends when you seed; if you start the stack much later there is a gap until live logging fills it.

## Production server (VPS / cloud VM)
1. `cp .env.example .env`; set a strong `TBOX_ADMIN_PASSWORD` and your `TBOX_DOMAIN` (DNS A record -> server).
2. `docker compose -f deploy/docker-compose.yml --env-file .env up -d --build` - Caddy obtains a Let's Encrypt certificate and serves HTTPS; the app is not exposed directly.
3. Log in as `admin`, then **Users** to create real accounts. Create sites with `POST /api/sites` (admin token); the response shows the site's edge key **once** (rotate via `/api/sites/<id>/rotate-key`).
4. Backups: automatic daily online backups to `/data/backups` (14 kept) plus `POST /api/admin/backup`. Copy them off the box (rsync/rclone). Restore: stop the server, replace `/data/tbox.db` with a backup file, start.

> Single worker by design in v0.1 (in-process alarm state). SQLite handles tens of tags at 1 s logging comfortably; for hundreds of tags at 1 s, move history to TimescaleDB (see ARCHITECTURE.md).

## Plant edge gateway (one per site)
- Hardware: any small or industrial PC on the PLC LAN with outbound HTTPS (no inbound ports). Python 3.10+, no extra packages.
- Copy `edge/tbox_edge` to the PC and create `edge.json` from `edge/config/edge.example.json` (server URL + site key).
- Linux: install `deploy/tbox-edge.service` (systemd). Windows: run `python -m tbox_edge --config edge.json` as a service with NSSM or Task Scheduler (run at startup, restart on failure).
- Internet loss: the edge keeps polling, buffers to `edge_buffer.db`, serves a read-only page at `http://<bind>:8081`, and uploads oldest-first on reconnect (the server de-duplicates). For a full local SCADA UI during outages, also run this server on a site PC (v0.1 has no cloud-to-site sync).

## GitHub
```bash
git remote add origin git@github.com:<you>/tbox-scada.git
git push -u origin main      # CI runs all tests
```
Never commit `.env`, `*.db`, edge keys or `edge.json` (already in `.gitignore`).

## Security checklist before real use
HTTPS only; unique strong passwords; remove demo users; one key per site; firewall PLCs from the internet; keep `TBOX_COMMANDS_ENABLED=false` until the command phase is reviewed; copy backups off-box.
